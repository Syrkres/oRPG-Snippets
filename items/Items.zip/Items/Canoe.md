---
cssclass: oRPGPage
fileType: item
itemType: vehicle
name: canoe
source: toa
rarity: none
attunement: none_required
value: 50_gp
weight: 100_lb.
properties: speed:_2_mphcarrying_capacity:_6_passengerscrew_1_ac_11_hp_50
---
> [!oRPG-Item]
> # Canoe
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Vehicle |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| 100 lb. |
>  |**Properties** | Speed: 2 mphCarrying Capacity: 6 passengersCrew 1, AC 11, HP 50 |
> | **Source** | ToA |

#  Canoe
**Type:** Vehicle

**Rarity:** None
**Attunement:** None Required
**Source:** ToA
**Properties:** Speed: 2 mphCarrying Capacity: 6 passengersCrew 1, AC 11, HP 50
**Value:** 50 gp
**Weight:** 100 lb.

**Description:** A canoe can be purchased in Port Nyanzaru for 50 gp. It holds up to six Medium creatures and has a maximum speed of 2 mph. It is otherwise identical to a rowboat. Crew. A ship needs a crew of skilled hirelings to function. As per the Player&#39;s Handbook, one skilled hireling costs at least 2 gp per day. The minimum number of skilled hirelings needed to crew a ship depends on the type of vessel.You can track the loyalty of individual crew members or the crew as a whole using the optional loyalty rules in chapter 4 of the Dungeon Master&#39;s Guide. If at least half the crew becomes disloyal during a voyage, the crew turns hostile and stages a mutiny. If the ship is berthed, disloyal crew members leave the ship and never return. Passengers. This indicates the number of Small and Medium passengers the ship can accommodate.Accommodations consist of shared hammocks in tight quarters. A ship outfitted with private accommodations can carry one-fifth as many passengers.A passenger is usually expected to pay 5 sp per day for a hammock, but prices can vary from ship to ship. A small private cabin usually costs 2 gp per day. Cargo. The maximum tonnage the ship can carry. Damage Threshold. If a ship has a Damage Threshold, it has immunity to all damage unless it takes an amount of damage equal to or greater than its damage threshold, in which case it takes damage as normal. Any damage that fails to meet or exceed the damage threshold is considered superficial and doesn&#39;t reduce the ship&#39;s hit points. Ship Repair. Repairs to a damaged ship can be made while the vessel is berthed. Repairing 1 hit point of damage requires 1 day and costs 20 gp for materials and labor.



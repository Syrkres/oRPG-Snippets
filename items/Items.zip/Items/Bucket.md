---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: bucket
source: phb
rarity: none
attunement: none_required
value: 5_cp
weight: 2_lb.
properties:
---
> [!oRPG-Item]
> # Bucket
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 cp |
>  | **Weight**| 2 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Bucket
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 cp
**Weight:** 2 lb.

**Description:** A bucket holds 3 gallons of liquid or ½ cubic foot of solids.



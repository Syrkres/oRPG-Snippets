---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear_poison_(injury)
name: drow_poison
source: dmg
rarity: none
attunement: none_required
value: 200_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Drow Poison
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear, poison (injury) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 200 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Drow Poison
**Type:** adventuring gear, poison (injury)

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 200 gp
**Weight:** Varies

**Description:** This poison is typically made only by the drow, and only in a place far removed from sunlight. A creature subjected to this poison must succeed on a DC 13 Constitution saving throw or be poisoned for 1 hour. If the saving throw fails by 5 or more, the creature is also unconscious while poisoned in this way. The creature wakes up if it takes damage or if another creature takes an action to shake it awake.



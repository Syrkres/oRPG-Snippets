---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: crystal_ball_of_mind_reading
source: dmg
rarity: legendary
attunement: requires_attunement
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Crystal Ball of Mind Reading
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Crystal Ball of Mind Reading
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** This crystal ball is about 6 inches in diameter. While touching it, you can cast the scrying spell (save DC 17) with it.You can use an action to cast the detect thoughts spell (save DC 17) while you are scrying with the crystal ball, targeting creatures you can see within 30 feet of the spell&#39;s sensor. You don&#39;t need to concentrate on this detect thoughts to maintain it during its duration, but it ends if scrying ends.



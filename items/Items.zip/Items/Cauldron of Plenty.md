---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cauldron_of_plenty
source: idrotf
rarity: rare
attunement: none_required
value: varies
weight: 50_lb.
properties:
---
> [!oRPG-Item]
> # Cauldron of Plenty
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 50 lb. |
>  |**Properties** |  |
> | **Source** | IDRotF |

#  Cauldron of Plenty
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** IDRotF
**Properties:**
**Value:** Varies
**Weight:** 50 lb.

**Description:** This cauldron is made of thick copper that has turned green with age. It is 4 feet wide, has a mouth 3½ feet in diameter, weighs 50 pounds, and can hold up to 30 gallons of liquid. Embossed on its bulging sides are images of satyrs and nymphs in repose, holding ladles. The cauldron comes with a lid and has side handles. It sits on five little clawed feet that keep it from tipping.If water is poured into the cauldron and stirred for 1 minute, it transforms into a hearty, hot stew, which can provide one nourishing meal for up to four people per gallon. The stew remains hot while in the cauldron, then cools naturally after it is removed. The outside of the cauldron remains safe to touch despite the heat of the stew.The cauldron can create stew three times. It then ceases to function until the next dawn, when it regains all its uses.



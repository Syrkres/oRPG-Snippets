---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: dragon
source: wdh
rarity: none
attunement: none_required
value: 1_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Dragon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WDH |

#  Dragon
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** WDH
**Properties:**
**Value:** 1 gp
**Weight:** Varies

**Description:** Gold coin, half again as large as a nib (1 dragon &#x3D; 100 nibs)



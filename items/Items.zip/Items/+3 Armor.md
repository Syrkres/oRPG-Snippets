---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +3_armor
source: dmg
rarity: legendary
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +3 Armor
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Legendary |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +3 Armor
**Type:** generic variant

**Rarity:** Legendary
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +3 bonus to AC while wearing this armor. Base items. This item variant can be applied to the following base items:Breastplate (+3 Breastplate)Chain Mail (+3 Chain Mail)Chain Shirt (+3 Chain Shirt)Half Plate Armor (+3 Half Plate Armor)Hide Armor (+3 Hide Armor)Leather Armor (+3 Leather Armor)Padded Armor (+3 Padded Armor)Plate Armor (+3 Plate Armor)Ring Mail (+3 Ring Mail)Scale Mail (+3 Scale Mail)Spiked Armor (+3 Spiked Armor)Splint Armor (+3 Splint Armor)Studded Leather Armor (+3 Studded Leather Armor)



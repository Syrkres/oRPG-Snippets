---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: corpse_slayer
source: egw
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Corpse Slayer
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Corpse Slayer
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You gain a +1 bonus to attack and damage rolls made with this magic weapon.When you hit an undead creature with an attack using this weapon, the attack deals an extra 1d8 damage of the weapon&#39;s type, and the creature has disadvantage on saving throws against effects that turn undead until the start of your next turn. Base items. This item variant can be applied to the following base items:Antimatter Rifle (Corpse Slayer Antimatter Rifle)Automatic Pistol (Corpse Slayer Automatic Pistol)Automatic Rifle (Corpse Slayer Automatic Rifle)Battleaxe (Corpse Slayer Battleaxe)Blowgun (Corpse Slayer Blowgun)Club (Corpse Slayer Club)Dagger (Corpse Slayer Dagger)Dart (Corpse Slayer Dart)Double-Bladed Scimitar (Corpse Slayer Double-Bladed Scimitar)Flail (Corpse Slayer Flail)Glaive (Corpse Slayer Glaive)Greataxe (Corpse Slayer Greataxe)Greatclub (Corpse Slayer Greatclub)Greatsword (Corpse Slayer Greatsword)Halberd (Corpse Slayer Halberd)Hand Crossbow (Corpse Slayer Hand Crossbow)Handaxe (Corpse Slayer Handaxe)Heavy Crossbow (Corpse Slayer Heavy Crossbow)Hooked Shortspear (Corpse Slayer Hooked Shortspear)Hunting Rifle (Corpse Slayer Hunting Rifle)Javelin (Corpse Slayer Javelin)Lance (Corpse Slayer Lance)Laser Pistol (Corpse Slayer Laser Pistol)Laser Rifle (Corpse Slayer Laser Rifle)Light Crossbow (Corpse Slayer Light Crossbow)Light Hammer (Corpse Slayer Light Hammer)Light Repeating Crossbow (Corpse Slayer Light Repeating Crossbow)Longbow (Corpse Slayer Longbow)Longsword (Corpse Slayer Longsword)Mace (Corpse Slayer Mace)Maul (Corpse Slayer Maul)Morningstar (Corpse Slayer Morningstar)Musket (Corpse Slayer Musket)Net (Corpse Slayer Net)Pike (Corpse Slayer Pike)Pistol (Corpse Slayer Pistol)Quarterstaff (Corpse Slayer Quarterstaff)Rapier (Corpse Slayer Rapier)Revolver (Corpse Slayer Revolver)Scimitar (Corpse Slayer Scimitar)Shortbow (Corpse Slayer Shortbow)Shortsword (Corpse Slayer Shortsword)Shotgun (Corpse Slayer Shotgun)Sickle (Corpse Slayer Sickle)Sling (Corpse Slayer Sling)Spear (Corpse Slayer Spear)Trident (Corpse Slayer Trident)War Pick (Corpse Slayer War Pick)Warhammer (Corpse Slayer Warhammer)Whip (Corpse Slayer Whip)Yklwa (Corpse Slayer Yklwa)



---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_cold_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Cold Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Cold Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to cold damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Cold Resistance)Chain Mail (Chain Mail of Cold Resistance)Chain Shirt (Chain Shirt of Cold Resistance)Half Plate Armor (Half Plate Armor of Cold Resistance)Hide Armor (Hide Armor of Cold Resistance)Leather Armor (Leather Armor of Cold Resistance)Padded Armor (Padded Armor of Cold Resistance)Plate Armor (Plate Armor of Cold Resistance)Ring Mail (Ring Mail of Cold Resistance)Scale Mail (Scale Mail of Cold Resistance)Spiked Armor (Spiked Armor of Cold Resistance)Splint Armor (Splint Armor of Cold Resistance)Studded Leather Armor (Studded Leather Armor of Cold Resistance)



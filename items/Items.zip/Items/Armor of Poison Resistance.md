---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_poison_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Poison Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Poison Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to poison damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Poison Resistance)Chain Mail (Chain Mail of Poison Resistance)Chain Shirt (Chain Shirt of Poison Resistance)Half Plate Armor (Half Plate Armor of Poison Resistance)Hide Armor (Hide Armor of Poison Resistance)Leather Armor (Leather Armor of Poison Resistance)Padded Armor (Padded Armor of Poison Resistance)Plate Armor (Plate Armor of Poison Resistance)Ring Mail (Ring Mail of Poison Resistance)Scale Mail (Scale Mail of Poison Resistance)Spiked Armor (Spiked Armor of Poison Resistance)Splint Armor (Splint Armor of Poison Resistance)Studded Leather Armor (Studded Leather Armor of Poison Resistance)



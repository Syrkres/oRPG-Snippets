---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: abacus
source: phb
rarity: none
attunement: none_required
value: 2_gp
weight: 2_lb.
properties:
---
> [!oRPG-Item]
> # Abacus
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 gp |
>  | **Weight**| 2 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Abacus
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 2 gp
**Weight:** 2 lb.

**Description:**



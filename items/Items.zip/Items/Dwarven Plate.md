---
cssclass: oRPGPage
fileType: item
itemType: heavy_armor
name: dwarven_plate
source: dmg
rarity: very_rare
attunement: none_required
value: varies
weight: 65_lb.
properties: ac_18
---
> [!oRPG-Item]
> # Dwarven Plate
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | heavy armor |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | 16,500 gp |
>  | **Weight**| 65 lb. |
>  |**Properties** | AC 18 |
> | **Source** | DMG |

#  Dwarven Plate
**Type:** heavy armor

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** DMG
**Properties:** AC 18
**Value:** Varies
**Weight:** 65 lb.

**Description:** While wearing this armor, you gain a +2 bonus to AC. In addition, if an effect moves you against your will along the ground, you can use your reaction to reduce the distance you are moved by up to 10 feet.The wearer has disadvantage on Dexterity (Stealth) checks.If the wearer has a Strength score lower than 15, their speed is reduced by 10 feet.



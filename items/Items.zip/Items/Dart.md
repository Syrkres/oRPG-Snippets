---
cssclass: oRPGPage
fileType: item
itemType: weapon_range_simple_weapon
name: dart
source: phb
rarity: none
attunement: none_required
value: 5_cp
weight: ¼_lb.
properties: 1d4_piercing_-_finesse_thrown_(20&#x2F;60_ft.)
---
> [!oRPG-Item]
> # Dart
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon, range, simple weapon |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 cp |
>  | **Weight**| ¼ lb. |
>  |**Properties** | 1d4, piercing, - finesse, thrown (20&#x2F;60 ft.) |
> | **Source** | PHB |

#  Dart
**Type:** weapon, range, simple weapon

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** 1d4, piercing, - finesse, thrown (20&#x2F;60 ft.)
**Value:** 5 cp
**Weight:** ¼ lb.

**Description:**  Range. A weapon that can be used to make a ranged attack has a range shown in parentheses after the ammunition or thrown property. The range lists two numbers. The first is the weapon&#39;s normal range in feet, and the second indicates the weapon&#39;s maximum range. When attacking a target beyond normal range, you have disadvantage on the attack roll. You can&#39;t attack a target beyond the weapon&#39;s long range. Finesse. When making an attack with a finesse weapon, you use your choice of your Strength or Dexterity modifier for the attack and damage rolls. You must use the same modifier for both rolls. Thrown. If a weapon has the thrown property, you can throw the weapon to make a ranged attack. If the weapon is a melee weapon, you use the same ability modifier for that attack roll and damage roll that you would use for a melee attack with the weapon. For example, if you throw a handaxe, you use your Strength, but if you throw a dagger, you can use either your Strength or your Dexterity, since the dagger has the finesse property.



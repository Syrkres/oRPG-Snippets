---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: embroidered_silk_handkerchief
source: dmg
rarity: none
attunement: none_required
value: 25_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Embroidered silk handkerchief
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 25 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Embroidered silk handkerchief
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 25 gp
**Weight:** Varies

**Description:**



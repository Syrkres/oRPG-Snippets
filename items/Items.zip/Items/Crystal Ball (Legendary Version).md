---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: crystal_ball_(legendary_version)
source: dmg
rarity: legendary
attunement: requires_attunement
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Crystal Ball (Legendary Version)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Crystal Ball (Legendary Version)
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** Multiple variations of this item exist, as listed below:Crystal Ball of Mind ReadingCrystal Ball of TelepathyCrystal Ball of True Seeing



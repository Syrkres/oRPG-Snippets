---
cssclass: oRPGPage
fileType: item
itemType: shield_(shield)
name: battering_shield
source: egw
rarity: rare
attunement: requires_attunement
value: varies
weight: 6_lb.
properties: ac_+2
---
> [!oRPG-Item]
> # Battering Shield
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | shield (shield) |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 6 lb. |
>  |**Properties** | AC +2 |
> | **Source** | EGW |

#  Battering Shield
**Type:** shield (shield)

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:** AC +2
**Value:** Varies
**Weight:** 6 lb.

**Description:** While holding this iron tower shield, you gain a +1 bonus to AC. This bonus is in addition to the shield&#39;s normal bonus to AC.Additionally, the shield has 3 charges, and it regains 1d3 expended charges daily at dawn. If you are holding the shield and push a creature within your reach at least 5 feet away, you can expend 1 charge to push that creature an additional 10 feet, knock it prone, or both.



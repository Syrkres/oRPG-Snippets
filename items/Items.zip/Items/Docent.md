---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: docent
source: erlw
rarity: rare
attunement: requires_attunement_by_a_warforged
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Docent
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement By A Warforged |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ERLW |

#  Docent
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement By A Warforged
**Source:** ERLW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** A docent is a small metal sphere, about 2 inches across, studded with dragonshards. To attune to a docent, you must embed the item somewhere on your body, such as your chest or your eye socket. Sentience. A docent is a sentient item of any alignment with an Intelligence of 16, a Wisdom of 14, and a Charisma of 14. It perceives the world through your senses. It communicates telepathically with you and can speak, read, and understand any language it knows (see &quot;Random Properties&quot; below). Life Support. Whenever you end your turn with 0 hit points, the docent can make a Wisdom (Medicine) check with a +6 bonus. If this check succeeds, the docent stabilizes you. Random Properties. A docent has the following properties:Languages. The docent knows Common, Giant, and 1d4 additional languages chosen by the DM. If a docent knows fewer than six languages, it can learn a new language after it hears or reads the language through your senses.Skills. The docent has a +7 bonus to one of the following skills (roll a d4): (1) Arcana, (2) History, (3) Investigation, or (4) Nature.Spells. The docent knows one of the following spells and can cast it at will, requiring no components (roll a d6): (1–2) detect evil and good or (3–6) detect magic. The docent decides when to cast the spell. Personality. A docent is designed to advise and assist the warforged it&#39;s attached to. One of the simple functions of a docent is to serve as a translator. The docent&#39;s properties are under its control, and if you have a bad relationship with your docent, it might refuse to assist you.



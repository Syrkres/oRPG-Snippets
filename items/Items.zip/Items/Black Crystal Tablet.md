---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: black_crystal_tablet
source: wdmm
rarity: legendary
attunement: requires_attunement_by_a_creature_that_has_proficiency_in_the_arcana_skill
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Black Crystal Tablet
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement By A Creature That Has Proficiency In The Arcana Skill |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WDMM |

#  Black Crystal Tablet
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement By A Creature That Has Proficiency In The Arcana Skill
**Source:** WDMM
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Any creature that attunes to the tablet must make a DC 20 Wisdom saving throw at the end of its next long rest. On a failed save, the creature becomes afflicted with a random form of long-term madness (see &quot;Madness&quot; in chapter 8 of the Dungeon Master&#39;s Guide).As an action, a creature attuned to the Black Crystal Tablet can use it to cast eyebite or gate (the portal created by this spell links to the Far Realm only). After the tablet is used to cast a spell, it cannot be used again until the next dawn.



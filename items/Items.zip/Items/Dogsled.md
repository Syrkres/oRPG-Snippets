---
cssclass: oRPGPage
fileType: item
itemType: vehicle_(land)
name: dogsled
source: idrotf
rarity: none
attunement: none_required
value: 20_gp
weight: 300_lb.
properties:
---
> [!oRPG-Item]
> # Dogsled
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | vehicle (land) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 20 gp |
>  | **Weight**| 300 lb. |
>  |**Properties** |  |
> | **Source** | IDRotF |

#  Dogsled
**Type:** vehicle (land)

**Rarity:** None
**Attunement:** None Required
**Source:** IDRotF
**Properties:**
**Value:** 20 gp
**Weight:** 300 lb.

**Description:** An empty sled costs 20 gp, weighs 300 pounds, and has room at the back for one driver.



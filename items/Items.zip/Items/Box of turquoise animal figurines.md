---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: box_of_turquoise_animal_figurines
source: dmg
rarity: none
attunement: none_required
value: 250_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Box of turquoise animal figurines
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 250 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Box of turquoise animal figurines
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 250 gp
**Weight:** Varies

**Description:**



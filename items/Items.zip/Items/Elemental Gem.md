---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: elemental_gem
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Elemental Gem
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | 2,250 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Elemental Gem
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Multiple variations of this item exist, as listed below:Elemental Gem, Blue SapphireElemental Gem, EmeraldElemental Gem, Red CorundumElemental Gem, Yellow Diamond



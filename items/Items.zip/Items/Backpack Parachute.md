---
cssclass: oRPGPage
fileType: item
itemType: other
name: backpack_parachute
source: wdh
rarity: unknown
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Backpack Parachute
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | Unknown |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WDH |

#  Backpack Parachute
**Type:** other

**Rarity:** Unknown
**Attunement:** None Required
**Source:** WDH
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** A humanoid wearing this piece of gear can deploy the parachute as a reaction while falling, or as an action otherwise. The parachute requires at least a 10-foot cube of unoccupied space in which to deploy, and it doesn&#39;t open fast enough to slow a fall of less than 60 feet. If it has sufficient time and space to deploy properly, the parachute allows its wearer to land without taking falling damage. Once it has been used, the parachute takes 10 minutes to repack.



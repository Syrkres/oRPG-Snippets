---
cssclass: oRPGPage
fileType: item
itemType: rod
name: blast_scepter
source: wdmm
rarity: very_rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Blast Scepter
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | rod |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WDMM |

#  Blast Scepter
**Type:** rod

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** WDMM
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** The Blast Scepter can be used as an arcane focus.Whoever is attuned to the Blast Scepter gains resistance to fire and lightning damage and can, as an action, use it to cast thunderwave as a 4th-level spell (save DC 16) without expending a spell slot.



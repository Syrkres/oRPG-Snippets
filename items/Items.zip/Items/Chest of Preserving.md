---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: chest_of_preserving
source: wdmm
rarity: common
attunement: none_required
value: varies
weight: 25_lb.
properties:
---
> [!oRPG-Item]
> # Chest of Preserving
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 25 lb. |
>  |**Properties** |  |
> | **Source** | WDMM |

#  Chest of Preserving
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** WDMM
**Properties:**
**Value:** Varies
**Weight:** 25 lb.

**Description:** Food and other perishable items do not age or decay while inside a Chest of Preserving. The chest is 2½ feet long, 1½ feet wide, and 1 foot tall with a half-barrel lid. The chest has a lock, which can be picked with thieves&#39; tools and a successful DC 15 Dexterity check. Smashing the lock or any other part of the chest renders it nonmagical.



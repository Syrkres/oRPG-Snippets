---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: boots_of_striding_and_springing
source: dmg
rarity: uncommon
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Boots of Striding and Springing
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | 5,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Boots of Striding and Springing
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While you wear these boots, your walking speed becomes 30 feet, unless your walking speed is higher, and your speed isn&#39;t reduced if you are encumbered or wearing heavy armor. In addition, you can jump three times the normal distance, though you can&#39;t jump farther than your remaining movement would allow.



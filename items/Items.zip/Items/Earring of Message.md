---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: earring_of_message
source: crcotn
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Earring of Message
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | CRCotN |

#  Earring of Message
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** CRCotN
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** The blue crystal of this earring is wrapped with delicate copper wire. The earring has 5 charges. While wearing it, you can use an action to expend 1 charge and cast the message spell. The earring regains 1d4 + 1 expended charges daily at dawn.



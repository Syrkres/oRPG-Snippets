---
cssclass: oRPGPage
fileType: item
itemType: other
name: adjustable_stilts
source: wdh
rarity: unknown
attunement: none_required
value: varies
weight: 8_lb.
properties:
---
> [!oRPG-Item]
> # Adjustable Stilts
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | Unknown |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 8 lb. |
>  |**Properties** |  |
> | **Source** | WDH |

#  Adjustable Stilts
**Type:** other

**Rarity:** Unknown
**Attunement:** None Required
**Source:** WDH
**Properties:**
**Value:** Varies
**Weight:** 8 lb.

**Description:** The stilts take 1 minute to put on or remove. They increase the height of any humanoid wearing them by 2 to 5 feet. Each stilt weighs 8 pounds and is 1 foot long when fully collapsed.



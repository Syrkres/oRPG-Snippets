---
cssclass: oRPGPage
fileType: item
itemType: mount
name: draft_horse
source: phb
rarity: none
attunement: none_required
value: 50_gp
weight: varies
properties: speed:_40_carrying_capacity:_540_lb.
---
> [!oRPG-Item]
> # Draft Horse
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | mount |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| Varies |
>  |**Properties** | Speed: 40, Carrying Capacity: 540 lb. |
> | **Source** | PHB |

#  Draft Horse
**Type:** mount

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** Speed: 40, Carrying Capacity: 540 lb.
**Value:** 50 gp
**Weight:** Varies

**Description:**



---
cssclass: oRPGPage
fileType: item
itemType: ammunition_futuristic
name: energy_cell
source: dmg
rarity: none
attunement: none_required
value: varies
weight: 5_oz.
properties:
---
> [!oRPG-Item]
> # Energy Cell
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition, futuristic |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 5 oz. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Energy Cell
**Type:** ammunition, futuristic

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 5 oz.

**Description:**



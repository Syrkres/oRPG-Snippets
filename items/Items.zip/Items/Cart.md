---
cssclass: oRPGPage
fileType: item
itemType: vehicle_(land)
name: cart
source: phb
rarity: none
attunement: none_required
value: 15_gp
weight: 200_lb.
properties:
---
> [!oRPG-Item]
> # Cart
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | vehicle (land) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 15 gp |
>  | **Weight**| 200 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Cart
**Type:** vehicle (land)

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 15 gp
**Weight:** 200 lb.

**Description:**



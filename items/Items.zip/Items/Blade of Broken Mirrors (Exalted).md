---
cssclass: oRPGPage
fileType: item
itemType: weapon_(dagger)_simple_weapon_melee_weapon
name: blade_of_broken_mirrors_(exalted)
source: egw
rarity: artifact
attunement: requires_attunement_by_a_humanoid
value: varies
weight: 1_lb.
properties: 1d4_piercing_-_finesse_light_thrown_(20&#x2F;60_ft.)
---
> [!oRPG-Item]
> # Blade of Broken Mirrors (Exalted)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (dagger), simple weapon, melee weapon |
> |**Rarity** | Artifact |
> | **Attunement** | Requires Attunement By A Humanoid |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** | 1d4, piercing, - finesse, light, thrown (20&#x2F;60 ft.) |
> | **Source** | EGW |

#  Blade of Broken Mirrors (Exalted)
**Type:** weapon (dagger), simple weapon, melee weapon

**Rarity:** Artifact
**Attunement:** Requires Attunement By A Humanoid
**Source:** EGW
**Properties:** 1d4, piercing, - finesse, light, thrown (20&#x2F;60 ft.)
**Value:** Varies
**Weight:** 1 lb.

**Description:** A weapon of Tharizdun, this dagger is a piece of jagged stone whose blade is scribed with a maze-like pattern with no beginning or end. Sentience. The Blade of Broken Mirrors is a sentient chaotic evil weapon with an Intelligence of 21, a Wisdom of 24, and a Charisma of 24. It has hearing and darkvision out to a range of 120 feet.The weapon communicates telepathically with its wielder and can speak, read, and understand Abyssal and Common. Personality. An insane glabrezu named Ragazuu lives within the Blade of Broken Mirrors. The weapon yearns to cause chaos. It learns its wielder&#39;s principles, then uses those ideals to encourage reckless action. The dagger whispers ideas of revolution. Dormant. The dagger grants the following benefits in its dormant state:You can speak, read, and write Abyssal.You gain a +1 bonus to attack and damage rolls made with this magic weapon. Immediately after you make a ranged attack with this weapon, it returns to your hand.Whenever you kill a humanoid with an attack using the Blade of Broken Mirrors, the blade remembers the creature&#39;s appearance. While holding the dagger, you can use an action to change your form to match any humanoid the blade remembers. Your statistics, other than your size, don&#39;t change. Any equipment you are wearing or carrying isn&#39;t transformed. You can revert to your true appearance as an action. You revert to your true appearance automatically when you die. When the Blade of Broken Mirrors attunes to a new wielder, the appearances of humanoids it has killed are wiped from its memory. Awakened. When the dagger reaches an awakened state, it gains the following properties:The weapon&#39;s bonus to attack and damage rolls increases to +2.While holding the weapon, you can use an action to cast one of the following spells from it (save DC 15): fabricate, hallucinatory terrain, major image, or phantasmal killer. Once a spell has been cast using the dagger, that spell can&#39;t be cast from the dagger again until the next dawn. Exalted. When the dagger reaches an exalted state, it gains the following properties:The weapon&#39;s bonus to attack and damage rolls increases to +3.The saving throw DC for spells cast from the dagger increases to 17.While holding the dagger, you can turn invisible as an action. Anything you are wearing or carrying is invisible with you. You remain invisible until you stop holding the dagger, until you attack or cast a spell that forces a creature to make a saving throw, or until you use a bonus action to become visible again.Betrayer Artifact Properties[–]The Arms of the Betrayers advance in power in the same manner as the Vestiges of Divergence. In its dormant state, each of these artifacts has one minor beneficial property and one minor detrimental property. When the artifact attains an awakened state, it gains an additional minor beneficial property and an additional minor detrimental property. When the item reaches its exalted state, it gains a major beneficial property. See &quot;Artifact Properties&quot; in chapter 7 of the Dungeon Master&#39;s Guide for more information. Finesse. When making an attack with a finesse weapon, you use your choice of your Strength or Dexterity modifier for the attack and damage rolls. You must use the same modifier for both rolls. Light. A light weapon is small and easy to handle, making it ideal for use when fighting with two weapons. Thrown. If a weapon has the thrown property, you can throw the weapon to make a ranged attack. If the weapon is a melee weapon, you use the same ability modifier for that attack roll and damage roll that you would use for a melee attack with the weapon. For example, if you throw a handaxe, you use your Strength, but if you throw a dagger, you can use either your Strength or your Dexterity, since the dagger has the finesse property.



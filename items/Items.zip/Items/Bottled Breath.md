---
cssclass: oRPGPage
fileType: item
itemType: potion
name: bottled_breath
source: pota
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Bottled Breath
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | potion |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PotA |

#  Bottled Breath
**Type:** potion

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** PotA
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This bottle contains a breath of elemental air. When you inhale it, you either exhale it or hold it.If you exhale the breath, you gain the effect of the gust of wind spell. If you hold the breath, you don&#39;t need to breathe for 1 hour, though you can end this benefit early (for example, to speak). Ending it early doesn&#39;t give you the benefit of exhaling the breath.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: amulet_of_the_black_skull
source: toa
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Amulet of the Black Skull
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | ToA |

#  Amulet of the Black Skull
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** ToA
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This amulet is carved from obsidian and shaped like a screaming humanoid skull, with ruby eyes and emeralds for teeth. It hangs from an iron chain necklace.The amulet has 6 charges and regains 1d6 charges daily at dawn. While wearing the amulet, you can use an action to expend 1 of its charges to transport yourself and anything you are wearing or carrying to a location within 100 feet of you. The destination you choose doesn&#39;t need to be in your line of sight, but it must be familiar to you (in other words, a place you have seen or visited), and it must be on the same plane of existence as you. This effect isn&#39;t subject to the magic restrictions placed on the Tomb of the Nine Gods; thus, the amulet can be used to enter and exit the tomb.If you aren&#39;t undead, you must make a DC 16 Constitution saving throw each time you use the amulet to teleport. On a failed saving throw, the black skull cackles as you are transformed in transit. The transformation takes effect as soon as you arrive at the destination, and is determined randomly by rolling percentile dice and consulting the Black Skull Transformation table.Black Skull Transformationd100Transformation01-20The symbol of Acererak is burned into your flesh, a curse that can only be removed with a remove curse spell or similar magic. Until the curse ends, your hit points can&#39;t be restored by magic.21-35You grow larger as if affected by an enlarge&#x2F;reduce spell, except the effect lasts for 1 hour.36-50You grow smaller as if affected by an enlarge&#x2F;reduce spell, except the effect lasts for 1 hour.51-70You arrive at the destination wearing nothing but the amulet of the black skull. Everything else that you were wearing or carrying appears in a random unoccupied space within 100 feet of you.71-95You are paralyzed for 1 minute or until this effect is ended with a lesser restoration spell or similar magic.96-00You become petrified. This effect can be ended only with a greater restoration spell or similar magic.



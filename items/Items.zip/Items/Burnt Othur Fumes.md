---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear_poison_(inhaled)
name: burnt_othur_fumes
source: dmg
rarity: none
attunement: none_required
value: 500_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Burnt Othur Fumes
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear, poison (inhaled) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Burnt Othur Fumes
**Type:** adventuring gear, poison (inhaled)

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 500 gp
**Weight:** Varies

**Description:** A creature subjected to this poison must succeed on a DC 13 Constitution saving throw or take 10 (3d6) poison damage, and must repeat the saving throw at the start of each of its turns. On each successive failed save, the character takes 3 (1d6) poison damage. After three successful saves, the poison ends.



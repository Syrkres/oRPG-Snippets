---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: azurite
source: dmg
rarity: none
attunement: none_required
value: 10_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Azurite
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Azurite
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 10 gp
**Weight:** Varies

**Description:** An opaque mottled deep blue gemstone.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: dragon_vessel
source: ftd
rarity: varies
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dragon Vessel
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Varies |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  Dragon Vessel
**Type:** wondrous item

**Rarity:** Varies
**Attunement:** Requires Attunement
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This vessel can be a potion bottle, drinking horn, or other container meant to hold a liquid.Multiple variations of this item exist, as listed below:Slumbering Dragon VesselStirring Dragon VesselWakened Dragon VesselAscendant Dragon Vessel



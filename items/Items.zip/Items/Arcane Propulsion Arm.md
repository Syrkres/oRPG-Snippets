---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: arcane_propulsion_arm
source: erlw
rarity: very_rare
attunement: requires_attunement_by_a_creature_missing_a_hand_or_an_arm
value: varies
weight: varies
properties: 1d8_force_-_thrown_(20&#x2F;60_ft.)
---
> [!oRPG-Item]
> # Arcane Propulsion Arm
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement By A Creature Missing A Hand Or An Arm |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** | 1d8, force, - thrown (20&#x2F;60 ft.) |
> | **Source** | ERLW |

#  Arcane Propulsion Arm
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement By A Creature Missing A Hand Or An Arm
**Source:** ERLW
**Properties:** 1d8, force, - thrown (20&#x2F;60 ft.)
**Value:** Varies
**Weight:** Varies

**Description:** This prosthetic appendage was developed by artificers of House Cannith. To attune to this item, you must attach it to your arm at the wrist, elbow, or shoulder, at which point the prosthetic magically forms a copy of the appendage it&#39;s replacing.While attached, the prosthetic provides these benefits:The prosthetic is a fully capable part of your body.You can take an action to remove the prosthetic, and it removes itself if your attunement to it ends. It can&#39;t be removed against your will.The prosthetic is a magic melee weapon with which you&#39;re proficient. It deals 1d8 force damage on a hit and has the thrown property, with a normal range of 20 feet and a long range of 60 feet. When thrown, the prosthetic detaches and flies at the target of the attack, then immediately returns to you and reattaches. Thrown. If a weapon has the thrown property, you can throw the weapon to make a ranged attack. If the weapon is a melee weapon, you use the same ability modifier for that attack roll and damage roll that you would use for a melee attack with the weapon. For example, if you throw a handaxe, you use your Strength, but if you throw a dagger, you can use either your Strength or your Dexterity, since the dagger has the finesse property.



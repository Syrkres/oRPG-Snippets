---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: diplomats_pack
source: phb
rarity: none
attunement: none_required
value: 39_gp
weight: 36_lb.
properties:
---
> [!oRPG-Item]
> # Diplomat&#39;s Pack
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 39 gp |
>  | **Weight**| 36 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Diplomat&#39;s Pack
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 39 gp
**Weight:** 36 lb.

**Description:** Includes:a chest2 cases for maps and scrollsa set of fine clothesa bottle of inkan ink pena lamp2 flasks of oil5 sheets of papera vial of perfumesealing waxsoap



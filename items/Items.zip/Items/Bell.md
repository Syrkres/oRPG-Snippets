---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: bell
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Bell
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Bell
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** Varies

**Description:**



---
cssclass: oRPGPage
fileType: item
itemType: ammunition_generic_variant
name: +3_ammunition
source: dmg
rarity: very_rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +3 Ammunition
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition, generic variant |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +3 Ammunition
**Type:** ammunition, generic variant

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +3 bonus to attack and damage rolls made with this piece of magic ammunition. Once it hits a target, the ammunition is no longer magical. Base items. This item variant can be applied to the following base items:Arrow (+3 Arrow)Blowgun Needle (+3 Blowgun Needle)Crossbow Bolt (+3 Crossbow Bolt)Energy Cell (+3 Energy Cell)Modern Bullet (+3 Modern Bullet)Renaissance Bullet (+3 Renaissance Bullet)Sling Bullet (+3 Sling Bullet)



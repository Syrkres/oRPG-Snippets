---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: alchemy_jug
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: 12_lb.
properties:
---
> [!oRPG-Item]
> # Alchemy Jug
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 12 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Alchemy Jug
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 12 lb.

**Description:** This ceramic jug appears to be able to hold a gallon of liquid and weighs 12 pounds whether full or empty. Sloshing sounds can be heard from within the jug when it is shaken, even if the jug is empty.You can use an action and name one liquid from the table below to cause the jug to produce the chosen liquid. Afterward, you can uncork the jug as an action and pour that liquid out, up to 2 gallons per minute. The maximum amount of liquid the jug can produce depends on the liquid you named.Once the jug starts producing a liquid, it can&#39;t produce a different one, or more of one that has reached its maximum, until the next dawn.LiquidMax AmountAcid8 ouncesBasic poison½ ounceBeer4 gallonsHoney1 gallonMayonnaise2 gallonsOil1 quartVinegar2 gallonsWater, fresh8 gallonsWater, salt12 gallonsWine1 gallon



---
cssclass: oRPGPage
fileType: item
itemType: ammunition
name: blowgun_needle
source: phb
rarity: none
attunement: none_required
value: 2_cp
weight: 0.32_oz.
properties:
---
> [!oRPG-Item]
> # Blowgun Needle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 cp |
>  | **Weight**| 0.32 oz. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Blowgun Needle
**Type:** ammunition

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 2 cp
**Weight:** 0.32 oz.

**Description:**



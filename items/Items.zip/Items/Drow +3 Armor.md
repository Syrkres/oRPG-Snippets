---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: drow_+3_armor
source: mm
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Drow +3 Armor
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | MM |

#  Drow +3 Armor
**Type:** generic variant

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** MM
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +3 bonus to AC while wearing this armor. This armor loses its enchantment bonus permanently if it is exposed to sunlight for 1 hour or longer. Base items. This item variant can be applied to the following base items:Breastplate (Drow +3 Breastplate)Chain Mail (Drow +3 Chain Mail)Chain Shirt (Drow +3 Chain Shirt)Half Plate Armor (Drow +3 Half Plate Armor)Hide Armor (Drow +3 Hide Armor)Leather Armor (Drow +3 Leather Armor)Padded Armor (Drow +3 Padded Armor)Plate Armor (Drow +3 Plate Armor)Ring Mail (Drow +3 Ring Mail)Scale Mail (Drow +3 Scale Mail)Spiked Armor (Drow +3 Spiked Armor)Splint Armor (Drow +3 Splint Armor)Studded Leather Armor (Drow +3 Studded Leather Armor)



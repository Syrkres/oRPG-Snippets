---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: ear_horn_of_hearing
source: xge
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Ear Horn of Hearing
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Ear Horn of Hearing
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While held up to your ear, this horn suppresses the effects of the deafened condition on you, allowing you to hear normally.



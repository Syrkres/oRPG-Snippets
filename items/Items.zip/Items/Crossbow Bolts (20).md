---
cssclass: oRPGPage
fileType: item
itemType: ammunition
name: crossbow_bolts_(20)
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: 1½_lb.
properties:
---
> [!oRPG-Item]
> # Crossbow Bolts (20)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 1½ lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Crossbow Bolts (20)
**Type:** ammunition

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** 1½ lb.

**Description:**



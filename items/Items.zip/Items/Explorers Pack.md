---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: explorers_pack
source: phb
rarity: none
attunement: none_required
value: 10_gp
weight: 59_lb.
properties:
---
> [!oRPG-Item]
> # Explorer&#39;s Pack
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| 59 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Explorer&#39;s Pack
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 10 gp
**Weight:** 59 lb.

**Description:** Includes:a backpacka bedrolla mess kita tinderbox10 torches10 days of rationsa waterskin50 feet of hempen rope



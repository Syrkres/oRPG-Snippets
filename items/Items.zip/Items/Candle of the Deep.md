---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: candle_of_the_deep
source: xge
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Candle of the Deep
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Candle of the Deep
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** The flame of this candle is not extinguished when immersed in water. It gives off light and heat like a normal candle.



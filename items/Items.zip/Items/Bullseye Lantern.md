---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: bullseye_lantern
source: phb
rarity: none
attunement: none_required
value: 10_gp
weight: 2_lb.
properties:
---
> [!oRPG-Item]
> # Bullseye Lantern
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| 2 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Bullseye Lantern
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 10 gp
**Weight:** 2 lb.

**Description:** A bullseye lantern casts bright light in a 60-foot cone and dim light for an additional 60 feet. Once lit, it burns for 6 hours on a flask (1 pint) of oil.



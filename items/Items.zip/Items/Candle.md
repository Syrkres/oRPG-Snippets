---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: candle
source: phb
rarity: none
attunement: none_required
value: 1_cp
weight: varies
properties:
---
> [!oRPG-Item]
> # Candle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 cp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Candle
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 cp
**Weight:** Varies

**Description:** For 1 hour, a candle sheds bright light in a 5-foot radius and dim light for an additional 5 feet.



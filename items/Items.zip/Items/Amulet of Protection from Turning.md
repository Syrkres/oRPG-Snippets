---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: amulet_of_protection_from_turning
source: tftyp
rarity: rare
attunement: requires_attunement
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Amulet of Protection from Turning
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | TftYP |

#  Amulet of Protection from Turning
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** TftYP
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** While you wear this amulet of silver and turquoise, you have advantage on saving throws against effects that turn undead.If you fail a saving throw against such an effect, you can choose to succeed instead. You can do so three times, and expended uses recharge daily at dawn. Each time an effect that turns undead is used against you, the amulet glows with silvery blue light for a few seconds.



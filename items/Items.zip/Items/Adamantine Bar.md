---
cssclass: oRPGPage
fileType: item
itemType: trade_good
name: adamantine_bar
source: wdh
rarity: none
attunement: none_required
value: 1000_gp
weight: 10_lb.
properties:
---
> [!oRPG-Item]
> # Adamantine Bar
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Trade Good |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1,000 gp |
>  | **Weight**| 10 lb. |
>  |**Properties** |  |
> | **Source** | WDH |

#  Adamantine Bar
**Type:** Trade Good

**Rarity:** None
**Attunement:** None Required
**Source:** WDH
**Properties:**
**Value:** 1,000 gp
**Weight:** 10 lb.

**Description:** Most wealth is not in coins. It is measured in livestock, grain, land, rights to collect taxes, or rights to resources (such as a mine or a forest).Guilds, nobles, and royalty regulate trade. Chartered companies are granted rights to conduct trade along certain routes, to send merchant ships to various ports, or to buy or sell specific goods. Guilds set prices for the goods or services that they control, and determine who may or may not offer those goods and services. Merchants commonly exchange trade goods without using currency.



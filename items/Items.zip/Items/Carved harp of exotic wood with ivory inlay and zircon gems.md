---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: carved_harp_of_exotic_wood_with_ivory_inlay_and_zircon_gems
source: dmg
rarity: none
attunement: none_required
value: 750_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Carved harp of exotic wood with ivory inlay and zircon gems
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 750 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Carved harp of exotic wood with ivory inlay and zircon gems
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 750 gp
**Weight:** Varies

**Description:**



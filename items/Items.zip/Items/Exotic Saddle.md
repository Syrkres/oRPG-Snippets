---
cssclass: oRPGPage
fileType: item
itemType: tack_and_harness
name: exotic_saddle
source: phb
rarity: none
attunement: none_required
value: 60_gp
weight: 40_lb.
properties:
---
> [!oRPG-Item]
> # Exotic Saddle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | tack and harness |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 60 gp |
>  | **Weight**| 40 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Exotic Saddle
**Type:** tack and harness

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 60 gp
**Weight:** 40 lb.

**Description:** An exotic saddle is required for riding any aquatic or flying mount.



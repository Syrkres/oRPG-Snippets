---
cssclass: oRPGPage
fileType: item
itemType: weapon_range_firearm_futuristic_martial_weapon
name: antimatter_rifle
source: dmg
rarity: none
attunement: none_required
value: varies
weight: 10_lb.
properties: 6d8_necrotic_-_ammunition_(120&#x2F;360_ft.)_reload_(2_shots)_two-handed
---
> [!oRPG-Item]
> # Antimatter Rifle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon, range, firearm, futuristic, martial weapon |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 10 lb. |
>  |**Properties** | 6d8, necrotic, - ammunition (120&#x2F;360 ft.), reload (2 shots), two-handed |
> | **Source** | DMG |

#  Antimatter Rifle
**Type:** weapon, range, firearm, futuristic, martial weapon

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:** 6d8, necrotic, - ammunition (120&#x2F;360 ft.), reload (2 shots), two-handed
**Value:** Varies
**Weight:** 10 lb.

**Description:**  Range. A weapon that can be used to make a ranged attack has a range shown in parentheses after the ammunition or thrown property. The range lists two numbers. The first is the weapon&#39;s normal range in feet, and the second indicates the weapon&#39;s maximum range. When attacking a target beyond normal range, you have disadvantage on the attack roll. You can&#39;t attack a target beyond the weapon&#39;s long range. Ammunition. You can use a weapon that has the ammunition property to make a ranged attack only if you have ammunition to fire from the weapon. Each time you attack with the weapon, you expend one piece of ammunition. Drawing the ammunition from a quiver, case, or other container is part of the attack. Loading a one-handed weapon requires a free hand. The ammunition of a firearm is destroyed upon use.If you use a weapon that has the ammunition property to make a melee attack, you treat the weapon as an improvised weapon. A sling must be loaded to deal any damage when used in this way. Reload. A limited number of shots can be made with a weapon that has the reload property. A character must then reload it using an action or a bonus action (the character&#39;s choice). Two-Handed. This weapon requires two hands to use. This property is relevant only when you attack with the weapon, not when you simply hold it.



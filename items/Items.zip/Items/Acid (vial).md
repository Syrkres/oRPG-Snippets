---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: acid_(vial)
source: phb
rarity: none
attunement: none_required
value: 25_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Acid (vial)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 25 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Acid (vial)
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 25 gp
**Weight:** 1 lb.

**Description:** As an action, you can splash the contents of this vial onto a creature within 5 feet of you or throw the vial up to 20 feet, shattering it on impact. In either case, make a ranged attack against a creature or object, treating the acid as an improvised weapon. On a hit, the target takes 2d6 acid damage.



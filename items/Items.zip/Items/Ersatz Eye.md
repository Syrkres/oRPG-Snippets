---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: ersatz_eye
source: xge
rarity: common
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Ersatz Eye
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Ersatz Eye
**Type:** wondrous item

**Rarity:** Common
**Attunement:** Requires Attunement
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This artificial eye replaces a real one that was lost or removed. While the ersatz eye is embedded in your eye socket, it can&#39;t be removed by anyone other than you, and you can see through the tiny orb as though it were a normal eye.



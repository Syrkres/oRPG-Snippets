---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: +1_all-purpose_tool
source: tce
rarity: uncommon
attunement: requires_attunement_by_an_artificer
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +1 All-Purpose Tool
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement By An Artificer |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | TCE |

#  +1 All-Purpose Tool
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement By An Artificer
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This simple screwdriver can transform into a variety of tools; as an action, you can touch the item and transform it into any type of artisan&#39;s tool of your choice (see the &quot;Equipment&quot; chapter in the Player&#39;s Handbook for a list of artisan&#39;s tools). Whatever form the tool takes, you are proficient with it.While holding this tool, you gain a +1 bonus to the spell attack rolls and the saving throw DCs of your artificer spells.As an action, you can focus on the tool to channel your creative forces. Choose a cantrip that you don&#39;t know from any class list. For 8 hours, you can cast that cantrip, and it counts as an artificer cantrip for you. Once this property is used, it can&#39;t be used again until the next dawn.



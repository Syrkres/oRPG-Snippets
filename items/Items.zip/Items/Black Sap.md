---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: black_sap
source: egw
rarity: none
attunement: none_required
value: 300_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Black Sap
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 300 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Black Sap
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** EGW
**Properties:**
**Value:** 300 gp
**Weight:** Varies

**Description:** This tarry substance harvested from the dark boughs of the death&#39;s head willow is a powerful intoxicant. It can be smoked as a concentrate or injected directly into the bloodstream. A creature subjected to a dose of black sap cannot be charmed or frightened for 1d6 hours.For each dose of black sap consumed, a creature must succeed on a DC 15 Constitution saving throw or become poisoned for 2d4 hours—an effect that is cumulative with multiple doses.



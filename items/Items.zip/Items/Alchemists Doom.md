---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: alchemists_doom
source: scc
rarity: unknown
attunement: none_required
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Alchemist&#39;s Doom
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | Unknown |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | SCC |

#  Alchemist&#39;s Doom
**Type:** adventuring gear

**Rarity:** Unknown
**Attunement:** None Required
**Source:** SCC
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This sticky, adhesive fluid ignites when exposed to air. As an action, you can throw this flask up to 20 feet, shattering it on impact. Make a ranged attack against a creature or object, treating the alchemist&#39;s doom as an improvised weapon. On a hit, the target takes 7 (2d6) fire damage at the start of each of its turns. A creature can end this damage by using its action to make a DC 10 Dexterity check to extinguish the flames.



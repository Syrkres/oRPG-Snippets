---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_radiant_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Radiant Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Radiant Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to radiant damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Radiant Resistance)Chain Mail (Chain Mail of Radiant Resistance)Chain Shirt (Chain Shirt of Radiant Resistance)Half Plate Armor (Half Plate Armor of Radiant Resistance)Hide Armor (Hide Armor of Radiant Resistance)Leather Armor (Leather Armor of Radiant Resistance)Padded Armor (Padded Armor of Radiant Resistance)Plate Armor (Plate Armor of Radiant Resistance)Ring Mail (Ring Mail of Radiant Resistance)Scale Mail (Scale Mail of Radiant Resistance)Spiked Armor (Spiked Armor of Radiant Resistance)Splint Armor (Splint Armor of Radiant Resistance)Studded Leather Armor (Studded Leather Armor of Radiant Resistance)



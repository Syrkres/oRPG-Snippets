---
cssclass: oRPGPage
fileType: item
itemType: other
name: clockwork_dog
source: skt
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Clockwork Dog
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | SKT |

#  Clockwork Dog
**Type:** other

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** SKT
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This Tiny clockwork dog made of copper and tin comes with a copper wind-up key. As an action, you can use the key to wind the dog, after which it follows you for 12 hours. At the end of that duration, the clockwork dog stops until wound again. The dog has AC 5, 1 hit point, and a walking speed of 30 feet.



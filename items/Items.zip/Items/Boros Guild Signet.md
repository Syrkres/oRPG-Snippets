---
cssclass: oRPGPage
fileType: item
itemType: ring
name: boros_guild_signet
source: ggr
rarity: uncommon
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Boros Guild Signet
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ring |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | GGR |

#  Boros Guild Signet
**Type:** ring

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** GGR
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This ring, adorned with the symbol of Boros, allows you to cast heroism. A guild signet is sometimes awarded to a guild member whose renown score in that guild is 5 or higher, as a reward for performing special services for the guild. Aside from its magical properties, the ring is also an indicator of Boros&#39; recognition and favor.A signet has 3 charges, and it regains 1d3 expended charges daily at dawn. While wearing it, you can expend 1 charge to cast the associated spell (save DC 13).



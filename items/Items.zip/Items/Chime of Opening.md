---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: chime_of_opening
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Chime of Opening
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | 3,000 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Chime of Opening
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This hollow metal tube measures about 1 foot long and weighs 1 pound. You can strike it as an action, pointing it at an object within 120 feet of you that can be opened, such as a door, lid, or lock. The chime issues a clear tone, and one lock or latch on the object opens unless the sound can&#39;t reach the object. If no locks or latches remain, the object itself opens.The chime can be used ten times. After the tenth time it cracks and becomes useless.



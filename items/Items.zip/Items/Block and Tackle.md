---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: block_and_tackle
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: 5_lb.
properties:
---
> [!oRPG-Item]
> # Block and Tackle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 5 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Block and Tackle
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** 5 lb.

**Description:** A set of pulleys with a cable threaded through them and a hook to attach to objects, a block and tackle allows you to hoist up to four times the weight you can normally lift.



---
cssclass: oRPGPage
fileType: item
itemType: medium_armor
name: copper_dragon_scale_mail
source: dmg
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 45_lb.
properties: ac_14_+_dex_(max_2)
---
> [!oRPG-Item]
> # Copper Dragon Scale Mail
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | medium armor |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 45 lb. |
>  |**Properties** | AC 14 + Dex (max 2) |
> | **Source** | DMG |

#  Copper Dragon Scale Mail
**Type:** medium armor

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:** AC 14 + Dex (max 2)
**Value:** Varies
**Weight:** 45 lb.

**Description:** Dragon scale mail is made of the scales of one kind of dragon. Sometimes dragons collect their cast-off scales and gift them to humanoids. Other times, hunters carefully skin and preserve the hide of a dead dragon. In either case, dragon scale mail is highly valued. While wearing this armor, you gain a +1 bonus to AC, you have advantage on saving throws against the Frightful Presence and breath weapons of dragons, and you have resistance to acid damage.Additionally, you can focus your senses as an action to magically discern the distance and direction to the closest copper dragon within 30 miles of you. This special action can&#39;t be used again until the next dawn.The wearer has disadvantage on Dexterity (Stealth) checks.



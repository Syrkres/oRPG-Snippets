---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: explosive_seed
source: egw
rarity: none
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Explosive Seed
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Explosive Seed
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This acorn-sized sphere of brass contains a small amount of blasting powder and a clockwork trigger. An explosive seed can be thrown up to 30 feet as an action, detonating on impact. Each creature within 5 feet of the exploding seed must make a DC 10 Dexterity saving throw, taking 1d8 bludgeoning damage on a failed save, or half as much damage on a successful one.



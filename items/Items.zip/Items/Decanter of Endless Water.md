---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: decanter_of_endless_water
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: 2_lb.
properties:
---
> [!oRPG-Item]
> # Decanter of Endless Water
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | 9,000 gp |
>  | **Weight**| 2 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Decanter of Endless Water
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 2 lb.

**Description:** This stoppered flask sloshes when shaken, as if it contains water. The decanter weighs 2 pounds.You can use an action to remove the stopper and speak one of three command words, whereupon an amount of fresh water or salt water (your choice) pours out of the flask. The water stops pouring out at the start of your next turn. Choose from the following options:&quot;Stream&quot; produces 1 gallon of water.&quot;Fountain&quot; produces 5 gallons of water.&quot;Geyser&quot; produces 30 gallons of water that gushes forth in a geyser 30 feet long and 1 foot wide. As a bonus action while holding the decanter, you can aim the geyser at a creature you can see within 30 feet of you. The target must succeed on a DC 13 Strength saving throw or take 1d4 bludgeoning damage and fall prone. Instead of a creature, you can target an object that isn&#39;t being worn or carried and that weighs no more than 200 pounds. The object is either knocked over or pushed up to 15 feet away from you.



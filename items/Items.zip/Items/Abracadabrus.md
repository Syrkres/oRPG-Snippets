---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: abracadabrus
source: idrotf
rarity: very_rare
attunement: none_required
value: varies
weight: 25_lb.
properties:
---
> [!oRPG-Item]
> # Abracadabrus
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 25 lb. |
>  |**Properties** |  |
> | **Source** | IDRotF |

#  Abracadabrus
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** IDRotF
**Properties:**
**Value:** Varies
**Weight:** 25 lb.

**Description:** An abracadabrus is an ornate, gemstone-studded wooden chest that weighs 25 pounds while empty. Its interior compartment is a cube measuring 1½ feet on a side.The chest has 20 charges. A creature can use an action to touch the closed lid of the chest and expend 1 of the chest&#39;s charges while naming one or more nonmagical objects (including raw materials, foodstuffs, and liquids) worth a total of 1 gp or less. The named objects magically appear in the chest, provided they can all fit inside it and the chest doesn&#39;t contain anything else. For example, the chest can conjure a plate of strawberries, a bowl of hot soup, a flagon of water, a stuffed animal, or a bag of twenty caltrops. Food and drink conjured by the chest are delicious, and they spoil if not consumed after 24 hours. Gems and precious metals created by the chest disappear after 1 minute.The chest regains 1d20 expended charges daily at dawn. If the item&#39;s last charge is expended, roll a d20. On a 1, the chest loses its magic (becoming an ordinary chest), and its gemstones turn to dust.



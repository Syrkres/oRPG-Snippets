---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: black_chromatic_rose
source: wbtw
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Black Chromatic Rose
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WBtW |

#  Black Chromatic Rose
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** WBtW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While this rose is held, it drips acid as a harmless visual effect.While holding the rose by its stem, you gain resistance to acid damage. If you would take more than 10 acid damage from a single source (after applying the resistance), the rose disintegrates, and you take no damage instead.As an action, you can blow the petals from the rose to produce a 20-foot cone of acid. Each creature in the cone must make a DC 15 Constitution saving throw, taking 3d10 acid damage on a failed save, or half as much damage on a successful one. Using this property destroys the rose.



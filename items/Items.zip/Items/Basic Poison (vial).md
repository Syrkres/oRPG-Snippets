---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear_poison
name: basic_poison_(vial)
source: phb
rarity: none
attunement: none_required
value: 100_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Basic Poison (vial)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear, poison |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 100 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Basic Poison (vial)
**Type:** adventuring gear, poison

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 100 gp
**Weight:** Varies

**Description:** You can use the poison in this vial to coat one slashing or piercing weapon or up to three pieces of ammunition. Applying the poison takes an action. A creature hit by the poisoned weapon or ammunition must make a DC 10 Constitution saving throw or take 1d4 poison damage. Once applied, the poison retains potency for 1 minute before drying.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: +1_amulet_of_the_devout
source: tce
rarity: uncommon
attunement: requires_attunement_by_a_cleric_or_paladin
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # +1 Amulet of the Devout
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement By A Cleric Or Paladin |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | TCE |

#  +1 Amulet of the Devout
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement By A Cleric Or Paladin
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This amulet bears the symbol of a deity inlaid with precious stones or metals. While you wear the holy symbol, you gain a +1 bonus to spell attack rolls and the saving throw DCs of your spells.While you wear this amulet, you can use your Channel Divinity feature without expending one of the feature&#39;s uses. Once this property is used, it can&#39;t be used again until the next dawn.



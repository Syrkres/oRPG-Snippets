---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: crowbar
source: phb
rarity: none
attunement: none_required
value: 2_gp
weight: 5_lb.
properties:
---
> [!oRPG-Item]
> # Crowbar
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 gp |
>  | **Weight**| 5 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Crowbar
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 2 gp
**Weight:** 5 lb.

**Description:** Using a crowbar grants advantage to Strength checks where the crowbar&#39;s leverage can be applied.



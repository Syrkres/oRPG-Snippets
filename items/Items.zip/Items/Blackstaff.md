---
cssclass: oRPGPage
fileType: item
itemType: staff_weapon_simple_weapon_melee_weapon
name: blackstaff
source: wdh
rarity: legendary
attunement: requires_attunement_by_the_blackstaff_heir,_who_must_be_a_wizard
value: varies
weight: 4_lb.
properties: 1d6_bludgeoning_-_versatile_(1d8)
---
> [!oRPG-Item]
> # Blackstaff
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | staff, weapon, simple weapon, melee weapon |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement By The Blackstaff Heir, Who Must Be A Wizard |
> | **Value** | Varies |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d6, bludgeoning, - versatile (1d8) |
> | **Source** | WDH |

#  Blackstaff
**Type:** staff, weapon, simple weapon, melee weapon

**Rarity:** Legendary
**Attunement:** Requires Attunement By The Blackstaff Heir, Who Must Be A Wizard
**Source:** WDH
**Properties:** 1d6, bludgeoning, - versatile (1d8)
**Value:** Varies
**Weight:** 4 lb.

**Description:** The Blackstaff is a sentient, rune-carved staff set with thin silver veins. It is the symbol of office for the Blackstaff, the highest-ranking wizard in Waterdeep. As the rightful owner of the Blackstaff, Vajra Safahr is the only one who can become attuned to it. The staff can, however, choose a new owner (see &quot;Personality&quot; below).This staff can be wielded as a magic quarterstaff that grants a +2 bonus to attack and damage rolls made with it. While holding it, you gain a +2 bonus to Armor Class, saving throws, and spell attack rolls.The staff has 20 charges for the following properties. The staff regains 2d8 + 4 expended charges daily at dawn. If you expend the last charge, roll a d20. On a 1, the staff retains its +2 bonus to attack and damage roll but loses all other properties. On a 20, the staff regain 1d8 + 2 charges. Power Strike. When you hit with a melee attack using the staff, you can expend 1 charge to deal an extra 1d6 force damage to the target. Spells. While holding this staff, you can use an action to expend 1 or more of its charges to cast one of the following spells from it, using your spell save DC and spell attack bonus: cone of cold (5 charges), fireball (5th-level version, 5 charges), globe of invulnerability (6 charges), hold monster (5 charges), levitate (2 charges). lightning bolt (5th-level version, 5 charges), magic missile (1 charge), ray of enfeeblement (1 charge), or wall of force (5 charges). Retributive Strike. You can use an action to break the staff over your knee or against a solid surface, performing a retributive strike. The staff is destroyed and releases its remaining magic in an explosion that expands to fill a 30-foot-radius sphere centered on it.You have a 50 percent chance to instantly travel to a random plane of existence, avoiding the explosion. If you fail to avoid the effect, you take force damage equal to 16 × the number of charges in the staff. Every other creature in the area must make a DC 17 Dexterity saving throw. On a failed save, a creature takes an amount of damage based on how far away it is from the point of origin, as shown in the following table. On a successful save, a creature takes half as much damage.Distance from OriginEffect10 ft. away or closer8 × the number of charges in the staff11 to 20 ft. away6 × the number of charges in the staff21 to 30 ft. away4 × the number of charges in the staff Animate Walking Statues. You can expend 1 or more of the staff&#39;s charges as an action to animate or deactivate one or more of the walking statues of Waterdeep. You must be in the city to use this property, and you can animate or deactivate one statue for each charge expended. An animated statue obeys the telepathic commands of Khelben Arunsun&#39;s spirit, which is trapped inside the staff (see &quot;Personality&quot; below). A walking statue becomes inanimate if deactivated or if the staff is broken. Dispel Magic. You can expend 1 of the staff&#39;s charges as a bonus action to cast dispel magic on a creature, an object, or a magical effect that you touch with the tip of the staff. If the target is an unwilling creature or an object in the possession of such a creature, you must hit the creature with a melee attack using the Blackstaff before you can expend the charge to cast the spell. Drain Magic. This property affects only creatures that use spell slots. When you hit such a creature with a melee attack using the Blackstaff, you can expend 1 of the staff&#39;s charges as a bonus action, causing the target to expend one spell slot of the highest spell level it can cast without casting a spell. If the target has already expended all its spell slots, nothing happens. Spell slots that are expended in this fashion are regained when the target finishes a long rest, as normal. Master of Enchantment. When you cast an enchantment spell of 1st level or higher while holding the staff, you can make an Intelligence (Arcana) check with a DC of 10 + the level of the spell. If the check succeeds, you cast the spell without expending a spell slot. Sentience. The Blackstaff is a sentient staff of neutral alignment, with an Intelligence of 22, a Wisdom of 15, and a Charisma of 18. It has hearing and darkvision out to a range of 120 feet, and it can communicate telepathically with any creature that is holding it. Personality. The staff has the spirits of all previous Blackstaffs trapped within it. Its creator, Khelben Arunsun, is the dominant personality among them. Like Khelben, the staff is extremely devious and manipulative. It prefers to counsel its owner without exerting outright control. The staff&#39;s primary goal is to protect Waterdeep and its Open Lord, currently Laeral Silverhand. Its secondary goal is to help its wielder become more powerful.In the event that the holder of the office of the Blackstaff no longer serves the staff&#39;s wishes, the staff ceases to function until it finds a worthy inheritor—someone whose loyalty to Waterdeep is beyond reproach. Spirit Trap. When the Blackstaff dies, the spirit of that individual becomes trapped in the staff along with the spirits of the previous Blackstaffs. (A Blackstaff whose spirit is trapped in the staff can&#39;t be raised from the dead.)Destroying the staff would release the spirits trapped inside it, but in that event, Khelben&#39;s spirit can lodge itself inside any one piece of the staff that remains. The piece containing Khelben&#39;s spirit has the staff&#39;s Sentience property but none of its other properties. As long as this piece of the staff exists, Khelben&#39;s spirit can make the staff whole again whenever he wishes. When the staff is remade, the spirits of the previous Blackstaffs become trapped inside it again. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: amulet_of_the_planes
source: dmg
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Amulet of the Planes
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | 120,000 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Amulet of the Planes
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** While wearing this amulet, you can use an action to name a location that you are familiar with on another plane of existence. Then make a DC 15 Intelligence check. On a successful check, you cast the plane shift spell. On a failure, you and each creature and object within 15 feet of you travel to a random destination. Roll a d100. On a 1-60, you travel to a random location on the plane you named. On a 61-100, you travel to a randomly determined plane of existence.



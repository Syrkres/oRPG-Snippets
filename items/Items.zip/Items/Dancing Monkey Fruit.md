---
cssclass: oRPGPage
fileType: item
itemType: other
name: dancing_monkey_fruit
source: toa
rarity: unknown_(magic)
attunement: none_required
value: 5_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Dancing Monkey Fruit
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | 5 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ToA |

#  Dancing Monkey Fruit
**Type:** other

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** ToA
**Properties:**
**Value:** 5 gp
**Weight:** Varies

**Description:** This rare magical fruit produces enough juice to fill a vial. Any humanoid that eats a dancing monkey fruit or drinks its juice must succeed on a DC 14 Constitution saving throw or begin a comic dance that lasts for 1 minute. Humanoids that can&#39;t be poisoned are immune to this magical effect.The dancer must use all its movement to dance without leaving its space and has disadvantage on attack rolls and Dexterity saving throws, and other creatures have advantage on attack rolls against it. Each time it takes damage, the dancer can repeat the saving throw, ending the effect on itself on a success. When the dancing effect ends, the humanoid suffers the poisoned condition for 1 hour.



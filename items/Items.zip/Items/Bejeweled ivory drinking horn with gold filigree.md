---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: bejeweled_ivory_drinking_horn_with_gold_filigree
source: dmg
rarity: none
attunement: none_required
value: 7500_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Bejeweled ivory drinking horn with gold filigree
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 7,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Bejeweled ivory drinking horn with gold filigree
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 7,500 gp
**Weight:** Varies

**Description:**



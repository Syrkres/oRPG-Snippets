---
cssclass: oRPGPage
fileType: item
itemType: artisan&#39;s_tools
name: cooks_utensils
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: 8_lb.
properties:
---
> [!oRPG-Item]
> # Cook&#39;s Utensils
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Artisan&#39;s Tools |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 8 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Cook&#39;s Utensils
**Type:** Artisan&#39;s Tools

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** 8 lb.

**Description:** These special tools include the items needed to pursue a craft or trade. Proficiency with a set of artisan&#39;s tools lets you add your proficiency bonus to any ability checks you make using the tools in your craft. Each type of artisan&#39;s tools requires a separate proficiency.Adventuring is a hard life. With a cook along on the journey, your meals will be much better than the typical mix of hardtack and dried fruit. Components. Cook&#39;s utensils include a metal pot, knives, forks, a stirring spoon, and a ladle. History. Your knowledge of cooking techniques allows you to assess the social patterns involved in a culture&#39;s eating habits. Medicine. When administering treatment, you can transform medicine that is bitter or sour into a pleasing concoction. Survival. When foraging for food, you can make do with ingredients you scavenge that others would be unable to transform into nourishing meals. Prepare Meals. As part of a short rest, you can prepare a tasty meal that helps your companions regain their strength. You and up to five creatures of your choice regain 1 extra hit point per Hit Die spent during a short rest, provided you have access to your cook&#39;s utensils and sufficient food.Cook&#39;s UtensilsActivityDCCreate a typical meal10Duplicate a meal10Spot poison or impurities in food15Create a gourmet meal15See the Tool Proficiencies entry for more information.



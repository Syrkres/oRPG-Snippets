---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: entertainers_pack
source: phb
rarity: none
attunement: none_required
value: 40_gp
weight: 38_lb.
properties:
---
> [!oRPG-Item]
> # Entertainer&#39;s Pack
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 40 gp |
>  | **Weight**| 38 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Entertainer&#39;s Pack
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 40 gp
**Weight:** 38 lb.

**Description:** Includes:a backpacka bedroll2 costumes5 candles5 days of rationsa waterskina disguise kit



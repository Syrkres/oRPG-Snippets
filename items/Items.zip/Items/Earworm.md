---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: earworm
source: erlw
rarity: uncommon
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Earworm
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ERLW |

#  Earworm
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** ERLW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** To attune to this symbiont, you must hold it against the skin behind your ear for the entire attunement period, whereupon it burrows into your head and bonds to your skull. While the earworm is inside you, you can speak, read, and write Deep Speech. Spells. The earworm has 4 charges. You can cast the following spells from it, expending the necessary number of charges (spell save DC 15): detect thoughts (2 charges) or dissonant whispers (1 charge). Each time you use the earworm to cast the detect thoughts spell, it sends the information gleaned to the nearest daelkyr, or to the next nearest earworm until it reaches a daelkyr.The earworm regains 1d4 expended charges daily at dawn. Symbiotic Nature. The earworm can&#39;t be removed from you while you&#39;re attuned to it, and you can&#39;t voluntarily end your attunement to it. If you&#39;re targeted by a spell that ends a curse, your attunement to the earworm ends, and it exits your body.



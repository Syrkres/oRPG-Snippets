---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_lightning_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Lightning Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Lightning Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to lightning damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Lightning Resistance)Chain Mail (Chain Mail of Lightning Resistance)Chain Shirt (Chain Shirt of Lightning Resistance)Half Plate Armor (Half Plate Armor of Lightning Resistance)Hide Armor (Hide Armor of Lightning Resistance)Leather Armor (Leather Armor of Lightning Resistance)Padded Armor (Padded Armor of Lightning Resistance)Plate Armor (Plate Armor of Lightning Resistance)Ring Mail (Ring Mail of Lightning Resistance)Scale Mail (Scale Mail of Lightning Resistance)Spiked Armor (Spiked Armor of Lightning Resistance)Splint Armor (Splint Armor of Lightning Resistance)Studded Leather Armor (Studded Leather Armor of Lightning Resistance)



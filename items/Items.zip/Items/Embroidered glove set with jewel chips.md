---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: embroidered_glove_set_with_jewel_chips
source: dmg
rarity: none
attunement: none_required
value: 2500_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Embroidered glove set with jewel chips
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Embroidered glove set with jewel chips
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 2,500 gp
**Weight:** Varies

**Description:**



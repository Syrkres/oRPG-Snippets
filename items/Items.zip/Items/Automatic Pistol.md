---
cssclass: oRPGPage
fileType: item
itemType: weapon_range_firearm_modern_martial_weapon
name: automatic_pistol
source: dmg
rarity: none
attunement: none_required
value: varies
weight: 3_lb.
properties: 2d6_piercing_-_ammunition_(50&#x2F;150_ft.)_reload_(15_shots)
---
> [!oRPG-Item]
> # Automatic Pistol
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon, range, firearm, modern, martial weapon |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** | 2d6, piercing, - ammunition (50&#x2F;150 ft.), reload (15 shots) |
> | **Source** | DMG |

#  Automatic Pistol
**Type:** weapon, range, firearm, modern, martial weapon

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:** 2d6, piercing, - ammunition (50&#x2F;150 ft.), reload (15 shots)
**Value:** Varies
**Weight:** 3 lb.

**Description:**  Range. A weapon that can be used to make a ranged attack has a range shown in parentheses after the ammunition or thrown property. The range lists two numbers. The first is the weapon&#39;s normal range in feet, and the second indicates the weapon&#39;s maximum range. When attacking a target beyond normal range, you have disadvantage on the attack roll. You can&#39;t attack a target beyond the weapon&#39;s long range. Ammunition. You can use a weapon that has the ammunition property to make a ranged attack only if you have ammunition to fire from the weapon. Each time you attack with the weapon, you expend one piece of ammunition. Drawing the ammunition from a quiver, case, or other container is part of the attack. Loading a one-handed weapon requires a free hand. The ammunition of a firearm is destroyed upon use.If you use a weapon that has the ammunition property to make a melee attack, you treat the weapon as an improvised weapon. A sling must be loaded to deal any damage when used in this way. Reload. A limited number of shots can be made with a weapon that has the reload property. A character must then reload it using an action or a bonus action (the character&#39;s choice).



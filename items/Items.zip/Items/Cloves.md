---
cssclass: oRPGPage
fileType: item
itemType: trade_good
name: cloves
source: phb
rarity: none
attunement: none_required
value: 3_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Cloves
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Trade Good |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 3 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Cloves
**Type:** Trade Good

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 3 gp
**Weight:** 1 lb.

**Description:** Most wealth is not in coins. It is measured in livestock, grain, land, rights to collect taxes, or rights to resources (such as a mine or a forest).Guilds, nobles, and royalty regulate trade. Chartered companies are granted rights to conduct trade along certain routes, to send merchant ships to various ports, or to buy or sell specific goods. Guilds set prices for the goods or services that they control, and determine who may or may not offer those goods and services. Merchants commonly exchange trade goods without using currency.



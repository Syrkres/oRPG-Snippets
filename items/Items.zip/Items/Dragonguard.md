---
cssclass: oRPGPage
fileType: item
itemType: medium_armor
name: dragonguard
source: lmop
rarity: rare
attunement: none_required
value: varies
weight: 20_lb.
properties: ac_14_+_dex_(max_2)
---
> [!oRPG-Item]
> # Dragonguard
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | medium armor |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 20 lb. |
>  |**Properties** | AC 14 + Dex (max 2) |
> | **Source** | LMoP |

#  Dragonguard
**Type:** medium armor

**Rarity:** Rare
**Attunement:** None Required
**Source:** LMoP
**Properties:** AC 14 + Dex (max 2)
**Value:** Varies
**Weight:** 20 lb.

**Description:** You have a +1 bonus to AC while wearing this armor.This +1 breastplate has a gold dragon motif worked into its design. Created for a human hero of Neverwinter named Tergon, it grants its wearer advantage on saving throws against the breath weapons of creatures that have the dragon type.



---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +3_shield_(*)
source: dmg
rarity: very_rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +3 Shield (*)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +3 Shield (*)
**Type:** generic variant

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** * This generic variant has the same name and source as the item +3 shield.While holding this shield, you have a +3 bonus to AC. This bonus is in addition to the shield&#39;s normal bonus to AC. Base items. This item variant can be applied to the following base items:Shield (+3 Shield)



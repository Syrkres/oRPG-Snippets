---
cssclass: oRPGPage
fileType: item
itemType: weapon_(greataxe)_martial_weapon_melee_weapon
name: bloodaxe
source: egw
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 7_lb.
properties: 1d12_slashing_-_heavy_two-handed
---
> [!oRPG-Item]
> # Bloodaxe
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (greataxe), martial weapon, melee weapon |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 7 lb. |
>  |**Properties** | 1d12, slashing, - heavy, two-handed |
> | **Source** | EGW |

#  Bloodaxe
**Type:** weapon (greataxe), martial weapon, melee weapon

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:** 1d12, slashing, - heavy, two-handed
**Value:** Varies
**Weight:** 7 lb.

**Description:** You gain a +2 bonus to attack and damage rolls made with this magic axe. The axe deals an extra 1d6 necrotic damage to creatures that aren&#39;t constructs or undead. If you reduce such a creature to 0 hit points with an attack using this axe, you gain 10 temporary hit points.This axe is forged from a dark, rust-colored metal and once belonged to the goliath barbarian Grog Strongjaw of Vox Machina. Heavy. Creatures that are Small or Tiny have disadvantage on attack rolls with heavy weapons. A heavy weapon&#39;s size and bulk make it too large for a Small or Tiny creature to use effectively. Two-Handed. This weapon requires two hands to use. This property is relevant only when you attack with the weapon, not when you simply hold it.



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: carved_ivory_statuette
source: dmg
rarity: none
attunement: none_required
value: 250_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Carved ivory statuette
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 250 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Carved ivory statuette
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 250 gp
**Weight:** Varies

**Description:**



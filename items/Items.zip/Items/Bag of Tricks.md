---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: bag_of_tricks
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: ½_lb.
properties:
---
> [!oRPG-Item]
> # Bag of Tricks
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| ½ lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Bag of Tricks
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** ½ lb.

**Description:** Multiple variations of this item exist, as listed below:Bag of Tricks, GrayBag of Tricks, RustBag of Tricks, Tan



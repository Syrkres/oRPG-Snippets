---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to one type of damage while you wear this armor. The DM chooses the type or determines it randomly from the options below.d10Damage Type1Acid2Cold3Fire4Force5Lightning6Necrotic7Poison8Psychic9Radiant10ThunderMultiple variations of this item exist, as listed below:Armor of Acid ResistanceArmor of Cold ResistanceArmor of Fire ResistanceArmor of Force ResistanceArmor of Lightning ResistanceArmor of Necrotic ResistanceArmor of Poison ResistanceArmor of Psychic ResistanceArmor of Radiant ResistanceArmor of Thunder Resistance



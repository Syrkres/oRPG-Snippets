---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: blue_chromatic_rose
source: wbtw
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Blue Chromatic Rose
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WBtW |

#  Blue Chromatic Rose
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** WBtW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While this rose is held, it crackles with lightning as a harmless visual effect.While holding the rose by its stem, you gain resistance to lightning damage. If you would take more than 10 lightning damage from a single source (after applying the resistance), the rose disintegrates, and you take no damage instead.As an action, you can blow the petals from the rose to produce a 20-foot cone of lightning. Each creature in the cone must make a DC 15 Constitution saving throw, taking 3d10 lightning damage on a failed save, or half as much damage on a successful one. Using this property destroys the rose.



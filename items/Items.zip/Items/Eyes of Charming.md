---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: eyes_of_charming
source: dmg
rarity: uncommon
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Eyes of Charming
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | 56,000 gp for a pair |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Eyes of Charming
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** These crystal lenses fit over the eyes. They have 3 charges. While wearing them, you can expend 1 charge as an action to cast the charm person spell (save DC 13) on a humanoid within 30 feet of you, provided that you and the target can see each other. The lenses regain all expended charges daily at dawn.



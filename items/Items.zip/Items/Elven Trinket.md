---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: elven_trinket
source: mtf
rarity: none
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Elven Trinket
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | MTF |

#  Elven Trinket
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** MTF
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** d8Trinket1A small notebook that causes anything written in it to disappear after 1 hour2A crystal lens made of ivory and gold that causes anything observed through it to appear to be surrounded by motes of multicolored light3A small golden pyramid inscribed with elven symbols and about the size of a walnut4A cloak pin made from enamel in the shape of a butterfly; when you take the pin off, it turns into a real butterfly, and returns when you are ready to put your cloak back on again5A golden compass that points toward the nearest portal to the Feywild within 10 miles6A small silver spinning top that, when spun, endlessly spins until interrupted7A small songbird made of enamel, gold wire, and precious stone; uttering the songbird&#39;s name in Elvish causes the trinket to emit that bird&#39;s birdsong8A small enamel flower that, when put in one&#39;s hair, animates, tying back the wearer&#39;s hair with a living vine with flowers; plucking a single flower from this vine returns it to its inanimate form



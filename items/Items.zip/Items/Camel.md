---
cssclass: oRPGPage
fileType: item
itemType: mount
name: camel
source: phb
rarity: none
attunement: none_required
value: 50_gp
weight: varies
properties: speed:_50_carrying_capacity:_480_lb.
---
> [!oRPG-Item]
> # Camel
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | mount |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| Varies |
>  |**Properties** | Speed: 50, Carrying Capacity: 480 lb. |
> | **Source** | PHB |

#  Camel
**Type:** mount

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** Speed: 50, Carrying Capacity: 480 lb.
**Value:** 50 gp
**Weight:** Varies

**Description:**



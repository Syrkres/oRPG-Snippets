---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: claws_of_the_umber_hulk
source: pota
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Claws of the Umber Hulk
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PotA |

#  Claws of the Umber Hulk
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** PotA
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** These heavy gauntlets of brown iron are forged in the shape of an umber hulk&#39;s claws, and they fit the wearer&#39;s hands and forearms all the way up to the elbow. While wearing both claws, you gain a burrowing speed of 20 feet, and you can tunnel through solid rock at a rate of 1 foot per round.You can use a claw as a melee weapon while wearing it. You have proficiency with it, and it deals 1d8 slashing damage on a hit (your Strength modifier applies to the attack and damage rolls, as normal).While wearing the claws, you can&#39;t manipulate objects or cast spells with somatic components.



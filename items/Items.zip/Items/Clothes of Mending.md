---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: clothes_of_mending
source: xge
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Clothes of Mending
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Clothes of Mending
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This elegant outfit of traveler&#39;s clothes magically mends itself to counteract daily wear and tear. Pieces of the outfit that are destroyed can&#39;t be repaired in this way.



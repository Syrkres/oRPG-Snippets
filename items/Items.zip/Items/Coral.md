---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: coral
source: dmg
rarity: none
attunement: none_required
value: 100_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Coral
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 100 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Coral
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 100 gp
**Weight:** Varies

**Description:** An opaque crimson gemstone.



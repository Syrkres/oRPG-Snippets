---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: component_pouch
source: phb
rarity: none
attunement: none_required
value: 25_gp
weight: 2_lb.
properties:
---
> [!oRPG-Item]
> # Component Pouch
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 25 gp |
>  | **Weight**| 2 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Component Pouch
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 25 gp
**Weight:** 2 lb.

**Description:** A component pouch is a small, watertight leather belt pouch that has compartments to hold all the material components and other special items you need to cast your spells, except for those components that have a specific cost (as indicated in a spell&#39;s description).



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: black_sapphire
source: dmg
rarity: none
attunement: none_required
value: 5000_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Black Sapphire
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5,000 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Black Sapphire
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 5,000 gp
**Weight:** Varies

**Description:** A translucent lustrous black with glowing highlights gemstone.



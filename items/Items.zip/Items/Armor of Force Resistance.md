---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_force_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Force Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Force Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to force damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Force Resistance)Chain Mail (Chain Mail of Force Resistance)Chain Shirt (Chain Shirt of Force Resistance)Half Plate Armor (Half Plate Armor of Force Resistance)Hide Armor (Hide Armor of Force Resistance)Leather Armor (Leather Armor of Force Resistance)Padded Armor (Padded Armor of Force Resistance)Plate Armor (Plate Armor of Force Resistance)Ring Mail (Ring Mail of Force Resistance)Scale Mail (Scale Mail of Force Resistance)Spiked Armor (Spiked Armor of Force Resistance)Splint Armor (Splint Armor of Force Resistance)Studded Leather Armor (Studded Leather Armor of Force Resistance)



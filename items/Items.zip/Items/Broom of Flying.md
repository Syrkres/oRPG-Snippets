---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: broom_of_flying
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Broom of Flying
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | 17,000 gp |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Broom of Flying
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** This wooden broom, which weighs 3 pounds, functions like a mundane broom until you stand astride it and speak its command word. It then hovers beneath you and can be ridden in the air. It has a flying speed of 50 feet. It can carry up to 400 pounds, but its flying speed becomes 30 feet while carrying over 200 pounds. The broom stops hovering when you land.You can send the broom to travel alone to a destination within 1 mile of you if you speak the command word, name the location, and are familiar with that place. The broom comes back to you when you speak another command word, provided that the broom is still within 1 mile of you.



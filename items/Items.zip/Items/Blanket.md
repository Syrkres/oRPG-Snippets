---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: blanket
source: phb
rarity: none
attunement: none_required
value: 5_sp
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Blanket
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 sp |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Blanket
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 sp
**Weight:** 3 lb.

**Description:**



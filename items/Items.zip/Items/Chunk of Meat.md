---
cssclass: oRPGPage
fileType: item
itemType: food_and_drink
name: chunk_of_meat
source: phb
rarity: none
attunement: none_required
value: 3_sp
weight: varies
properties:
---
> [!oRPG-Item]
> # Chunk of Meat
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | food and drink |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 3 sp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Chunk of Meat
**Type:** food and drink

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 3 sp
**Weight:** Varies

**Description:**



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: coin_of_delving
source: egw
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Coin of Delving
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Coin of Delving
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This scintillating copper coin sheds dim light in a 5-foot radius. If dropped a distance greater than 5 feet, the coin issues a melodious ringing sound when it hits a surface. Any creature that can hear the chime can determine the distance the coin dropped based on the tone.



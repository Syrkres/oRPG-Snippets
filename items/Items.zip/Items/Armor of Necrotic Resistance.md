---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_necrotic_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Necrotic Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Necrotic Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to necrotic damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Necrotic Resistance)Chain Mail (Chain Mail of Necrotic Resistance)Chain Shirt (Chain Shirt of Necrotic Resistance)Half Plate Armor (Half Plate Armor of Necrotic Resistance)Hide Armor (Hide Armor of Necrotic Resistance)Leather Armor (Leather Armor of Necrotic Resistance)Padded Armor (Padded Armor of Necrotic Resistance)Plate Armor (Plate Armor of Necrotic Resistance)Ring Mail (Ring Mail of Necrotic Resistance)Scale Mail (Scale Mail of Necrotic Resistance)Spiked Armor (Spiked Armor of Necrotic Resistance)Splint Armor (Splint Armor of Necrotic Resistance)Studded Leather Armor (Studded Leather Armor of Necrotic Resistance)



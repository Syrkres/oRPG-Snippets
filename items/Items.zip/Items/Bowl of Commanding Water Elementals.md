---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: bowl_of_commanding_water_elementals
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Bowl of Commanding Water Elementals
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | 100,000 gp |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Bowl of Commanding Water Elementals
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** While this bowl is filled with water, you can use an action to speak the bowl&#39;s command word and summon a water elemental, as if you had cast the conjure elemental spell. The bowl can&#39;t be used this way again until the next dawn.The bowl is about 1 foot in diameter and half as deep. It weighs 3 pounds and holds about 3 gallons.



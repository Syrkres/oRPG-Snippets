---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: catapult_munition
source: scc
rarity: unknown
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Catapult Munition
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | Unknown |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | SCC |

#  Catapult Munition
**Type:** adventuring gear

**Rarity:** Unknown
**Attunement:** None Required
**Source:** SCC
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** A catapult munition roughly the size and weight of a cannonball.The munition can be thrown up to 30 feet and explodes on impact. Any creature within a 15-foot-radius sphere centered on the point of impact must make a DC 14 Dexterity saving throw, taking 35 (10d6) fire damage on a failed save, or half as much damage on a successful one. In addition, each object in that area that isn&#39;t being worn or carried takes 35 (10d6) fire damage.



:::#  +1 Shield 
---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +1_shield_(*)
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +1 Shield (*)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +1 Shield (*)
*Type: generic variant*

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** * This generic variant has the same name and source as the item +1 shield.While holding this shield, you have a +1 bonus to AC. This bonus is in addition to the shield&#39;s normal bonus to AC. Base items. This item variant can be applied to the following base items:Shield (+1 Shield)



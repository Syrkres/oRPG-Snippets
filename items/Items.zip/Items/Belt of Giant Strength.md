---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: belt_of_giant_strength
source: dmg
rarity: varies
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Belt of Giant Strength
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Varies |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Belt of Giant Strength
**Type:** wondrous item

**Rarity:** Varies
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Multiple variations of this item exist, as listed below:Belt of Cloud Giant StrengthBelt of Fire Giant StrengthBelt of Frost Giant StrengthBelt of Hill Giant StrengthBelt of Stone Giant StrengthBelt of Storm Giant Strength



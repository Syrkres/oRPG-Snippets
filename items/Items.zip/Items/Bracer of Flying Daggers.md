---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: bracer_of_flying_daggers
source: wdh
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Bracer of Flying Daggers
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WDH |

#  Bracer of Flying Daggers
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** WDH
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This armband appears to have thin daggers strapped to it. As an action, you can pull up to two magic daggers from the bracer and immediately hurl them, making a ranged attack with each dagger. A dagger vanishes if you don&#39;t hurl it right away, and the daggers disappear right after they hit or miss. The bracer never runs out of daggers.



---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +3_weapon_(no_damage)
source: dmg
rarity: very_rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +3 Weapon (no damage)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +3 Weapon (no damage)
**Type:** generic variant

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +3 bonus to attack rolls made with this weapon. Base items. This item variant can be applied to the following base items:Net (+3 Net)



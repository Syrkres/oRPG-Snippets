---
cssclass: oRPGPage
fileType: item
itemType: staff_weapon_simple_weapon_melee_weapon
name: dragonstaff_of_ahghairon
source: wdh
rarity: legendary
attunement: requires_attunement
value: varies
weight: 4_lb.
properties: 1d6_bludgeoning_-_versatile_(1d8)
---
> [!oRPG-Item]
> # Dragonstaff of Ahghairon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | staff, weapon, simple weapon, melee weapon |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d6, bludgeoning, - versatile (1d8) |
> | **Source** | WDH |

#  Dragonstaff of Ahghairon
**Type:** staff, weapon, simple weapon, melee weapon

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** WDH
**Properties:** 1d6, bludgeoning, - versatile (1d8)
**Value:** Varies
**Weight:** 4 lb.

**Description:** While holding the dragonstaff of Ahghairon, you have advantage on saving throws against the spells and breath weapons of dragons, as well as the breath weapons of other creatures of the dragon type (such as dragon turtles).A creature of the dragon type that you touch with the staff can move through the city of Waterdeep, ignoring Ahghairon&#39;s dragonward (see &quot;Ahghairon&#39;s Dragonward,&quot; in the Introduction). This effect lasts until the creature is touched again by the staff or until a time you proclaim when you confer the benefit.The staff has 10 charges. While holding it, you can expend 1 charge as an action to cast the command spell. If you target a dragon with this casting, the dragon has disadvantage on its saving throw. The staff regains 1d10 charges daily at dawn. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: electrum_50-zib_coin
source: ggr
rarity: none
attunement: none_required
value: 5_sp
weight: varies
properties:
---
> [!oRPG-Item]
> # Electrum 50-Zib Coin
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 sp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | GGR |

#  Electrum 50-Zib Coin
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** GGR
**Properties:**
**Value:** 5 sp
**Weight:** Varies

**Description:**



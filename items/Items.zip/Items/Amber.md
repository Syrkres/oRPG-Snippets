---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: amber
source: dmg
rarity: none
attunement: none_required
value: 100_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Amber
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 100 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Amber
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 100 gp
**Weight:** Varies

**Description:** A transparent watery gold to rich gold gemstone.



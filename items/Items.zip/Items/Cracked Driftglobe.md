---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cracked_driftglobe
source: cm
rarity: uncommon
attunement: none_required
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Cracked Driftglobe
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | CM |

#  Cracked Driftglobe
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** CM
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This small sphere of thick glass weighs 1 pound. If you are within 60 feet of it, you can speak its command word and cause it to emanate the light spell.



---
cssclass: oRPGPage
fileType: item
itemType: spellcasting_focus
name: druidic_focus
source: phb
rarity: none
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Druidic Focus
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | spellcasting focus |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Druidic Focus
**Type:** spellcasting focus

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** A druidic focus might be a sprig of mistletoe or holly, a wand or scepter made of yew or another special wood, a staff drawn whole out of a living tree, or a totem object incorporating feathers, fur, bones, and teeth from sacred animals. A druid can use such an object as a spellcasting focus.Multiple variations of this item exist, as listed below:Sprig of mistletoeTotemWooden staffYew wand



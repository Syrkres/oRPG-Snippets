---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: backpack
source: phb
rarity: none
attunement: none_required
value: 2_gp
weight: 5_lb.
properties:
---
> [!oRPG-Item]
> # Backpack
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 gp |
>  | **Weight**| 5 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Backpack
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 2 gp
**Weight:** 5 lb.

**Description:** A backpack can hold one cubic foot or 30 pounds of gear. You can also strap items, such as a bedroll or a coil of rope, to the outside of a backpack.



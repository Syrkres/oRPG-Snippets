---
cssclass: oRPGPage
fileType: item
itemType: weapon_(quarterstaff)_simple_weapon_melee_weapon
name: baba_yagas_pestle
source: tce
rarity: artifact
attunement: requires_attunement
value: varies
weight: 4_lb.
properties: 1d6_bludgeoning_-_versatile_(1d8)
---
> [!oRPG-Item]
> # Baba Yaga&#39;s Pestle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (quarterstaff), simple weapon, melee weapon |
> |**Rarity** | Artifact |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d6, bludgeoning, - versatile (1d8) |
> | **Source** | TCE |

#  Baba Yaga&#39;s Pestle
**Type:** weapon (quarterstaff), simple weapon, melee weapon

**Rarity:** Artifact
**Attunement:** Requires Attunement
**Source:** TCE
**Properties:** 1d6, bludgeoning, - versatile (1d8)
**Value:** Varies
**Weight:** 4 lb.

**Description:** The pestle is a 6-inch-long, worn wooden tool. Once during your turn while you are holding the pestle, you can extend it into a quarterstaff or shrink it back into a pestle (no action required). As a quarterstaff, the pestle is a magic weapon that grants a +3 bonus to attack and damage rolls made with it.The pestle has 12 charges. When you hit with a melee attack using the pestle, you can expend up to 3 of its charges to deal an extra 1d8 force damage for each charge expended. The pestle regains all expended charges daily at dawn. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



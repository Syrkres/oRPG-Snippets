---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: belt_of_cloud_giant_strength
source: dmg
rarity: legendary
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Belt of Cloud Giant Strength
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Belt of Cloud Giant Strength
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While wearing this belt, your Strength score changes to 27. The item has no effect on you if your Strength without the belt is equal to or greater than the belt&#39;s score.



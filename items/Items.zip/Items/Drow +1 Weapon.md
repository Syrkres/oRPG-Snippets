---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: drow_+1_weapon
source: mm
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Drow +1 Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | MM |

#  Drow +1 Weapon
**Type:** generic variant

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** MM
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +1 bonus to attack and damage rolls made with this weapon. This weapon loses its enchantment bonus permanently if it is exposed to sunlight for 1 hour or longer. Base items. This item variant can be applied to the following base items:Antimatter Rifle (Drow +1 Antimatter Rifle)Automatic Pistol (Drow +1 Automatic Pistol)Automatic Rifle (Drow +1 Automatic Rifle)Battleaxe (Drow +1 Battleaxe)Blowgun (Drow +1 Blowgun)Club (Drow +1 Club)Dagger (Drow +1 Dagger)Dart (Drow +1 Dart)Double-Bladed Scimitar (Drow +1 Double-Bladed Scimitar)Flail (Drow +1 Flail)Glaive (Drow +1 Glaive)Greataxe (Drow +1 Greataxe)Greatclub (Drow +1 Greatclub)Greatsword (Drow +1 Greatsword)Halberd (Drow +1 Halberd)Hand Crossbow (Drow +1 Hand Crossbow)Handaxe (Drow +1 Handaxe)Heavy Crossbow (Drow +1 Heavy Crossbow)Hooked Shortspear (Drow +1 Hooked Shortspear)Hunting Rifle (Drow +1 Hunting Rifle)Javelin (Drow +1 Javelin)Lance (Drow +1 Lance)Laser Pistol (Drow +1 Laser Pistol)Laser Rifle (Drow +1 Laser Rifle)Light Crossbow (Drow +1 Light Crossbow)Light Hammer (Drow +1 Light Hammer)Light Repeating Crossbow (Drow +1 Light Repeating Crossbow)Longbow (Drow +1 Longbow)Longsword (Drow +1 Longsword)Mace (Drow +1 Mace)Maul (Drow +1 Maul)Morningstar (Drow +1 Morningstar)Musket (Drow +1 Musket)Pike (Drow +1 Pike)Pistol (Drow +1 Pistol)Quarterstaff (Drow +1 Quarterstaff)Rapier (Drow +1 Rapier)Revolver (Drow +1 Revolver)Scimitar (Drow +1 Scimitar)Shortbow (Drow +1 Shortbow)Shortsword (Drow +1 Shortsword)Shotgun (Drow +1 Shotgun)Sickle (Drow +1 Sickle)Sling (Drow +1 Sling)Spear (Drow +1 Spear)Trident (Drow +1 Trident)War Pick (Drow +1 War Pick)Warhammer (Drow +1 Warhammer)Whip (Drow +1 Whip)Yklwa (Drow +1 Yklwa)



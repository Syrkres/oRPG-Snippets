---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: charm_of_plant_command
source: gos
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Charm of Plant Command
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | GoS |

#  Charm of Plant Command
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** GoS
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This fist-sized charm is made from a bundle of dried plant stems wrapped in silver thread. Hung on a leather thong, it is typically worn around the neck or attached to a belt.This charm has 3 charges. While you bear the charm, you can expend 1 charge as an action to cast the speak with plants spell. For the duration of the spell, you also have advantage on Charisma checks made to influence the behavior, demeanor, and attitude of plants. The charm regains all expended charges at dawn each day.



---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_fire_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Fire Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Fire Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to fire damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Fire Resistance)Chain Mail (Chain Mail of Fire Resistance)Chain Shirt (Chain Shirt of Fire Resistance)Half Plate Armor (Half Plate Armor of Fire Resistance)Hide Armor (Hide Armor of Fire Resistance)Leather Armor (Leather Armor of Fire Resistance)Padded Armor (Padded Armor of Fire Resistance)Plate Armor (Plate Armor of Fire Resistance)Ring Mail (Ring Mail of Fire Resistance)Scale Mail (Scale Mail of Fire Resistance)Spiked Armor (Spiked Armor of Fire Resistance)Splint Armor (Splint Armor of Fire Resistance)Studded Leather Armor (Studded Leather Armor of Fire Resistance)



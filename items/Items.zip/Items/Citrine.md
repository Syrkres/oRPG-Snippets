---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: citrine
source: dmg
rarity: none
attunement: none_required
value: 50_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Citrine
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Citrine
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 50 gp
**Weight:** Varies

**Description:** A transparent pale yellow-brown gemstone.



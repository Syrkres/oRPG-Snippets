---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: bell_branch
source: tce
rarity: rare
attunement: requires_attunement_by_a_druid_or_warlock
value: varies
weight: 0.16_oz.
properties:
---
> [!oRPG-Item]
> # Bell Branch
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement By A Druid Or Warlock |
> | **Value** | Varies |
>  | **Weight**| 0.16 oz. |
>  |**Properties** |  |
> | **Source** | TCE |

#  Bell Branch
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement By A Druid Or Warlock
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 0.16 oz.

**Description:** This silver implement is shaped like a tree branch and is strung with small golden bells. The branch is a spellcasting focus for your spells while you hold it.The branch has 3 charges, and it regains 1d3 expended charges daily at dawn. You can use the charges in the following ways while holding it:As a bonus action, you can expend 1 charge to detect the presence of aberrations, celestials, constructs, elementals, fey, fiends, or undead within 60 feet of you. If such creatures are present and don&#39;t have total cover from you, the bells ring softly, their tone indicating the creature types present.As an action, you can expend 1 charge to cast protection from evil and good.



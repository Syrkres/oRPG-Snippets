---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +2_armor
source: dmg
rarity: very_rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +2 Armor
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +2 Armor
**Type:** generic variant

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +2 bonus to AC while wearing this armor. Base items. This item variant can be applied to the following base items:Breastplate (+2 Breastplate)Chain Mail (+2 Chain Mail)Chain Shirt (+2 Chain Shirt)Half Plate Armor (+2 Half Plate Armor)Hide Armor (+2 Hide Armor)Leather Armor (+2 Leather Armor)Padded Armor (+2 Padded Armor)Plate Armor (+2 Plate Armor)Ring Mail (+2 Ring Mail)Scale Mail (+2 Scale Mail)Spiked Armor (+2 Spiked Armor)Splint Armor (+2 Splint Armor)Studded Leather Armor (+2 Studded Leather Armor)



---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear_poison_(contact)
name: carrion_crawler_mucus
source: dmg
rarity: none
attunement: none_required
value: 200_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Carrion Crawler Mucus
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear, poison (contact) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 200 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Carrion Crawler Mucus
**Type:** adventuring gear, poison (contact)

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 200 gp
**Weight:** Varies

**Description:** This poison must be harvested from a dead or incapacitated carrion crawler. A creature subjected to this poison must succeed on a DC 13 Constitution saving throw or be poisoned for 1 minute. The poisoned creature is paralyzed. The creature can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success.



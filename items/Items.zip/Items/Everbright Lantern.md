---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: everbright_lantern
source: erlw
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Everbright Lantern
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ERLW |

#  Everbright Lantern
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** ERLW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This bullseye lantern contains an Eberron dragonshard that sheds light comparable to that produced by a continual flame spell. An everbright lantern sheds light in a 120-foot cone; the closest 60 feet is bright light, and the farthest 60 feet is dim light.



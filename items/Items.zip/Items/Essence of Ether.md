---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear_poison_(inhaled)
name: essence_of_ether
source: dmg
rarity: none
attunement: none_required
value: 300_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Essence of Ether
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear, poison (inhaled) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 300 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Essence of Ether
**Type:** adventuring gear, poison (inhaled)

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 300 gp
**Weight:** Varies

**Description:** A creature subjected to this poison must succeed on a DC 15 Constitution saving throw or become poisoned for 8 hours. The poisoned creature is unconscious. The creature wakes up if it takes damage or if another creature takes an action to shake it awake.



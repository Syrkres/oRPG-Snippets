---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: blue_quartz
source: dmg
rarity: none
attunement: none_required
value: 10_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Blue Quartz
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Blue Quartz
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 10 gp
**Weight:** Varies

**Description:** A transparent pale blue gemstone.



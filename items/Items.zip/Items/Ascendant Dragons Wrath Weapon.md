---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: ascendant_dragons_wrath_weapon
source: ftd
rarity: legendary
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Ascendant Dragon&#39;s Wrath Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  Ascendant Dragon&#39;s Wrath Weapon
**Type:** generic variant

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This weapon is decorated with dragon heads, claws, wings, scales, or Draconic letters. When it steeps in a dragon&#39;s hoard, it absorbs the energy of the dragon&#39;s breath weapon and deals damage of that type with its special properties.Whenever you roll a 20 on your attack roll with this weapon, each creature of your choice within 5 feet of the target takes 5 damage of the type dealt by the dragon&#39;s breath weapon.You gain a +3 bonus to attack and damage rolls made using the weapon. On a hit, the weapon deals an extra 3d6 damage of the type dealt by the dragon&#39;s breath weapon.As an action, you can unleash a 60-foot cone of destructive energy from the weapon. Each creature in that area must make a DC 18 Dexterity saving throw, taking 12d6 damage of the type dealt by the dragon&#39;s breath weapon on a failed save, or half as much damage on a successful one. Once this action is used, it can&#39;t be used again until the next dawn. Base items. This item variant can be applied to the following base items:Antimatter Rifle (Ascendant Dragon&#39;s Wrath Antimatter Rifle)Automatic Pistol (Ascendant Dragon&#39;s Wrath Automatic Pistol)Automatic Rifle (Ascendant Dragon&#39;s Wrath Automatic Rifle)Battleaxe (Ascendant Dragon&#39;s Wrath Battleaxe)Blowgun (Ascendant Dragon&#39;s Wrath Blowgun)Club (Ascendant Dragon&#39;s Wrath Club)Dagger (Ascendant Dragon&#39;s Wrath Dagger)Dart (Ascendant Dragon&#39;s Wrath Dart)Double-Bladed Scimitar (Ascendant Dragon&#39;s Wrath Double-Bladed Scimitar)Flail (Ascendant Dragon&#39;s Wrath Flail)Glaive (Ascendant Dragon&#39;s Wrath Glaive)Greataxe (Ascendant Dragon&#39;s Wrath Greataxe)Greatclub (Ascendant Dragon&#39;s Wrath Greatclub)Greatsword (Ascendant Dragon&#39;s Wrath Greatsword)Halberd (Ascendant Dragon&#39;s Wrath Halberd)Hand Crossbow (Ascendant Dragon&#39;s Wrath Hand Crossbow)Handaxe (Ascendant Dragon&#39;s Wrath Handaxe)Heavy Crossbow (Ascendant Dragon&#39;s Wrath Heavy Crossbow)Hooked Shortspear (Ascendant Dragon&#39;s Wrath Hooked Shortspear)Hunting Rifle (Ascendant Dragon&#39;s Wrath Hunting Rifle)Javelin (Ascendant Dragon&#39;s Wrath Javelin)Lance (Ascendant Dragon&#39;s Wrath Lance)Laser Pistol (Ascendant Dragon&#39;s Wrath Laser Pistol)Laser Rifle (Ascendant Dragon&#39;s Wrath Laser Rifle)Light Crossbow (Ascendant Dragon&#39;s Wrath Light Crossbow)Light Hammer (Ascendant Dragon&#39;s Wrath Light Hammer)Light Repeating Crossbow (Ascendant Dragon&#39;s Wrath Light Repeating Crossbow)Longbow (Ascendant Dragon&#39;s Wrath Longbow)Longsword (Ascendant Dragon&#39;s Wrath Longsword)Mace (Ascendant Dragon&#39;s Wrath Mace)Maul (Ascendant Dragon&#39;s Wrath Maul)Morningstar (Ascendant Dragon&#39;s Wrath Morningstar)Musket (Ascendant Dragon&#39;s Wrath Musket)Net (Ascendant Dragon&#39;s Wrath Net)Pike (Ascendant Dragon&#39;s Wrath Pike)Pistol (Ascendant Dragon&#39;s Wrath Pistol)Quarterstaff (Ascendant Dragon&#39;s Wrath Quarterstaff)Rapier (Ascendant Dragon&#39;s Wrath Rapier)Revolver (Ascendant Dragon&#39;s Wrath Revolver)Scimitar (Ascendant Dragon&#39;s Wrath Scimitar)Shortbow (Ascendant Dragon&#39;s Wrath Shortbow)Shortsword (Ascendant Dragon&#39;s Wrath Shortsword)Shotgun (Ascendant Dragon&#39;s Wrath Shotgun)Sickle (Ascendant Dragon&#39;s Wrath Sickle)Sling (Ascendant Dragon&#39;s Wrath Sling)Spear (Ascendant Dragon&#39;s Wrath Spear)Trident (Ascendant Dragon&#39;s Wrath Trident)War Pick (Ascendant Dragon&#39;s Wrath War Pick)Warhammer (Ascendant Dragon&#39;s Wrath Warhammer)Whip (Ascendant Dragon&#39;s Wrath Whip)Yklwa (Ascendant Dragon&#39;s Wrath Yklwa)



---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: acheron_blade
source: egw
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Acheron Blade
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Acheron Blade
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** The black blade of this sword is crafted from a mysterious arcane alloy. You gain a +1 bonus to attack and damage rolls made with this magic weapon. While the sword is on your person, you are immune to effects that turn undead. Dark Blessing. While holding the sword, you can use an action to give yourself 1d4 + 4 temporary hit points. This property can&#39;t be used again until the next dusk. Disheartening Strike. When you hit a creature with an attack using this weapon, you can fill the target with unsettling dread: the target has disadvantage on the next saving throw it makes before the end of your next turn. The creature ignores this effect if it&#39;s immune to the frightened condition. Once you use this property, you can&#39;t do so again until the next dusk. Base items. This item variant can be applied to the following base items:Double-Bladed Scimitar (Acheron Blade Double-Bladed Scimitar)Greatsword (Acheron Blade Greatsword)Longsword (Acheron Blade Longsword)Rapier (Acheron Blade Rapier)Scimitar (Acheron Blade Scimitar)Shortsword (Acheron Blade Shortsword)



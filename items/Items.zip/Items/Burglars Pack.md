---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: burglars_pack
source: phb
rarity: none
attunement: none_required
value: 16_gp
weight: 44½_lb.
properties:
---
> [!oRPG-Item]
> # Burglar&#39;s Pack
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 16 gp |
>  | **Weight**| 44½ lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Burglar&#39;s Pack
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 16 gp
**Weight:** 44½ lb.

**Description:** Includes:a backpacka bag of 1,000 ball bearings10 feet of stringa bell5 candlesa crowbara hammer10 pitonsa hooded lantern2 flasks of oil5 days rationsa tinderboxa waterskin50 feet of hempen rope



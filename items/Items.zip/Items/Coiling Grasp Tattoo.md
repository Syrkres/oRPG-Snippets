---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item_(tattoo)
name: coiling_grasp_tattoo
source: tce
rarity: uncommon
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Coiling Grasp Tattoo
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item (tattoo) |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | TCE |

#  Coiling Grasp Tattoo
**Type:** wondrous item (tattoo)

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Produced by a special needle, this magic tattoo has long intertwining designs. Tattoo Attunement. To attune to this item, you hold the needle to your skin where you want the tattoo to appear, pressing the needle there throughout the attunement process. When the attunement is complete, the needle turns into the ink that becomes the tattoo, which appears on the skin.If your attunement to the tattoo ends, the tattoo vanishes, and the needle reappears in your space. Grasping Tendrils. While the tattoo is on your skin, you can, as an action, cause the tattoo to extrude into inky tendrils, which reach for a creature you can see within 15 feet of you. The creature must succeed on a DC 14 Strength saving throw or take 3d6 force damage and be grappled by you. As an action, the creature can escape the grapple by succeeding on a DC 14 Strength (Athletics) or Dexterity (Acrobatics) check. The grapple also ends if you halt it (no action required), if the creature is ever more than 15 feet away from you, or if you use this tattoo on a different creature.



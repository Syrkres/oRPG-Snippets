---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: deck_of_illusions
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Deck of Illusions
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | 8,100 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Deck of Illusions
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This box contains a set of parchment cards. A full deck has 34 cards. A deck found as treasure is usually missing 1d20 - 1 cards.The magic of the deck functions only if cards are drawn at random (you can use an altered deck of playing cards to simulate the deck). You can use an action to draw a card at random from the deck and throw it to the ground at a point within 30 feet of you.An illusion of one or more creatures forms over the thrown card and remains until dispelled. An illusory creature appears real, of the appropriate size, and behaves as if it were a real creature, except that it can do no harm. While you are within 120 feet of the illusory creature and can see it, you can use an action to move it magically anywhere within 30 feet of its card. Any physical interaction with the illusory creature reveals it to be an illusion, because objects pass through it. Someone who uses an action to visually inspect the creature identifies it as illusory with a successful DC 15 Intelligence (Investigation) check. The creature then appears translucent.The illusion lasts until its card is moved or the illusion is dispelled. When the illusion ends, the image on its card disappears, and that card can&#39;t be used again.Playing CardIllusionAce of heartsRed dragonKing of heartsKnight and four guardsQueen of heartsSuccubus&#x2F;IncubusJack of heartsDruidTen of heartsCloud giantNine of heartsEttinEight of heartsBugbearTwo of heartsGoblinAce of diamondsBeholderKing of diamondsArchmage and mage apprenticeQueen of diamondsNight hagJack of diamondsAssassinTen of diamondsFire giantNine of diamondsOgre mageEight of diamondsGnollTwo of diamondsKoboldAce of spadesLichKing of spadesPriest and two acolytesQueen of spadesMedusaJack of spadesVeteranTen of spadesFrost giantNine of spadesTrollEight of spadesHobgoblinTwo of spadesGoblinAce of clubsIron golemKing of clubsBandit captain and three banditsQueen of clubsErinyesJack of clubsBerserkerTen of clubsHill giantNine of clubsOgreEight of clubsOrcTwo of clubsKoboldjokers (2)You (the deck&#39;s owner)



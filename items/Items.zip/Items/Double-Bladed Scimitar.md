---
cssclass: oRPGPage
fileType: item
itemType: weapon_martial_weapon_melee_weapon
name: double-bladed_scimitar
source: erlw
rarity: none
attunement: none_required
value: 100_gp
weight: 6_lb.
properties: 2d4_slashing_-_special_two-handed
---
> [!oRPG-Item]
> # Double-Bladed Scimitar
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon, martial weapon, melee weapon |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 100 gp |
>  | **Weight**| 6 lb. |
>  |**Properties** | 2d4, slashing, - special, two-handed |
> | **Source** | ERLW |

#  Double-Bladed Scimitar
**Type:** weapon, martial weapon, melee weapon

**Rarity:** None
**Attunement:** None Required
**Source:** ERLW
**Properties:** 2d4, slashing, - special, two-handed
**Value:** 100 gp
**Weight:** 6 lb.

**Description:**  Special. If you attack with a double-bladed scimitar as part of the Attack action on your turn, you can use a bonus action immediately after to make a melee attack with it. This attack deals 1d4 slashing damage on a hit, instead of 2d4. Two-Handed. This weapon requires two hands to use. This property is relevant only when you attack with the weapon, not when you simply hold it.



---
cssclass: oRPGPage
fileType: item
itemType: other
name: arcanaloths_music_box
source: toa
rarity: unknown_(magic)
attunement: none_required
value: 750_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Arcanaloth&#39;s Music Box
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | 750 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ToA |

#  Arcanaloth&#39;s Music Box
**Type:** other

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** ToA
**Properties:**
**Value:** 750 gp
**Weight:** Varies

**Description:** This music box is made of dark wood with gold filigree. Each of its five sides is sculpted with the image of a horned woman playing a different musical instrument: a dulcimer, a flute, a harp, a lyre, and a viol. While touching the box, you can use an action to make it play music featuring one of the instruments shown, which can be heard up to 60 feet away. You can also use an action to stop the music.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: emerald_pen
source: ftd
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Emerald Pen
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  Emerald Pen
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This pen is tipped with an emerald nib and requires no ink to write. While holding this pen, you can cast illusory script at will, requiring no material components.



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: eye_agate
source: dmg
rarity: none
attunement: none_required
value: 10_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Eye Agate
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Eye Agate
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 10 gp
**Weight:** Varies

**Description:** A translucent circles of gray, white, brown, blue, or green gemstone.



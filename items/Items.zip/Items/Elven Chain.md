---
cssclass: oRPGPage
fileType: item
itemType: medium_armor
name: elven_chain
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: 20_lb.
properties: ac_13_+_dex_(max_2)
---
> [!oRPG-Item]
> # Elven Chain
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | medium armor |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | 4,150 gp |
>  | **Weight**| 20 lb. |
>  |**Properties** | AC 13 + Dex (max 2) |
> | **Source** | DMG |

#  Elven Chain
**Type:** medium armor

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:** AC 13 + Dex (max 2)
**Value:** Varies
**Weight:** 20 lb.

**Description:** You gain a +1 bonus to AC while you wear this armor. You are considered proficient with this armor even if you lack proficiency with medium armor.



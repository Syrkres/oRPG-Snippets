---
cssclass: oRPGPage
fileType: item
itemType: mount
name: axe_beak
source: idrotf
rarity: none
attunement: none_required
value: 50_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Axe Beak
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | mount |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | IDRotF |

#  Axe Beak
**Type:** mount

**Rarity:** None
**Attunement:** None Required
**Source:** IDRotF
**Properties:**
**Value:** 50 gp
**Weight:** Varies

**Description:** An axe beak&#39;s splayed toes allow it to run across snow, and it can carry as much weight as a mule. A domesticated axe beak can be purchased in Ten-Towns for 50 gp.



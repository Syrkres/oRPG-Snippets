---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: azorius_keyrune
source: ggr
rarity: rare
attunement: requires_attunement_by_a_member_of_the_azorius_guild
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Azorius Keyrune
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement By A Member Of The Azorius Guild |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | GGR |

#  Azorius Keyrune
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement By A Member Of The Azorius Guild
**Source:** GGR
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This keyrune is carved from white marble and lapis lazuli to resemble a noble bird of prey. It can become a giant eagle for up to 1 hour. While the transformed eagle is within 1 mile of you, you can communicate with it telepathically. As an action, you can see through the eagle&#39;s eyes and hear what it hears until the start of your next turn, and you gain the benefit of its keen sight. During this time, you are deaf and blind with regard to your own senses.When you use an action to speak the item&#39;s command word and place the keyrune on the ground in an unoccupied space within 5 feet of you, the keyrune transforms into a giant eagle. If there isn&#39;t enough space for the eagle, the keyrune doesn&#39;t transform.The creature is friendly to you, your companions, and other members of your guild (unless those guild members are hostile to you). It understands your languages and obeys your spoken commands. If you issue no commands, the eagle takes the Dodge action and moves to avoid danger.At the end of the duration, the creature reverts to its keyrune form. It reverts early if it drops to 0 hit points or if you use an action to speak the command word again while touching it. When the creature reverts to its keyrune form, it can&#39;t transform again until 36 hours have passed.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: +3_dragonhide_belt
source: ftd
rarity: very_rare
attunement: requires_attunement_by_a_monk
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +3 Dragonhide Belt
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement By A Monk |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  +3 Dragonhide Belt
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement By A Monk
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This finely detailed belt is made of dragonhide. While wearing it, you gain a +3 bonus to the saving throw DCs of your ki features. In addition, you can use an action to regain ki points equal to a roll of your Martial Arts die. You can&#39;t use this action again until the next dawn.



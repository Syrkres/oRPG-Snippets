---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +2_weapon
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +2 Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +2 Weapon
**Type:** generic variant

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +2 bonus to attack and damage rolls made with this magic weapon. Base items. This item variant can be applied to the following base items:Antimatter Rifle (+2 Antimatter Rifle)Automatic Pistol (+2 Automatic Pistol)Automatic Rifle (+2 Automatic Rifle)Battleaxe (+2 Battleaxe)Blowgun (+2 Blowgun)Club (+2 Club)Dagger (+2 Dagger)Dart (+2 Dart)Double-Bladed Scimitar (+2 Double-Bladed Scimitar)Flail (+2 Flail)Glaive (+2 Glaive)Greataxe (+2 Greataxe)Greatclub (+2 Greatclub)Greatsword (+2 Greatsword)Halberd (+2 Halberd)Hand Crossbow (+2 Hand Crossbow)Handaxe (+2 Handaxe)Heavy Crossbow (+2 Heavy Crossbow)Hooked Shortspear (+2 Hooked Shortspear)Hunting Rifle (+2 Hunting Rifle)Javelin (+2 Javelin)Lance (+2 Lance)Laser Pistol (+2 Laser Pistol)Laser Rifle (+2 Laser Rifle)Light Crossbow (+2 Light Crossbow)Light Hammer (+2 Light Hammer)Light Repeating Crossbow (+2 Light Repeating Crossbow)Longbow (+2 Longbow)Longsword (+2 Longsword)Mace (+2 Mace)Maul (+2 Maul)Morningstar (+2 Morningstar)Musket (+2 Musket)Pike (+2 Pike)Pistol (+2 Pistol)Quarterstaff (+2 Quarterstaff)Rapier (+2 Rapier)Revolver (+2 Revolver)Scimitar (+2 Scimitar)Shortbow (+2 Shortbow)Shortsword (+2 Shortsword)Shotgun (+2 Shotgun)Sickle (+2 Sickle)Sling (+2 Sling)Spear (+2 Spear)Trident (+2 Trident)War Pick (+2 War Pick)Warhammer (+2 Warhammer)Whip (+2 Whip)Yklwa (+2 Yklwa)



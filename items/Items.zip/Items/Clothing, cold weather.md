---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: clothing,_cold_weather
source: idrotf
rarity: none
attunement: none_required
value: 10_gp
weight: 5_lb.
properties:
---
> [!oRPG-Item]
> # Clothing, cold weather
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| 5 lb. |
>  |**Properties** |  |
> | **Source** | IDRotF |

#  Clothing, cold weather
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** IDRotF
**Properties:**
**Value:** 10 gp
**Weight:** 5 lb.

**Description:** This outfit consists of a heavy fur coat or cloak over layers of wool clothing, as well as a fur-lined hat or hood, goggles, and fur-lined leather boots and gloves.As long as cold weather clothing remains dry, its wearer automatically succeeds on saving throws against the effects of extreme cold.



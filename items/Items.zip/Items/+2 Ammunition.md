---
cssclass: oRPGPage
fileType: item
itemType: ammunition_generic_variant
name: +2_ammunition
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +2 Ammunition
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition, generic variant |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +2 Ammunition
**Type:** ammunition, generic variant

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +2 bonus to attack and damage rolls made with this piece of magic ammunition. Once it hits a target, the ammunition is no longer magical. Base items. This item variant can be applied to the following base items:Arrow (+2 Arrow)Blowgun Needle (+2 Blowgun Needle)Crossbow Bolt (+2 Crossbow Bolt)Energy Cell (+2 Energy Cell)Modern Bullet (+2 Modern Bullet)Renaissance Bullet (+2 Renaissance Bullet)Sling Bullet (+2 Sling Bullet)



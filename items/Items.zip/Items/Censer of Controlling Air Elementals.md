---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: censer_of_controlling_air_elementals
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Censer of Controlling Air Elementals
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | 100,000 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Censer of Controlling Air Elementals
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** While incense is burning in this censer, you can use an action to speak the censer&#39;s command word and summon an air elemental, as if you had cast the conjure elemental spell. The censer can&#39;t be used this way again until the next dawn.This 6-inch-wide, 1-foot-high vessel resembles a chalice with a decorated lid. It weighs 1 pound.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: amulet_of_the_drunkard
source: egw
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Amulet of the Drunkard
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Amulet of the Drunkard
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This amulet smells of old, ale-stained wood. While wearing it, you can regain 4d4 + 4 hit points when you drink a pint of beer, ale, mead, or wine. Once the amulet has restored hit points, it can&#39;t do so again until the next dawn.



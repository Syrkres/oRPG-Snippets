---
cssclass: oRPGPage
fileType: item
itemType: weapon_(longsword)_martial_weapon_melee_weapon
name: dragon_sensing_longsword
source: pota
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: 3_lb.
properties: 1d8_slashing_-_versatile_(1d10)
---
> [!oRPG-Item]
> # Dragon Sensing Longsword
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (longsword), martial weapon, melee weapon |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** | 1d8, slashing, - versatile (1d10) |
> | **Source** | PotA |

#  Dragon Sensing Longsword
**Type:** weapon (longsword), martial weapon, melee weapon

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** PotA
**Properties:** 1d8, slashing, - versatile (1d10)
**Value:** Varies
**Weight:** 3 lb.

**Description:** This +1 longsword is made of dragon bone and with a dragon-leather grip. It has rubies in its pommel and hilt. The sword grows warm and the rubies glow slightly when the sword is within 120 feet of a dragon. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



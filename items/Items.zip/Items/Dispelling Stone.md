---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: dispelling_stone
source: egw
rarity: very_rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dispelling Stone
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Dispelling Stone
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This smooth, rainbow-colored, egg-shaped stone can be thrown up to 30 feet and explodes in a 10-foot-radius sphere of magical energy on impact, destroying the stone. Any active spell of 5th level or lower in the sphere ends.



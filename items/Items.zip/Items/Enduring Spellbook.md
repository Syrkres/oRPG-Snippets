---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: enduring_spellbook
source: xge
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Enduring Spellbook
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Enduring Spellbook
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This spellbook, along with anything written on its pages, can&#39;t be damaged by fire or immersion in water. In addition, the spellbook doesn&#39;t deteriorate with age.



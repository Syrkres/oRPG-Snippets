---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: breathing_bubble
source: egw
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Breathing Bubble
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Breathing Bubble
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This translucent, bubble-like sphere has a slightly tacky outer surface, and you gain the item&#39;s benefits only while wearing it over your head like a helmet.The bubble contains 1 hour of breathable air. The bubble regains all its expended air daily at dawn.



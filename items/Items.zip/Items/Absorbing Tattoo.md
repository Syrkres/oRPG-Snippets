---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item_(tattoo)
name: absorbing_tattoo
source: tce
rarity: very_rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Absorbing Tattoo
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item (tattoo) |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | TCE |

#  Absorbing Tattoo
**Type:** wondrous item (tattoo)

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Produced by a special needle, this magic tattoo features designs that emphasize one color. Tattoo Attunement. To attune to this item, you hold the needle to your skin where you want the tattoo to appear, pressing the needle there throughout the attunement process. When the attunement is complete, the needle turns into the ink that becomes the tattoo, which appears on the skin.If your attunement to the tattoo ends, the tattoo vanishes, and the needle reappears in your space. Damage Resistance. While the tattoo is on your skin, you have resistance to a type of damage associated with that color, as shown on the table below. The DM chooses the color or determines it randomly.Absorbing Tattood10ColorTattoo1GreenAcid Absorbing Tattoo2BlueCold Absorbing Tattoo3RedFire Absorbing Tattoo4WhiteForce Absorbing Tattoo5YellowLightning Absorbing Tattoo6BlackNecrotic Absorbing Tattoo7VioletPoison Absorbing Tattoo8SilverPsychic Absorbing Tattoo9GoldRadiant Absorbing Tattoo10OrangeThunder Absorbing Tattoo Damage Absorption. When you take damage of the chosen type, you can use your reaction to gain immunity against that instance of the damage, and you regain a number of hit points equal to half the damage you would have taken. Once this reaction is used, it can&#39;t be used again until the next dawn.Multiple variations of this item exist, as listed below:Acid Absorbing TattooCold Absorbing TattooFire Absorbing TattooForce Absorbing TattooLightning Absorbing TattooNecrotic Absorbing TattooPoison Absorbing TattooPsychic Absorbing TattooRadiant Absorbing TattooThunder Absorbing Tattoo



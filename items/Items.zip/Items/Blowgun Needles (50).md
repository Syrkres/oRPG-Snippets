---
cssclass: oRPGPage
fileType: item
itemType: ammunition
name: blowgun_needles_(50)
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Blowgun Needles (50)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Blowgun Needles (50)
**Type:** ammunition

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** 1 lb.

**Description:**



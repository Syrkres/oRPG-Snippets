---
cssclass: oRPGPage
fileType: item
itemType: armor_(shield)
name: arrow-catching_shield
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: 6_lb.
properties: ac_+2
---
> [!oRPG-Item]
> # Arrow-Catching Shield
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | armor (shield) |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 6 lb. |
>  |**Properties** | AC +2 |
> | **Source** | DMG |

#  Arrow-Catching Shield
**Type:** armor (shield)

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:** AC +2
**Value:** Varies
**Weight:** 6 lb.

**Description:** You gain a +2 bonus to AC against ranged attacks while you wield this shield. This bonus is in addition to the shield&#39;s normal bonus to AC. In addition, whenever an attacker makes a ranged attack against a target within 5 feet of you, you can use your reaction to become the target of the attack instead.



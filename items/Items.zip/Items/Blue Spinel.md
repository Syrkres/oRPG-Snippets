---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: blue_spinel
source: dmg
rarity: none
attunement: none_required
value: 500_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Blue Spinel
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Blue Spinel
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 500 gp
**Weight:** Varies

**Description:** A transparent deep blue gemstone.



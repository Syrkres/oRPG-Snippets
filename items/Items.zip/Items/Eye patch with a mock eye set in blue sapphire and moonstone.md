---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: eye_patch_with_a_mock_eye_set_in_blue_sapphire_and_moonstone
source: dmg
rarity: none
attunement: none_required
value: 2500_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Eye patch with a mock eye set in blue sapphire and moonstone
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Eye patch with a mock eye set in blue sapphire and moonstone
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 2,500 gp
**Weight:** Varies

**Description:**



---
cssclass: oRPGPage
fileType: item
itemType: weapon_(greatclub)_simple_weapon_melee_weapon
name: dragon_thighbone_club
source: skt
rarity: unknown_(magic)
attunement: attunement_optional
value: varies
weight: 250_lb.
properties: 1d8_bludgeoning_-_two-handed
---
> [!oRPG-Item]
> # Dragon Thighbone Club
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (greatclub), simple weapon, melee weapon |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | Attunement Optional |
> | **Value** | Varies |
>  | **Weight**| 250 lb. |
>  |**Properties** | 1d8, bludgeoning, - two-handed |
> | **Source** | SKT |

#  Dragon Thighbone Club
**Type:** weapon (greatclub), simple weapon, melee weapon

**Rarity:** Unknown (magic)
**Attunement:** Attunement Optional
**Source:** SKT
**Properties:** 1d8, bludgeoning, - two-handed
**Value:** Varies
**Weight:** 250 lb.

**Description:** This red dragon&#39;s thighbone is 14 feet long, 250 lbs, and is wrapped in old leather, suggesting that it was once used as a giant&#39;s greatclub.When you hit a creature of the dragon type with this weapon, it deals an extra 2d8 bludgeoning damage.If you attune to the greatclub, it magically shrinks to a size that you can wield effectively. Two-Handed. This weapon requires two hands to use. This property is relevant only when you attack with the weapon, not when you simply hold it.



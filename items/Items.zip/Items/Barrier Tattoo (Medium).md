---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item_(tattoo)
name: barrier_tattoo_(medium)
source: tce
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Barrier Tattoo (Medium)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item (tattoo) |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | TCE |

#  Barrier Tattoo (Medium)
**Type:** wondrous item (tattoo)

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Produced by a special needle, this magic tattoo depicts protective imagery and uses ink that resembles liquid metal. Tattoo Attunement. To attune to this item, you hold the needle to your skin where you want the tattoo to appear, pressing the needle there throughout the attunement process. When the attunement is complete, the needle turns into the ink that becomes the tattoo, which appears on the skin.If your attunement to the tattoo ends, the tattoo vanishes, and the needle reappears in your space. Protection. While you aren&#39;t wearing armor, the tattoo grants you an Armor Class of 15 + your Dexterity modifier (maximum of +2). You can use a shield and still gain this benefit.



---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: crossbow_bolt_case
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Crossbow Bolt Case
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Crossbow Bolt Case
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** 1 lb.

**Description:** This wooden case can hold up to twenty crossbow bolts.



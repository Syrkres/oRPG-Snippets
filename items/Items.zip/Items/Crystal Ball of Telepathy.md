---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: crystal_ball_of_telepathy
source: dmg
rarity: legendary
attunement: requires_attunement
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Crystal Ball of Telepathy
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Crystal Ball of Telepathy
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** This crystal ball is about 6 inches in diameter. While touching it, you can cast the scrying spell (save DC 17) with it.While scrying with the crystal ball, you can communicate telepathically with creatures you can see within 30 feet of the spell&#39;s sensor. You can also use an action to cast the suggestion spell (save DC 17) through the sensor on one of those creatures. You don&#39;t need to concentrate on this suggestion to maintain it during its duration, but it ends if scrying ends. Once used, the suggestion power of the crystal ball can&#39;t be used again until the next dawn.



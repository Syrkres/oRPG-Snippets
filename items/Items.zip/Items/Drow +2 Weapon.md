---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: drow_+2_weapon
source: mm
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Drow +2 Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | MM |

#  Drow +2 Weapon
**Type:** generic variant

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** MM
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +2 bonus to attack and damage rolls made with this weapon. This weapon loses its enchantment bonus permanently if it is exposed to sunlight for 1 hour or longer. Base items. This item variant can be applied to the following base items:Antimatter Rifle (Drow +2 Antimatter Rifle)Automatic Pistol (Drow +2 Automatic Pistol)Automatic Rifle (Drow +2 Automatic Rifle)Battleaxe (Drow +2 Battleaxe)Blowgun (Drow +2 Blowgun)Club (Drow +2 Club)Dagger (Drow +2 Dagger)Dart (Drow +2 Dart)Double-Bladed Scimitar (Drow +2 Double-Bladed Scimitar)Flail (Drow +2 Flail)Glaive (Drow +2 Glaive)Greataxe (Drow +2 Greataxe)Greatclub (Drow +2 Greatclub)Greatsword (Drow +2 Greatsword)Halberd (Drow +2 Halberd)Hand Crossbow (Drow +2 Hand Crossbow)Handaxe (Drow +2 Handaxe)Heavy Crossbow (Drow +2 Heavy Crossbow)Hooked Shortspear (Drow +2 Hooked Shortspear)Hunting Rifle (Drow +2 Hunting Rifle)Javelin (Drow +2 Javelin)Lance (Drow +2 Lance)Laser Pistol (Drow +2 Laser Pistol)Laser Rifle (Drow +2 Laser Rifle)Light Crossbow (Drow +2 Light Crossbow)Light Hammer (Drow +2 Light Hammer)Light Repeating Crossbow (Drow +2 Light Repeating Crossbow)Longbow (Drow +2 Longbow)Longsword (Drow +2 Longsword)Mace (Drow +2 Mace)Maul (Drow +2 Maul)Morningstar (Drow +2 Morningstar)Musket (Drow +2 Musket)Pike (Drow +2 Pike)Pistol (Drow +2 Pistol)Quarterstaff (Drow +2 Quarterstaff)Rapier (Drow +2 Rapier)Revolver (Drow +2 Revolver)Scimitar (Drow +2 Scimitar)Shortbow (Drow +2 Shortbow)Shortsword (Drow +2 Shortsword)Shotgun (Drow +2 Shotgun)Sickle (Drow +2 Sickle)Sling (Drow +2 Sling)Spear (Drow +2 Spear)Trident (Drow +2 Trident)War Pick (Drow +2 War Pick)Warhammer (Drow +2 Warhammer)Whip (Drow +2 Whip)Yklwa (Drow +2 Yklwa)



---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +1_armor
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +1 Armor
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +1 Armor
**Type:** generic variant

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +1 bonus to AC while wearing this armor. Base items. This item variant can be applied to the following base items:Breastplate (+1 Breastplate)Chain Mail (+1 Chain Mail)Chain Shirt (+1 Chain Shirt)Half Plate Armor (+1 Half Plate Armor)Hide Armor (+1 Hide Armor)Leather Armor (+1 Leather Armor)Padded Armor (+1 Padded Armor)Plate Armor (+1 Plate Armor)Ring Mail (+1 Ring Mail)Scale Mail (+1 Scale Mail)Spiked Armor (+1 Spiked Armor)Splint Armor (+1 Splint Armor)Studded Leather Armor (+1 Studded Leather Armor)



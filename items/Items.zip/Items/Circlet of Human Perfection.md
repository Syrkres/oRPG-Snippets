---
cssclass: oRPGPage
fileType: item
itemType: other
name: circlet_of_human_perfection
source: wdmm
rarity: uncommon
attunement: requires_attunement_by_a_humanoid
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Circlet of Human Perfection
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement By A Humanoid |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WDMM |

#  Circlet of Human Perfection
**Type:** other

**Rarity:** Uncommon
**Attunement:** Requires Attunement By A Humanoid
**Source:** WDMM
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** The Circlet of Human Perfection transforms its attuned wearer into an attractive human of average height and weight. The circlet chooses the physical characteristics of the form, such as age, gender, skin color, hair color, and voice. Except for size, the wearer&#39;s statistics and racial traits don&#39;t change, nor do items worn or carried by the wearer. Removing the circlet ends the effect.



---
cssclass: oRPGPage
fileType: item
itemType: food_and_drink
name: ale_(mug)
source: phb
rarity: none
attunement: none_required
value: 4_cp
weight: varies
properties:
---
> [!oRPG-Item]
> # Ale (Mug)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | food and drink |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 4 cp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Ale (Mug)
**Type:** food and drink

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 4 cp
**Weight:** Varies

**Description:**



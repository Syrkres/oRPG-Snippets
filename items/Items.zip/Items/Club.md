---
cssclass: oRPGPage
fileType: item
itemType: weapon_simple_weapon_melee_weapon
name: club
source: phb
rarity: none
attunement: none_required
value: 1_sp
weight: 2_lb.
properties: 1d4_bludgeoning_-_light
---
> [!oRPG-Item]
> # Club
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon, simple weapon, melee weapon |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 sp |
>  | **Weight**| 2 lb. |
>  |**Properties** | 1d4, bludgeoning, - light |
> | **Source** | PHB |

#  Club
**Type:** weapon, simple weapon, melee weapon

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** 1d4, bludgeoning, - light
**Value:** 1 sp
**Weight:** 2 lb.

**Description:**  Light. A light weapon is small and easy to handle, making it ideal for use when fighting with two weapons.



---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: book
source: phb
rarity: none
attunement: none_required
value: 25_gp
weight: 5_lb.
properties:
---
> [!oRPG-Item]
> # Book
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 25 gp |
>  | **Weight**| 5 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Book
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 25 gp
**Weight:** 5 lb.

**Description:** A book might contain poetry, historical accounts, information pertaining to a particular field of lore, diagrams and notes on gnomish contraptions, or just about anything else that can be represented using text or pictures. A book of spells is a spellbook.



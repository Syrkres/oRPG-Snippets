---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: common_glamerweave
source: erlw
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Common Glamerweave
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ERLW |

#  Common Glamerweave
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** ERLW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Glamerweave is clothing imbued with harmless illusory magic. While wearing the common version of these clothes, you can use a bonus action to create a moving illusory pattern within the cloth.



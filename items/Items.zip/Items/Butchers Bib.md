---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: butchers_bib
source: egw
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Butcher&#39;s Bib
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Butcher&#39;s Bib
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This black leather apron is perpetually covered by blood, even after being washed off. You gain the following benefits while wearing the apron:Once per turn when you roll damage for a melee attack with a weapon, you can reroll the weapon&#39;s damage dice. If you do so, you must use the second total.Your weapon attacks that deal slashing damage score a critical hit on a roll of 19 or 20 on the d20.



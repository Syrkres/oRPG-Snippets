---
cssclass: oRPGPage
fileType: item
itemType: weapon_(sickle)_simple_weapon_melee_weapon
name: +3_moon_sickle
source: tce
rarity: very_rare
attunement: requires_attunement_by_a_druid_or_ranger
value: varies
weight: 2_lb.
properties: 1d4_slashing_-_light
---
> [!oRPG-Item]
> # +3 Moon Sickle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (sickle), simple weapon, melee weapon |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement By A Druid Or Ranger |
> | **Value** | Varies |
>  | **Weight**| 2 lb. |
>  |**Properties** | 1d4, slashing, - light |
> | **Source** | TCE |

#  +3 Moon Sickle
**Type:** weapon (sickle), simple weapon, melee weapon

**Rarity:** Very Rare
**Attunement:** Requires Attunement By A Druid Or Ranger
**Source:** TCE
**Properties:** 1d4, slashing, - light
**Value:** Varies
**Weight:** 2 lb.

**Description:** This silver-bladed sickle glimmers softly with moonlight. While holding this magic weapon, you gain a +3 bonus to attack and damage rolls made with it, and you gain a +3 bonus to spell attack rolls and the saving throw DCs of your druid and ranger spells. In addition, you can use the sickle as a spellcasting focus for your druid and ranger spells.When you cast a spell that restores hit points, you can roll a d4 and add the number rolled to the amount of hit points restored, provided you are holding the sickle. Light. A light weapon is small and easy to handle, making it ideal for use when fighting with two weapons.



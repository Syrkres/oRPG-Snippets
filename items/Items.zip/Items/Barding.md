---
cssclass: oRPGPage
fileType: item
itemType: tack_and_harness
name: barding
source: phb
rarity: none
attunement: none_required
value: base_value_×4
weight: base_weight_×2
properties:
---
> [!oRPG-Item]
> # Barding
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | tack and harness |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | base value ×4 |
>  | **Weight**| base weight ×2 |
>  |**Properties** |  |
> | **Source** | PHB |

#  Barding
**Type:** tack and harness

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** base value ×4
**Weight:** base weight ×2

**Description:** Barding is armor designed to protect an animal&#39;s head, neck, chest, and body. Any type of armor shown on the Armor table in this chapter can be purchased as barding. The cost is four times the equivalent armor made for humanoids, and it weighs twice as much. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate Barding)Chain Mail (Chain Mail Barding)Chain Shirt (Chain Shirt Barding)Half Plate Armor (Half Plate Barding)Hide Armor (Hide Barding)Leather Armor (Leather Barding)Padded Armor (Padded Barding)Plate Armor (Plate Barding)Ring Mail (Ring Mail Barding)Scale Mail (Scale Mail Barding)Spiked Armor (Spiked Barding)Splint Armor (Splint Barding)Studded Leather Armor (Studded Leather Barding)



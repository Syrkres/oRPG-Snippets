---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: dimir_keyrune
source: ggr
rarity: very_rare
attunement: requires_attunement_by_a_member_of_the_dimir_guild
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dimir Keyrune
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement By A Member Of The Dimir Guild |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | GGR |

#  Dimir Keyrune
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement By A Member Of The Dimir Guild
**Source:** GGR
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This keyrune, carved from black stone accented with steel, resembles a stylized horror. On command, it transforms into an intellect devourer that resembles the Dimir guild symbol, with six bladelike legs. The creature exists for up to 24 hours. During that time, it pursues only a single mission you give it—usually an assignment to take over someone&#39;s body, either to impersonate that person for a brief time or to extract secrets from their mind. When the mission is complete, the creature returns to you, reports its success, and reverts to its keyrune form.When you use an action to speak the item&#39;s command word and place the keyrune on the ground in an unoccupied space within 5 feet of you, the keyrune transforms into a intellect devourer. If there isn&#39;t enough space for the creature, the keyrune doesn&#39;t transform.The creature is friendly to you, your companions, and other members of your guild (unless those guild members are hostile to you). It understands your languages and obeys your spoken commands. If you issue no commands, the creature takes the Dodge action and moves to avoid danger.At the end of the duration, the creature reverts to its keyrune form. It reverts early if it drops to 0 hit points or if you use an action to speak the command word again while touching it. When the creature reverts to its keyrune form, it can&#39;t transform again until 36 hours have passed.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: amethyst_lodestone
source: ftd
rarity: very_rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Amethyst Lodestone
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  Amethyst Lodestone
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This fist-sized chunk of amethyst is infused with an amethyst dragon&#39;s ability to bend gravitational forces. While you are carrying the lodestone, you have advantage on Strength saving throws.The lodestone has 6 charges for the following properties, which you can use while you are holding the stone. The stone regains 1d6 expended charges daily at dawn. Flight. As a bonus action, you can expend 1 charge to gain the power of flight for 10 minutes. For the duration, you gain a flying speed equal to your walking speed, and you can hover. Gravitational Thrust. As an action, you can expend 1 charge to focus gravity around a creature you can see within 60 feet of you. The target must succeed on a DC 18 Strength saving throw or be pushed up to 20 feet in a direction of your choice. Reverse Gravity. As an action, you can expend 3 charges to cast reverse gravity from the stone (save DC 18).



---
cssclass: oRPGPage
fileType: item
itemType: explosive_renaissance
name: bomb
source: dmg
rarity: none
attunement: none_required
value: 150_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Bomb
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | explosive, renaissance |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 150 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Bomb
**Type:** explosive, renaissance

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 150 gp
**Weight:** 1 lb.

**Description:** As an action, a character can light this bomb and throw it at a point up to 60 feet away. Each creature within 5 feet of that point must succeed on a DC 12 Dexterity saving throw or take 3d6 fire damage.



---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: dungeoneers_pack
source: phb
rarity: none
attunement: none_required
value: 12_gp
weight: 61½_lb.
properties:
---
> [!oRPG-Item]
> # Dungeoneer&#39;s Pack
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 12 gp |
>  | **Weight**| 61½ lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Dungeoneer&#39;s Pack
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 12 gp
**Weight:** 61½ lb.

**Description:** Includes:a backpacka crowbara hammer10 pitons10 torchesa tinderbox10 days of rationsa waterskin50 feet of hempen rope



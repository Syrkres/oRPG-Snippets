---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: astral_shard
source: tce
rarity: rare
attunement: requires_attunement_by_a_sorcerer
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Astral Shard
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement By A Sorcerer |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | TCE |

#  Astral Shard
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement By A Sorcerer
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This crystal is a solidified shard of the Astral Plane, swirling with silver mist. As an action, you can attach the shard to a Tiny object (such as a weapon or a piece of jewelry) or detach it. It falls off if your attunement to it ends. You can use the shard as a spellcasting focus while you hold or wear it.When you use a Metamagic option on a spell while you are holding or wearing the shard, immediately after casting the spell you can teleport to an unoccupied space you can see within 30 feet of you.



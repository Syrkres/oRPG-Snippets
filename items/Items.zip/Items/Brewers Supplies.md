---
cssclass: oRPGPage
fileType: item
itemType: artisan&#39;s_tools
name: brewers_supplies
source: phb
rarity: none
attunement: none_required
value: 20_gp
weight: 9_lb.
properties:
---
> [!oRPG-Item]
> # Brewer&#39;s Supplies
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Artisan&#39;s Tools |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 20 gp |
>  | **Weight**| 9 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Brewer&#39;s Supplies
**Type:** Artisan&#39;s Tools

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 20 gp
**Weight:** 9 lb.

**Description:** These special tools include the items needed to pursue a craft or trade. Proficiency with a set of artisan&#39;s tools lets you add your proficiency bonus to any ability checks you make using the tools in your craft. Each type of artisan&#39;s tools requires a separate proficiency.Brewing is the art of producing beer. Not only does beer serve as an alcoholic beverage, but the process of brewing purifies water. Crafting beer takes weeks of fermentation, but only a few hours of work. Components. Brewer&#39;s supplies include a large glass jug, a quantity of hops, a siphon, and several feet of tubing. History. Proficiency with brewer&#39;s supplies gives you additional insight on Intelligence (History) checks concerning events that involve alcohol as a significant element. Medicine. This tool proficiency grants additional insight when you treat anyone suffering from alcohol poisoning or when you can use alcohol to dull pain. Persuasion. A stiff drink can help soften the hardest heart. Your proficiency with brewer&#39;s supplies can help you ply someone with drink, giving them just enough alcohol to mellow their mood. Potable Water. Your knowledge of brewing enables you to purify water that would otherwise be undrinkable. As part of a long rest, you can purify up to 6 gallons of water, or 1 gallon as part of a short rest.Brewer&#39;s SuppliesActivityDCDetect poison or impurities in a drink10Identify alcohol15Ignore effects of alcohol20See the Tool Proficiencies entry for more information.



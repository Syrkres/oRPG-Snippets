---
cssclass: oRPGPage
fileType: item
itemType: ammunition_generic_variant
name: +1_ammunition
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +1 Ammunition
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition, generic variant |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +1 Ammunition
**Type:** ammunition, generic variant

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +1 bonus to attack and damage rolls made with this piece of magic ammunition. Once it hits a target, the ammunition is no longer magical. Base items. This item variant can be applied to the following base items:Arrow (+1 Arrow)Blowgun Needle (+1 Blowgun Needle)Crossbow Bolt (+1 Crossbow Bolt)Energy Cell (+1 Energy Cell)Modern Bullet (+1 Modern Bullet)Renaissance Bullet (+1 Renaissance Bullet)Sling Bullet (+1 Sling Bullet)



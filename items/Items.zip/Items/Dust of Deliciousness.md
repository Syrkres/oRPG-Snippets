---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: dust_of_deliciousness
source: egw
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dust of Deliciousness
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Dust of Deliciousness
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This reddish brown dust can be sprinkled over any edible substance to greatly improve the flavor. The dust also dulls the eater&#39;s senses: anyone eating food treated with this dust has disadvantage on Wisdom ability checks and Wisdom saving throws for 1 hour. There is enough dust to flavor six servings.



---
cssclass: oRPGPage
fileType: item
itemType: heavy_armor
name: chain_mail
source: phb
rarity: none
attunement: none_required
value: 75_gp
weight: 55_lb.
properties: ac_16
---
> [!oRPG-Item]
> # Chain Mail
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | heavy armor |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 75 gp |
>  | **Weight**| 55 lb. |
>  |**Properties** | AC 16 |
> | **Source** | PHB |

#  Chain Mail
**Type:** heavy armor

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** AC 16
**Value:** 75 gp
**Weight:** 55 lb.

**Description:** Made of interlocking metal rings, chain mail includes a layer of quilted fabric worn underneath the mail to prevent chafing and to cushion the impact of blows. The suit includes gauntlets.The wearer has disadvantage on Dexterity (Stealth) checks.If the wearer has a Strength score lower than 13, their speed is reduced by 10 feet.



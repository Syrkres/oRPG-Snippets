---
cssclass: oRPGPage
fileType: item
itemType: mount
name: donkey
source: phb
rarity: none
attunement: none_required
value: 8_gp
weight: varies
properties: speed:_40_carrying_capacity:_420_lb.
---
> [!oRPG-Item]
> # Donkey
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | mount |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 8 gp |
>  | **Weight**| Varies |
>  |**Properties** | Speed: 40, Carrying Capacity: 420 lb. |
> | **Source** | PHB |

#  Donkey
**Type:** mount

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** Speed: 40, Carrying Capacity: 420 lb.
**Value:** 8 gp
**Weight:** Varies

**Description:**



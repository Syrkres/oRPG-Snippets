---
cssclass: oRPGPage
fileType: item
itemType: other
name: barking_box
source: wdh
rarity: unknown
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Barking Box
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | Unknown |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WDH |

#  Barking Box
**Type:** other

**Rarity:** Unknown
**Attunement:** None Required
**Source:** WDH
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This metal cube, 6 inches on a side, has a crank on top. Using an action to wind the crank activates the box for 8 hours. While activated, the box barks whenever it detects vibrations within 15 feet of it, as long as the box and the source of the vibrations are in contact with the same ground or substance. A switch on one side of the box sets the device to emit either a small dog&#39;s bark or a large dog&#39;s bark.



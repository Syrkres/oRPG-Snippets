---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: charlatans_die
source: xge
rarity: common
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Charlatan&#39;s Die
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Charlatan&#39;s Die
**Type:** wondrous item

**Rarity:** Common
**Attunement:** Requires Attunement
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Whenever you roll this six—sided die, you can control which number it rolls.



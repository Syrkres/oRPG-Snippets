---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: belt_of_dwarvenkind
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Belt of Dwarvenkind
> ![[Belt of Dwarvenkind.jpg|Belt of Dwarvenkind]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | 14,900 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Belt of Dwarvenkind
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While wearing this belt, you gain the following benefits:Your Constitution score increases by 2, to a maximum of 20.You have advantage on Charisma (Persuasion) checks made to interact with dwarves.In addition, while attuned to the belt, you have a 50 percent chance each day at dawn of growing a full beard if you&#39;re capable of growing one, or a visibly thicker beard if you already have one.If you aren&#39;t a dwarf, you gain the following additional benefits while wearing the belt:You have advantage on saving throws against poison, and you have resistance against poison damage.You have darkvision out to a range of 60 feet.You can speak, read, and write Dwarvish.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: clockwork_amulet
source: xge
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Clockwork Amulet
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Clockwork Amulet
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This copper amulet contains tiny interlocking gears and is powered by magic from Mechanus, a plane of clockwork predictability. A creature that puts an ear to the amulet can hear faint ticking and whirring noises coming from within.When you make an attack roll while wearing the amulet, you can forgo rolling the d20 to get a 10 on the die. Once used, this property can&#39;t be used again until the next dawn.



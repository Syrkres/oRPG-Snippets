---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: barrel
source: phb
rarity: none
attunement: none_required
value: 2_gp
weight: 70_lb.
properties:
---
> [!oRPG-Item]
> # Barrel
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 gp |
>  | **Weight**| 70 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Barrel
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 2 gp
**Weight:** 70 lb.

**Description:** A barrel can hold 40 gallons of liquid or 4 cubic feet of solids.



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: black_pearl
source: dmg
rarity: none
attunement: none_required
value: 500_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Black Pearl
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Black Pearl
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 500 gp
**Weight:** Varies

**Description:** An opaque pure black gemstone.



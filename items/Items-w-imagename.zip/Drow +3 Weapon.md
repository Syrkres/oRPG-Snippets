---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: drow_+3_weapon
source: mm
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Drow +3 Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | MM |

#  Drow +3 Weapon
**Type:** generic variant

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** MM
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +3 bonus to attack and damage rolls made with this weapon. This weapon loses its enchantment bonus permanently if it is exposed to sunlight for 1 hour or longer. Base items. This item variant can be applied to the following base items:Antimatter Rifle (Drow +3 Antimatter Rifle)Automatic Pistol (Drow +3 Automatic Pistol)Automatic Rifle (Drow +3 Automatic Rifle)Battleaxe (Drow +3 Battleaxe)Blowgun (Drow +3 Blowgun)Club (Drow +3 Club)Dagger (Drow +3 Dagger)Dart (Drow +3 Dart)Double-Bladed Scimitar (Drow +3 Double-Bladed Scimitar)Flail (Drow +3 Flail)Glaive (Drow +3 Glaive)Greataxe (Drow +3 Greataxe)Greatclub (Drow +3 Greatclub)Greatsword (Drow +3 Greatsword)Halberd (Drow +3 Halberd)Hand Crossbow (Drow +3 Hand Crossbow)Handaxe (Drow +3 Handaxe)Heavy Crossbow (Drow +3 Heavy Crossbow)Hooked Shortspear (Drow +3 Hooked Shortspear)Hunting Rifle (Drow +3 Hunting Rifle)Javelin (Drow +3 Javelin)Lance (Drow +3 Lance)Laser Pistol (Drow +3 Laser Pistol)Laser Rifle (Drow +3 Laser Rifle)Light Crossbow (Drow +3 Light Crossbow)Light Hammer (Drow +3 Light Hammer)Light Repeating Crossbow (Drow +3 Light Repeating Crossbow)Longbow (Drow +3 Longbow)Longsword (Drow +3 Longsword)Mace (Drow +3 Mace)Maul (Drow +3 Maul)Morningstar (Drow +3 Morningstar)Musket (Drow +3 Musket)Pike (Drow +3 Pike)Pistol (Drow +3 Pistol)Quarterstaff (Drow +3 Quarterstaff)Rapier (Drow +3 Rapier)Revolver (Drow +3 Revolver)Scimitar (Drow +3 Scimitar)Shortbow (Drow +3 Shortbow)Shortsword (Drow +3 Shortsword)Shotgun (Drow +3 Shotgun)Sickle (Drow +3 Sickle)Sling (Drow +3 Sling)Spear (Drow +3 Spear)Trident (Drow +3 Trident)War Pick (Drow +3 War Pick)Warhammer (Drow +3 Warhammer)Whip (Drow +3 Whip)Yklwa (Drow +3 Yklwa)



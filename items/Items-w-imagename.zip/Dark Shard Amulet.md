---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: dark_shard_amulet
source: xge
rarity: common
attunement: requires_attunement_by_a_warlock
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dark Shard Amulet
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | Requires Attunement By A Warlock |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Dark Shard Amulet
**Type:** wondrous item

**Rarity:** Common
**Attunement:** Requires Attunement By A Warlock
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This amulet is fashioned from a single shard of resilient extraplanar material originating from the realm of your warlock patron. While you are wearing it, you gain the following benefits:You can use the amulet as a spellcasting focus for your warlock spells.You can try to cast a cantrip that you don&#39;t know. The cantrip must be on the warlock spell list, and you must make a DC 10 Intelligence (Arcana) check. If the check succeeds, you cast the spell. If the check fails, so does the spell, and the action used to cast the spell is wasted. In either case, you can&#39;t use this property again until you finish a long rest.



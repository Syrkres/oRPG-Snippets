---
cssclass: oRPGPage
fileType: item
itemType: spellcasting_focus
name: amulet
source: phb
rarity: none
attunement: none_required
value: 5_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Amulet
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | spellcasting focus |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Amulet
**Type:** spellcasting focus

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 gp
**Weight:** 1 lb.

**Description:** A holy symbol is a representation of a god or pantheon.A cleric or paladin can use a holy symbol as a spellcasting focus. To use the symbol in this way, the caster must hold it in hand, wear it visibly, or bear it on a shield.



---
cssclass: oRPGPage
fileType: item
itemType: heavy_armor
name: efreeti_chain
source: dmg
rarity: legendary
attunement: requires_attunement
value: varies
weight: 55_lb.
properties: ac_16
---
> [!oRPG-Item]
> # Efreeti Chain
> ![[Efreeti Chain.jpg|Efreeti Chain]]
>
> |  |   |
> |:--|---|
> |**Type** | heavy armor |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 55 lb. |
>  |**Properties** | AC 16 |
> | **Source** | DMG |

#  Efreeti Chain
**Type:** heavy armor

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:** AC 16
**Value:** Varies
**Weight:** 55 lb.

**Description:** While wearing this armor, you gain a +3 bonus to AC, you are immune to fire damage, and you can understand and speak Primordial. In addition, you can stand on and walk across molten rock as if it were solid ground.The wearer has disadvantage on Dexterity (Stealth) checks.If the wearer has a Strength score lower than 13, their speed is reduced by 10 feet.



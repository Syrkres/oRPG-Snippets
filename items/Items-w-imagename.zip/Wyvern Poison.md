---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear_poison_(injury)
name: wyvern_poison
source: dmg
rarity: none
attunement: none_required
value: 1200_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Wyvern Poison
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear, poison (injury) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1,200 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Wyvern Poison
**Type:** adventuring gear, poison (injury)

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 1,200 gp
**Weight:** Varies

**Description:** This poison must be harvested from a dead or incapacitated wyvern. A creature subjected to this poison must make a DC 15 Constitution saving throw, taking 24 (7d6) poison damage on a failed save, or half as much damage on a successful one.



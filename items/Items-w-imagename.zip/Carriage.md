---
cssclass: oRPGPage
fileType: item
itemType: vehicle_(land)
name: carriage
source: phb
rarity: none
attunement: none_required
value: 100_gp
weight: 600_lb.
properties:
---
> [!oRPG-Item]
> # Carriage
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | vehicle (land) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 100 gp |
>  | **Weight**| 600 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Carriage
**Type:** vehicle (land)

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 100 gp
**Weight:** 600 lb.

**Description:**



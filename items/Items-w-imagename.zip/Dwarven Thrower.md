---
cssclass: oRPGPage
fileType: item
itemType: weapon_(warhammer)_martial_weapon_melee_weapon
name: dwarven_thrower
source: dmg
rarity: very_rare
attunement: requires_attunement_by_a_dwarf
value: varies
weight: 2_lb.
properties: 1d8_bludgeoning_-_thrown_(20&#x2F;60_ft.)_versatile_(1d10)
---
> [!oRPG-Item]
> # Dwarven Thrower
> ![[Dwarven Thrower.jpg|Dwarven Thrower]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (warhammer), martial weapon, melee weapon |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement By A Dwarf |
> | **Value** | 60,312 gp |
>  | **Weight**| 2 lb. |
>  |**Properties** | 1d8, bludgeoning, - thrown (20&#x2F;60 ft.), versatile (1d10) |
> | **Source** | DMG |

#  Dwarven Thrower
**Type:** weapon (warhammer), martial weapon, melee weapon

**Rarity:** Very Rare
**Attunement:** Requires Attunement By A Dwarf
**Source:** DMG
**Properties:** 1d8, bludgeoning, - thrown (20&#x2F;60 ft.), versatile (1d10)
**Value:** Varies
**Weight:** 2 lb.

**Description:** You gain a +3 bonus to attack and damage rolls made with this magic weapon. It has the thrown property with a normal range of 20 feet and a long range of 60 feet. When you hit with a ranged attack using this weapon, it deals an extra 1d8 damage or, if the target is a giant, 2d8 damage. Immediately after the attack, the weapon flies back to your hand. Thrown. If a weapon has the thrown property, you can throw the weapon to make a ranged attack. If the weapon is a melee weapon, you use the same ability modifier for that attack roll and damage roll that you would use for a melee attack with the weapon. For example, if you throw a handaxe, you use your Strength, but if you throw a dagger, you can use either your Strength or your Dexterity, since the dagger has the finesse property. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



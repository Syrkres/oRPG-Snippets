---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: crampons
source: idrotf
rarity: none
attunement: none_required
value: 2_gp
weight: ¼_lb.
properties:
---
> [!oRPG-Item]
> # Crampons
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 gp |
>  | **Weight**| ¼ lb. |
>  |**Properties** |  |
> | **Source** | IDRotF |

#  Crampons
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** IDRotF
**Properties:**
**Value:** 2 gp
**Weight:** ¼ lb.

**Description:** A crampon is a metal plate with spikes that is strapped to the sole of a boot. A creature wearing crampons can&#39;t fall prone while moving across slippery ice.



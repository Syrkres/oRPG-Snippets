---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: yellow_sapphire
source: dmg
rarity: none
attunement: none_required
value: 1000_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Yellow Sapphire
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1,000 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Yellow Sapphire
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 1,000 gp
**Weight:** Varies

**Description:** A transparent fiery yellow or yellow-green gemstone.



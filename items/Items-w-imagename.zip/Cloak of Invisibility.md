---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cloak_of_invisibility
source: dmg
rarity: legendary
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Cloak of Invisibility
> ![[Cloak of Invisibility.png|Cloak of Invisibility]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Cloak of Invisibility
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While wearing this cloak, you can pull its hood over your head to cause yourself to become invisible. While you are invisible, anything you are carrying or wearing is invisible with you. You become visible when you cease wearing the hood. Pulling the hood up or down requires an action.Deduct the time you are invisible, in increments of 1 minute, from the cloak&#39;s maximum duration of 2 hours. After 2 hours of use, the cloak ceases to function. For every uninterrupted period of 12 hours the cloak goes unused, it regains 1 hour of duration.



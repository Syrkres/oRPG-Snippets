---
cssclass: oRPGPage
fileType: item
itemType: other
name: dragons_blood
source: erlw
rarity: none
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dragon&#39;s Blood
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ERLW |

#  Dragon&#39;s Blood
**Type:** other

**Rarity:** None
**Attunement:** None Required
**Source:** ERLW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Introduced into Sharn by Daask, dragon&#39;s blood is a potent and highly addictive stimulant. In addition to inducing euphoria, it can enhance spellcasting ability or even temporarily imbue a user with the ability to cast sorcerer spells. The drug&#39;s effects are potentially dangerous and always unpredictable. This isn&#39;t something a player character should want to use; adventurers are more likely to interfere with Daask smugglers or deal with an addict who accidentally casts a fireball in a crowded street. The specific effects of dragon&#39;s blood are up to you, but you can take inspiration from the Wild Magic Surge table in the Player&#39;s Handbook.



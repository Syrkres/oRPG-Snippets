---
cssclass: oRPGPage
fileType: item
itemType: weapon_(longsword)_martial_weapon_melee_weapon
name: draconic_longsword
source: toa
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: 3_lb.
properties: 1d8_slashing_-_versatile_(1d10)
---
> [!oRPG-Item]
> # Draconic Longsword
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (longsword), martial weapon, melee weapon |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** | 1d8, slashing, - versatile (1d10) |
> | **Source** | ToA |

#  Draconic Longsword
**Type:** weapon (longsword), martial weapon, melee weapon

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** ToA
**Properties:** 1d8, slashing, - versatile (1d10)
**Value:** Varies
**Weight:** 3 lb.

**Description:** This longsword has a dragon-shaped hilt. While you carry it, you gain the ability to speak and understand the Draconic language. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



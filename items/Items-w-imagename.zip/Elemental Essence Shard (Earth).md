---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: elemental_essence_shard_(earth)
source: tce
rarity: rare
attunement: requires_attunement_by_a_sorcerer
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Elemental Essence Shard (Earth)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement By A Sorcerer |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | TCE |

#  Elemental Essence Shard (Earth)
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement By A Sorcerer
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This crackling crystal contains the essence of an elemental plane. As an action, you can attach the shard to a Tiny object (such as a weapon or a piece of jewelry) or detach it. It falls off if your attunement to it ends. You can use the shard as a spellcasting focus while you hold or wear it.When you use a Metamagic option on a spell while you are holding or wearing the shard, you can use the following property: Property. You gain resistance to a damage type of your choice until the start of your next turn.



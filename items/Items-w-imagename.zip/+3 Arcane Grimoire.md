---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: +3_arcane_grimoire
source: tce
rarity: very_rare
attunement: requires_attunement_by_a_wizard
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # +3 Arcane Grimoire
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement By A Wizard |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | TCE |

#  +3 Arcane Grimoire
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement By A Wizard
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** While you are holding this leather-bound book, you can use it as a spellcasting focus for your wizard spells, and you gain a +3 bonus to spell attack rolls and to the saving throw DCs of your wizard spells.You can use this book as a spellbook. In addition, when you use your Arcane Recovery feature, you can increase the number of spell slot levels you regain by 1.



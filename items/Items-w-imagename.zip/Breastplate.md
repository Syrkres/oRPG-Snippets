---
cssclass: oRPGPage
fileType: item
itemType: medium_armor
name: breastplate
source: phb
rarity: none
attunement: none_required
value: 400_gp
weight: 20_lb.
properties: ac_14_+_dex_(max_2)
---
> [!oRPG-Item]
> # Breastplate
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | medium armor |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 400 gp |
>  | **Weight**| 20 lb. |
>  |**Properties** | AC 14 + Dex (max 2) |
> | **Source** | PHB |

#  Breastplate
**Type:** medium armor

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** AC 14 + Dex (max 2)
**Value:** 400 gp
**Weight:** 20 lb.

**Description:** This armor consists of a fitted metal chest piece worn with supple leather. Although it leaves the legs and arms relatively unprotected, this armor provides good protection for the wearer&#39;s vital organs while leaving the wearer relatively unencumbered.



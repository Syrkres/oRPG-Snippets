---
cssclass: oRPGPage
fileType: item
itemType: wand
name: charred_wand_of_magic_missiles
source: wdh
rarity: uncommon
attunement: none_required
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Charred Wand of Magic Missiles
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wand |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | WDH |

#  Charred Wand of Magic Missiles
**Type:** wand

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** WDH
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This wand has 7 charges. While holding it, you can use an action to expend 1 or more of its charges to cast the magic missile spell from it. For 1 charge, you cast the 1st-level version of the spell. You can increase the spell slot level by one for each additional charge you expend.The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand&#39;s last charge, roll a d20. On a 1, the wand crumbles into ashes and is destroyed.Each time you expend a charge from this wand, there is a 50 percent chance that nothing happens and the charge is wasted.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: bracers_of_archery
source: dmg
rarity: uncommon
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Bracers of Archery
> ![[Bracers of Archery.jpg|Bracers of Archery]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Bracers of Archery
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While wearing these bracers, you have proficiency with the longbow and shortbow, and you gain a +2 bonus to damage rolls on ranged attacks made with such weapons.



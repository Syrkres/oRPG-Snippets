---
cssclass: oRPGPage
fileType: item
itemType: artisan&#39;s_tools
name: artisans_tools
source: phb
rarity: none
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Artisan&#39;s Tools
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Artisan&#39;s Tools |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Artisan&#39;s Tools
**Type:** Artisan&#39;s Tools

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** These special tools include the items needed to pursue a craft or trade. Proficiency with a set of artisan&#39;s tools lets you add your proficiency bonus to any ability checks you make using the tools in your craft. Each type of artisan&#39;s tools requires a separate proficiency.Multiple variations of this item exist, as listed below:Alchemist&#39;s SuppliesBrewer&#39;s SuppliesCalligrapher&#39;s SuppliesCarpenter&#39;s ToolsCartographer&#39;s ToolsCobbler&#39;s ToolsCook&#39;s UtensilsGlassblower&#39;s ToolsJeweler&#39;s ToolsLeatherworker&#39;s ToolsMason&#39;s ToolsPainter&#39;s SuppliesPotter&#39;s ToolsSmith&#39;s ToolsTinker&#39;s ToolsWeaver&#39;s ToolsWoodcarver&#39;s ToolsSee the Tool Proficiencies entry for more information.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: wreath_of_the_prism
source: egw
rarity: legendary
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Wreath of the Prism
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Wreath of the Prism
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This loop of golden thorns is inset with dozens of gems representing the five colors of Tiamat.Multiple variations of this item exist, as listed below:Wreath of the Prism (Dormant)Wreath of the Prism (Awakened)Wreath of the Prism (Exalted)



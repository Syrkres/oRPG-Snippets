---
cssclass: oRPGPage
fileType: item
itemType: food_and_drink
name: common_wine_(pitcher)
source: phb
rarity: none
attunement: none_required
value: 2_sp
weight: varies
properties:
---
> [!oRPG-Item]
> # Common Wine (Pitcher)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | food and drink |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 sp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Common Wine (Pitcher)
**Type:** food and drink

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 2 sp
**Weight:** Varies

**Description:**



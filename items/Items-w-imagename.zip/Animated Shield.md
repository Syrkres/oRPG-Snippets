---
cssclass: oRPGPage
fileType: item
itemType: armor_(shield)
name: animated_shield
source: dmg
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 6_lb.
properties: ac_+2
---
> [!oRPG-Item]
> # Animated Shield
> ![[Animated Shield.jpg|Animated Shield]]
>
> |  |   |
> |:--|---|
> |**Type** | armor (shield) |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 6 lb. |
>  |**Properties** | AC +2 |
> | **Source** | DMG |

#  Animated Shield
**Type:** armor (shield)

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:** AC +2
**Value:** Varies
**Weight:** 6 lb.

**Description:** While holding this shield, you can speak its command word as a bonus action to cause it to animate. The shield leaps into the air and hovers in your space to protect you as if you were wielding it, leaving your hands free. The shield remains animated for 1 minute, until you use a bonus action to end this effect, or until you are incapacitated or die, at which point the shield falls to the ground or into your hand if you have one free.



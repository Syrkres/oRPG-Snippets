---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item_(tattoo)
name: acid_absorbing_tattoo
source: tce
rarity: very_rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Acid Absorbing Tattoo
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item (tattoo) |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | TCE |

#  Acid Absorbing Tattoo
**Type:** wondrous item (tattoo)

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Produced by a special needle, this magic tattoo features designs that emphasize one color (green). Tattoo Attunement. To attune to this item, you hold the needle to your skin where you want the tattoo to appear, pressing the needle there throughout the attunement process. When the attunement is complete, the needle turns into the ink that becomes the tattoo, which appears on the skin.If your attunement to the tattoo ends, the tattoo vanishes, and the needle reappears in your space. Damage Resistance. While the tattoo is on your skin, you have resistance to acid damage. Damage Absorption. When you take acid damage, you can use your reaction to gain immunity against that instance of the damage, and you regain a number of hit points equal to half the damage you would have taken. Once this reaction is used, it can&#39;t be used again until the next dawn.



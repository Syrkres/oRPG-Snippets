---
cssclass: oRPGPage
fileType: item
itemType: staff_weapon_simple_weapon_melee_weapon
name: devlins_staff_of_striking
source: toa
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 4_lb.
properties: 1d6_bludgeoning_-_versatile_(1d8)
---
> [!oRPG-Item]
> # Devlin&#39;s Staff of Striking
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | staff, weapon, simple weapon, melee weapon |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d6, bludgeoning, - versatile (1d8) |
> | **Source** | ToA |

#  Devlin&#39;s Staff of Striking
**Type:** staff, weapon, simple weapon, melee weapon

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** ToA
**Properties:** 1d6, bludgeoning, - versatile (1d8)
**Value:** Varies
**Weight:** 4 lb.

**Description:** This staff can be wielded as a magic quarterstaff that grants a +3 bonus to attack and damage rolls made with it.The staff has 10 charges. When you hit with a melee attack using it, you can expend up to 3 of its charges. For each charge you expend, the target takes an extra 1d6 force damage. The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll a d20. On a 1, the staff becomes a nonmagical quarterstaff.If you attune to this staff, you transform into a goat-humanoid hybrid over the course of 3 days. Tieflings are immune to this curse. Throughout the first day, shaggy fur begins to grow all over your body. After 24 hours, your eyes become goat-like, and stumpy horns sprout from your brow. On the last day, your fingers and toes meld into double digits, and the horns grow to full length. This transformation doesn&#39;t prevent you from wielding weapons or casting spells. Remove curse, greater restoration, or any other effect that ends a curse restores your original appearance, but only a wish spell can rid the staff of its power to transform those who attune to it. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



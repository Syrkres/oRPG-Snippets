---
cssclass: oRPGPage
fileType: item
itemType: wand
name: +1_wand_of_the_war_mage
source: dmg
rarity: uncommon
attunement: requires_attunement_by_a_spellcaster
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # +1 Wand of the War Mage
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wand |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement By A Spellcaster |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  +1 Wand of the War Mage
**Type:** wand

**Rarity:** Uncommon
**Attunement:** Requires Attunement By A Spellcaster
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** While you are holding this wand, you gain a +1 bonus to spell attack rolls. In addition, you ignore half cover when making a spell attack.



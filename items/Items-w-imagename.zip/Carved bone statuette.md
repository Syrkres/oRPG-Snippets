---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: carved_bone_statuette
source: dmg
rarity: none
attunement: none_required
value: 25_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Carved bone statuette
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 25 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Carved bone statuette
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 25 gp
**Weight:** Varies

**Description:**



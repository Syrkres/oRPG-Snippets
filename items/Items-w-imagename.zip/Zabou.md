---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: zabou
source: toa
rarity: none
attunement: none_required
value: 10_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Zabou
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ToA |

#  Zabou
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** ToA
**Properties:**
**Value:** 10 gp
**Weight:** Varies

**Description:** Zabou mushrooms feed on offal and the rotting wood of dead trees. If handled carefully, a zabou can be picked or uprooted without causing it to release its spores. If crushed or struck, a zabou releases its spores in a 10-foot-radius sphere. A zabou can also be hurled up to 30 feet away or dropped like a grenade, releasing its cloud of spores on impact. Any creature in that area must succeed on a DC 10 Constitution saving throw or be poisoned for 1 minute. The poisoned creature&#39;s skin itches for the duration. The creature can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success.



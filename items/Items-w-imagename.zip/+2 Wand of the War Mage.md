---
cssclass: oRPGPage
fileType: item
itemType: wand
name: +2_wand_of_the_war_mage
source: dmg
rarity: rare
attunement: requires_attunement_by_a_spellcaster
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # +2 Wand of the War Mage
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wand |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement By A Spellcaster |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  +2 Wand of the War Mage
**Type:** wand

**Rarity:** Rare
**Attunement:** Requires Attunement By A Spellcaster
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** While you are holding this wand, you gain a +2 bonus to spell attack rolls. In addition, you ignore half cover when making a spell attack.



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: copper_alms-coin
source: ggr
rarity: none
attunement: none_required
value: 1_cp
weight: varies
properties:
---
> [!oRPG-Item]
> # Copper Alms-Coin
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 cp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | GGR |

#  Copper Alms-Coin
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** GGR
**Properties:**
**Value:** 1 cp
**Weight:** Varies

**Description:**



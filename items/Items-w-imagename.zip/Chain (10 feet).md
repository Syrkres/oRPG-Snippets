---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: chain_(10_feet)
source: phb
rarity: none
attunement: none_required
value: 5_gp
weight: 10_lb.
properties:
---
> [!oRPG-Item]
> # Chain (10 feet)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 gp |
>  | **Weight**| 10 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Chain (10 feet)
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 gp
**Weight:** 10 lb.

**Description:** A chain has 10 hit points. It can be burst with a successful DC 20 Strength check.



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: black_velvet_mask_stitched_with_silver_thread
source: dmg
rarity: none
attunement: none_required
value: 25_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Black velvet mask stitched with silver thread
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 25 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Black velvet mask stitched with silver thread
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 25 gp
**Weight:** Varies

**Description:**



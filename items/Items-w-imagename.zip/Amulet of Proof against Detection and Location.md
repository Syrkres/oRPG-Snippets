---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: amulet_of_proof_against_detection_and_location
source: dmg
rarity: uncommon
attunement: requires_attunement
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Amulet of Proof against Detection and Location
> ![[Amulet of Proof against Detection and Location.jpg|Amulet of Proof against Detection and Location]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Amulet of Proof against Detection and Location
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** While wearing this amulet, you are hidden from divination magic. You can&#39;t be targeted by such magic or perceived through magical scrying sensors.



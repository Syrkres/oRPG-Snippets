---
cssclass: oRPGPage
fileType: item
itemType: heavy_armor
name: demon_armor
source: dmg
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 65_lb.
properties: ac_18
---
> [!oRPG-Item]
> # Demon Armor
> ![[Demon Armor.jpg|Demon Armor]]
>
> |  |   |
> |:--|---|
> |**Type** | heavy armor |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | 52,260 gp |
>  | **Weight**| 65 lb. |
>  |**Properties** | AC 18 |
> | **Source** | DMG |

#  Demon Armor
**Type:** heavy armor

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:** AC 18
**Value:** Varies
**Weight:** 65 lb.

**Description:** While wearing this armor, you gain a +1 bonus to AC, and you can understand and speak Abyssal. In addition, the armor&#39;s clawed gauntlets turn unarmed strikes with your hands into magic weapons that deal slashing damage, with a +1 bonus to attack and damage rolls and a damage die of 1d8. Curse. Once you don this cursed armor, you can&#39;t doff it unless you are targeted by the remove curse spell or similar magic. While wearing the armor, you have disadvantage on attack rolls against demons and on saving throws against their spells and special abilities.The wearer has disadvantage on Dexterity (Stealth) checks.If the wearer has a Strength score lower than 15, their speed is reduced by 10 feet.



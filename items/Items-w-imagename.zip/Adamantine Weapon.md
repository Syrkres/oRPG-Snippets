---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: adamantine_weapon
source: xge
rarity: unknown
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Adamantine Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Unknown |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Adamantine Weapon
**Type:** generic variant

**Rarity:** Unknown
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Melee weapons made of or coated with adamantine are unusually effective when used to break objects. Whenever an adamantine weapon hits an object, the hit is a critical hit.The adamantine version of a melee weapon costs 500 gp more than the normal version, whether the weapon is made of the metal or coated with it. Base items. This item variant can be applied to the following base items:Antimatter Rifle (Adamantine Antimatter Rifle)Automatic Pistol (Adamantine Automatic Pistol)Automatic Rifle (Adamantine Automatic Rifle)Battleaxe (Adamantine Battleaxe)Blowgun (Adamantine Blowgun)Club (Adamantine Club)Dagger (Adamantine Dagger)Dart (Adamantine Dart)Double-Bladed Scimitar (Adamantine Double-Bladed Scimitar)Flail (Adamantine Flail)Glaive (Adamantine Glaive)Greataxe (Adamantine Greataxe)Greatclub (Adamantine Greatclub)Greatsword (Adamantine Greatsword)Halberd (Adamantine Halberd)Hand Crossbow (Adamantine Hand Crossbow)Handaxe (Adamantine Handaxe)Heavy Crossbow (Adamantine Heavy Crossbow)Hooked Shortspear (Adamantine Hooked Shortspear)Hunting Rifle (Adamantine Hunting Rifle)Javelin (Adamantine Javelin)Lance (Adamantine Lance)Laser Pistol (Adamantine Laser Pistol)Laser Rifle (Adamantine Laser Rifle)Light Crossbow (Adamantine Light Crossbow)Light Hammer (Adamantine Light Hammer)Light Repeating Crossbow (Adamantine Light Repeating Crossbow)Longbow (Adamantine Longbow)Longsword (Adamantine Longsword)Mace (Adamantine Mace)Maul (Adamantine Maul)Morningstar (Adamantine Morningstar)Musket (Adamantine Musket)Pike (Adamantine Pike)Pistol (Adamantine Pistol)Quarterstaff (Adamantine Quarterstaff)Rapier (Adamantine Rapier)Revolver (Adamantine Revolver)Scimitar (Adamantine Scimitar)Shortbow (Adamantine Shortbow)Shortsword (Adamantine Shortsword)Shotgun (Adamantine Shotgun)Sickle (Adamantine Sickle)Sling (Adamantine Sling)Spear (Adamantine Spear)Trident (Adamantine Trident)War Pick (Adamantine War Pick)Warhammer (Adamantine Warhammer)Whip (Adamantine Whip)Yklwa (Adamantine Yklwa)



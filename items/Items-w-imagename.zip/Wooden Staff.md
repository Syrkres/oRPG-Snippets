---
cssclass: oRPGPage
fileType: item
itemType: weapon_spellcasting_focus_simple_weapon
name: wooden_staff
source: phb
rarity: none
attunement: none_required
value: 5_gp
weight: 4_lb.
properties: 1d6_bludgeoning_-_versatile_(1d8)
---
> [!oRPG-Item]
> # Wooden Staff
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon, spellcasting focus, simple weapon |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 gp |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d6, bludgeoning, - versatile (1d8) |
> | **Source** | PHB |

#  Wooden Staff
**Type:** weapon, spellcasting focus, simple weapon

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** 1d6, bludgeoning, - versatile (1d8)
**Value:** 5 gp
**Weight:** 4 lb.

**Description:**  Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.A druid can use this object as a spellcasting focus.



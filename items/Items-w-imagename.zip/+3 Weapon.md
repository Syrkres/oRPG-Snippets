---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +3_weapon
source: dmg
rarity: very_rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +3 Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +3 Weapon
**Type:** generic variant

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +3 bonus to attack and damage rolls made with this magic weapon. Base items. This item variant can be applied to the following base items:Antimatter Rifle (+3 Antimatter Rifle)Automatic Pistol (+3 Automatic Pistol)Automatic Rifle (+3 Automatic Rifle)Battleaxe (+3 Battleaxe)Blowgun (+3 Blowgun)Club (+3 Club)Dagger (+3 Dagger)Dart (+3 Dart)Double-Bladed Scimitar (+3 Double-Bladed Scimitar)Flail (+3 Flail)Glaive (+3 Glaive)Greataxe (+3 Greataxe)Greatclub (+3 Greatclub)Greatsword (+3 Greatsword)Halberd (+3 Halberd)Hand Crossbow (+3 Hand Crossbow)Handaxe (+3 Handaxe)Heavy Crossbow (+3 Heavy Crossbow)Hooked Shortspear (+3 Hooked Shortspear)Hunting Rifle (+3 Hunting Rifle)Javelin (+3 Javelin)Lance (+3 Lance)Laser Pistol (+3 Laser Pistol)Laser Rifle (+3 Laser Rifle)Light Crossbow (+3 Light Crossbow)Light Hammer (+3 Light Hammer)Light Repeating Crossbow (+3 Light Repeating Crossbow)Longbow (+3 Longbow)Longsword (+3 Longsword)Mace (+3 Mace)Maul (+3 Maul)Morningstar (+3 Morningstar)Musket (+3 Musket)Pike (+3 Pike)Pistol (+3 Pistol)Quarterstaff (+3 Quarterstaff)Rapier (+3 Rapier)Revolver (+3 Revolver)Scimitar (+3 Scimitar)Shortbow (+3 Shortbow)Shortsword (+3 Shortsword)Shotgun (+3 Shotgun)Sickle (+3 Sickle)Sling (+3 Sling)Spear (+3 Spear)Trident (+3 Trident)War Pick (+3 War Pick)Warhammer (+3 Warhammer)Whip (+3 Whip)Yklwa (+3 Yklwa)



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cube_of_force
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Cube of Force
> ![[Cube of Force.jpg|Cube of Force]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | 62,000 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Cube of Force
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This cube is about an inch across. Each face has a distinct marking on it that can be pressed. The cube starts with 36 charges, and it regains 1d20 expended charges daily at dawn.You can use an action to press one of the cube&#39;s faces, expending a number of charges based on the chosen face, as shown in the Cube of Force Faces table. Each face has a different effect. If the cube has insufficient charges remaining, nothing happens. Otherwise, a barrier of invisible force springs into existence, forming a cube 15 feet on a side. The barrier is centered on you, moves with you, and lasts for 1 minute, until you use an action to press the cube&#39;s sixth face, or the cube runs out of charges. You can change the barrier&#39;s effect by pressing a different face of the cube and expending the requisite number of charges, resetting the duration. If your movement causes the barrier to come into contact with a solid object that can&#39;t pass through the cube, you can&#39;t move any closer to that object as long as the barrier remains.Cube of Force FacesFaceChargesEffect11Gases, wind, and fog can&#39;t pass through the barrier.22Nonliving matter can&#39;t pass through the barrier. Walls, floors, and ceilings can pass through at your discretion.33Living matter can&#39;t pass through the barrier.44Spell effects can&#39;t pass through the barrier.55Nothing can pass through the barrier. Walls, floors, and ceilings can pass through at your discretion.60The barrier deactivates.The cube loses charges when the barrier is targeted by certain spells or comes into contact with certain spell or magic item effects, as shown in the table below.Spell or itemCharges LostDisintegrate1d12Horn of blasting1d10Passwall1d6Prismatic spray1d20Wall of fire1d4



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: dragon-touched_focus
source: ftd
rarity: varies
attunement: requires_attunement_by_a_spellcaster
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dragon-Touched Focus
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Varies |
> | **Attunement** | Requires Attunement By A Spellcaster |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  Dragon-Touched Focus
**Type:** wondrous item

**Rarity:** Varies
**Attunement:** Requires Attunement By A Spellcaster
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This wondrous item can be a scepter, an orb, an amulet, a crystal, or another finely crafted object. It typically incorporates imagery of dragons&#39; wings, claws, teeth, or scales.Multiple variations of this item exist, as listed below:Slumbering Dragon-Touched FocusStirring Dragon-Touched FocusWakened Dragon-Touched FocusAscendant Dragon-Touched Focus



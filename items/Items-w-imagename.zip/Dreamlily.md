---
cssclass: oRPGPage
fileType: item
itemType: other
name: dreamlily
source: erlw
rarity: none
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dreamlily
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | other |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ERLW |

#  Dreamlily
**Type:** other

**Rarity:** None
**Attunement:** None Required
**Source:** ERLW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** A psychoactive liquid that smells and tastes like your favorite beverage, essence of dreamlily is a Sarlonan opiate. First imported to help manage pain during the Last War, it&#39;s now the most commonly abused substance in Sharn. Though dreamlily isn&#39;t illegal if used for medicinal purposes, it&#39;s heavily taxed, and thus most dreamlily is smuggled in and sold on the black market. Dreamlily dens can be found across the lower wards. Consuming dreamlily causes disorienting euphoria and brings about remarkable resistance to pain. A creature under the effects of dreamlily is poisoned for 1 hour. While poisoned in this way, the creature is immune to fear, and the first time it drops to 0 hit points without being killed outright, it drops to 1 hit point instead. A dose of dreamlily costs around 1 gp, or up to ten times that if purchased through legal channels. There are many varieties of the drug, however, and the duration or the price might vary accordingly.



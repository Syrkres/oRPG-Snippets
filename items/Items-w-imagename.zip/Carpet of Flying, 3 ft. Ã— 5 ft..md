---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: carpet_of_flying,_3_ft._×_5_ft.
source: dmg
rarity: very_rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Carpet of Flying, 3 ft. × 5 ft.
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Carpet of Flying, 3 ft. × 5 ft.
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You can speak the carpet&#39;s command word as an action to make the carpet hover and fly. It moves according to your spoken directions, provided that you are within 30 feet of it.A 3 ft. × 5 ft. carpet can carry up to 200 lb. at a fly speed of 80 feet. A carpet can carry up to twice this weight, but it flies at half speed if it carries more than its normal capacity.



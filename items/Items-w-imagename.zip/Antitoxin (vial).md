---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: antitoxin_(vial)
source: phb
rarity: none
attunement: none_required
value: 50_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Antitoxin (vial)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Antitoxin (vial)
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 50 gp
**Weight:** Varies

**Description:** A creature that drinks this vial of liquid gains advantage on saving throws against poison for 1 hour. It confers no benefit to undead or constructs.



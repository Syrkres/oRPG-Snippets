---
cssclass: oRPGPage
fileType: item
itemType: gaming_set
name: dragonchess_set
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: ½_lb.
properties:
---
> [!oRPG-Item]
> # Dragonchess Set
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Gaming Set |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| ½ lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Dragonchess Set
**Type:** Gaming Set

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** ½ lb.

**Description:** If you are proficient with a gaming set, you can add your proficiency bonus to ability checks you make to play a game with that set. Each type of gaming set requires a separate proficiency.See the Tool Proficiencies entry for more information.Proficiency with a gaming set applies to one type of game, such as Three-Dragon Ante or games of chance that use dice. Components. A gaming set has all the pieces needed to play a specific game or type of game, such as a complete deck of cards or a board and tokens. History. Your mastery of a game includes knowledge of its history, as well as of important events it was connected to or prominent historical figures involved with it. Insight. Playing games with someone is a good way to gain understanding of their personality, granting you a better ability to discern their lies from their truths and read their mood. Sleight of Hand. Sleight of Hand is a useful skill for cheating at a game, as it allows you to swap pieces, palm cards, or alter a die roll. Alternatively, engrossing a target in a game by manipulating the components with dexterous movements is a great distraction for a pickpocketing attempt.Gaming SetActivityDCCatch a player cheating15Gain insight into an opponent&#39;s personality15



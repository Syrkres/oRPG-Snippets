---
cssclass: oRPGPage
fileType: item
itemType: weapon_(mace)_simple_weapon_melee_weapon
name: bonecounter
source: sdw
rarity: rare
attunement: none_required
value: varies
weight: 4_lb.
properties: 1d6_bludgeoning
---
> [!oRPG-Item]
> # Bonecounter
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (mace), simple weapon, melee weapon |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d6, bludgeoning |
> | **Source** | SDW |

#  Bonecounter
**Type:** weapon (mace), simple weapon, melee weapon

**Rarity:** Rare
**Attunement:** None Required
**Source:** SDW
**Properties:** 1d6, bludgeoning
**Value:** Varies
**Weight:** 4 lb.

**Description:** This weapon is a magical +2 mace called Bonecounter. Whenever this weapon is used to destroy an undead creature, a single silver piece appears in the wielder&#39;s pocket.



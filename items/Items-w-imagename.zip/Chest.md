---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: chest
source: phb
rarity: none
attunement: none_required
value: 5_gp
weight: 25_lb.
properties:
---
> [!oRPG-Item]
> # Chest
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 gp |
>  | **Weight**| 25 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Chest
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 gp
**Weight:** 25 lb.

**Description:** A chest holds 12 cubic feet or 300 pounds of gear.



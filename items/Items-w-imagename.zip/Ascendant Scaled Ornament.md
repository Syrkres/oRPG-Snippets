---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: ascendant_scaled_ornament
source: ftd
rarity: legendary
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Ascendant Scaled Ornament
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  Ascendant Scaled Ornament
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This ornament can be jewelry, a cloak, or another wearable accessory. It appears to be fashioned from a dragon&#39;s scale, tooth, or claw, or it incorporates images in those shapes.You gain a +1 bonus to AC, and you can&#39;t be charmed or frightened. Moreover, each creature of your choice within 30 feet of you has advantage on saving throws it makes to avoid being charmed or frightened or to end those conditions on itself.When you would take damage of the type dealt by the breath of the dragon in whose hoard the ornament became Wakened, you can use your reaction to take no damage instead, and you regain hit points equal to the damage you would have taken. Once this property is used, it can&#39;t be used again until the next dawn.While you are wearing the ornament, you gain a flying speed equal to your walking speed and can hover. While you are flying using this speed, spectral dragon wings appear on your back.



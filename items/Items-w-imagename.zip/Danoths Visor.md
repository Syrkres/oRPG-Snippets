---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: danoths_visor
source: egw
rarity: legendary
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Danoth&#39;s Visor
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Danoth&#39;s Visor
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** These mithral-frame goggles with clear diamond lenses were used by the evoker Danoth Oro to spot invisible enemies and scout areas from afar.Multiple variations of this item exist, as listed below:Danoth&#39;s Visor (Dormant)Danoth&#39;s Visor (Awakened)Danoth&#39;s Visor (Exalted)



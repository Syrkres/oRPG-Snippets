---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item_instrument
name: +1_rhythm-makers_drum
source: tce
rarity: uncommon
attunement: requires_attunement_by_a_bard
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # +1 Rhythm-Maker&#39;s Drum
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item, Instrument |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement By A Bard |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | TCE |

#  +1 Rhythm-Maker&#39;s Drum
**Type:** wondrous item, Instrument

**Rarity:** Uncommon
**Attunement:** Requires Attunement By A Bard
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** While holding this drum, you gain a +1 bonus to spell attack rolls and to the saving throw DCs of your bard spells.As an action, you can play the drum to regain one use of your Bardic Inspiration feature. This property of the drum can&#39;t be used again until the next dawn.If you have proficiency with a given musical instrument, you can add your proficiency bonus to any ability checks you make to play music with the instrument.A bard can use a musical instrument as a spellcasting focus, substituting it for any material component that does not list a cost.Each type of musical instrument requires a separate proficiency.See the Tool Proficiencies entry for more information.Proficiency with a musical instrument indicates you are familiar with the techniques used to play it. You also have knowledge of some songs commonly performed with that instrument. History. Your expertise aids you in recalling lore related to your instrument. Performance. Your ability to put on a good show is improved when you incorporate an instrument into your act. Compose a Tune. As part of a long rest, you can compose a new tune and lyrics for your instrument. You might use this ability to impress a noble or spread scandalous rumors with a catchy tune.Musical InstrumentActivityDCIdentify a tune10Improvise a tune20



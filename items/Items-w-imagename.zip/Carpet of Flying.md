---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: carpet_of_flying
source: dmg
rarity: very_rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Carpet of Flying
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | None Required |
> | **Value** | undefined |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Carpet of Flying
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Multiple variations of this item exist, as listed below:Carpet of Flying, 3 ft. × 5 ft.Carpet of Flying, 4 ft. × 6 ft.Carpet of Flying, 5 ft. × 7 ft.Carpet of Flying, 6 ft. × 9 ft.



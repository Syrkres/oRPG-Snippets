---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: defender
source: dmg
rarity: legendary
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Defender
> ![[Defender.jpg|Defender]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Defender
**Type:** generic variant

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You gain a +3 bonus to attack and damage rolls made with this magic weapon.The first time you attack with the sword on each of your turns, you can transfer some or all of the sword&#39;s bonus to your Armor Class, instead of using the bonus on any attacks that turn. For example, you could reduce the bonus to your attack and damage rolls to +1 and gain a +2 bonus to AC. The adjusted bonuses remain in effect until the start of your next turn, although you must hold the sword to gain a bonus to AC from it. Base items. This item variant can be applied to the following base items:Double-Bladed Scimitar (Defender Double-Bladed Scimitar)Greatsword (Defender Greatsword)Longsword (Defender Longsword)Rapier (Defender Rapier)Scimitar (Defender Scimitar)Shortsword (Defender Shortsword)



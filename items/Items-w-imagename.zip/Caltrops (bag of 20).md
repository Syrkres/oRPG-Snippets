---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: caltrops_(bag_of_20)
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: 2_lb.
properties:
---
> [!oRPG-Item]
> # Caltrops (bag of 20)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 2 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Caltrops (bag of 20)
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** 2 lb.

**Description:** As an action, you can spread a single bag of caltrops to cover a 5-foot-square area. Any creature that enters the area must succeed on a DC 15 Dexterity saving throw or stop moving and take 1 piercing damage. Until the creature regains at least 1 hit point, its walking speed is reduced by 10 feet. A creature moving through the area at half speed doesn&#39;t need to make the saving throw.



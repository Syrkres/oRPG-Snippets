---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: balance_of_harmony
source: tftyp
rarity: uncommon
attunement: none_required
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Balance of Harmony
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | TftYP |

#  Balance of Harmony
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** TftYP
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This scale bears celestial symbols on one pan and fiendish symbols on the other. You can use the scale to cast detect evil and good as a ritual. Doing so requires you to place the scale on a solid surface, then sprinkle the pans with holy water or place a transparent gem worth 100 gp in each pan. The scale remains motionless if it detects nothing, tips to one side or the other for good (consecrated) or evil (desecrated), and fluctuates slightly if it detects a creature appropriate to the spell but neither good nor evil. By touching the scales after casting the ritual, you instantly learn any information the spell can normally convey, and then the effect ends.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: amulet_of_health
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Amulet of Health
> ![[Amulet of Health.jpg|Amulet of Health]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Amulet of Health
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** Your Constitution score is 19 while you wear this amulet. It has no effect on you if your Constitution score is already 19 or higher without it.



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: copper_chalice_with_silver_filigree
source: dmg
rarity: none
attunement: none_required
value: 25_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Copper chalice with silver filigree
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 25 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Copper chalice with silver filigree
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 25 gp
**Weight:** Varies

**Description:**



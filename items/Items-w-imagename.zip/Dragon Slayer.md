---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: dragon_slayer
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dragon Slayer
> ![[Dragon Slayer.jpg|Dragon Slayer]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Dragon Slayer
**Type:** generic variant

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You gain a +1 bonus to attack and damage rolls made with this magic weapon.When you hit a dragon with this weapon, the dragon takes an extra 3d6 damage of the weapon&#39;s type. For the purpose of this weapon, &quot;dragon&quot; refers to any creature with the dragon type, including dragon turtles and wyverns. Base items. This item variant can be applied to the following base items:Double-Bladed Scimitar (Dragon Slayer Double-Bladed Scimitar)Greatsword (Dragon Slayer Greatsword)Longsword (Dragon Slayer Longsword)Rapier (Dragon Slayer Rapier)Scimitar (Dragon Slayer Scimitar)Shortsword (Dragon Slayer Shortsword)



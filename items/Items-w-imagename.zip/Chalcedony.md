---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: chalcedony
source: dmg
rarity: none
attunement: none_required
value: 50_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Chalcedony
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Chalcedony
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 50 gp
**Weight:** Varies

**Description:** An opaque white gemstone.



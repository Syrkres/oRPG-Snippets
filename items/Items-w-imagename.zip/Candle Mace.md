---
cssclass: oRPGPage
fileType: item
itemType: weapon_(mace)_simple_weapon_melee_weapon
name: candle_mace
source: bgdia
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: 4_lb.
properties: 1d6_bludgeoning
---
> [!oRPG-Item]
> # Candle Mace
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (mace), simple weapon, melee weapon |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d6, bludgeoning |
> | **Source** | BGDIA |

#  Candle Mace
**Type:** weapon (mace), simple weapon, melee weapon

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** BGDIA
**Properties:** 1d6, bludgeoning
**Value:** Varies
**Weight:** 4 lb.

**Description:** The head of this mace sheds bright light in a 5-foot-radius and dim light for an additional 5 feet. When you wield this mace, you can extinguish or ignite its light as an action.



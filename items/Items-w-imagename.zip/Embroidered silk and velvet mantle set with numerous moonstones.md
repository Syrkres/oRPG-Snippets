---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: embroidered_silk_and_velvet_mantle_set_with_numerous_moonstones
source: dmg
rarity: none
attunement: none_required
value: 2500_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Embroidered silk and velvet mantle set with numerous moonstones
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Embroidered silk and velvet mantle set with numerous moonstones
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 2,500 gp
**Weight:** Varies

**Description:**



---
cssclass: oRPGPage
fileType: item
itemType: spellcasting_focus
name: emblem
source: phb
rarity: none
attunement: none_required
value: 5_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Emblem
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | spellcasting focus |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Emblem
**Type:** spellcasting focus

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 gp
**Weight:** Varies

**Description:** A holy symbol is a representation of a god or pantheon.A cleric or paladin can use a holy symbol as a spellcasting focus. To use the symbol in this way, the caster must hold it in hand, wear it visibly, or bear it on a shield.



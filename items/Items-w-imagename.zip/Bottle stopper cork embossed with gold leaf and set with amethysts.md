---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: bottle_stopper_cork_embossed_with_gold_leaf_and_set_with_amethysts
source: dmg
rarity: none
attunement: none_required
value: 750_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Bottle stopper cork embossed with gold leaf and set with amethysts
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 750 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Bottle stopper cork embossed with gold leaf and set with amethysts
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 750 gp
**Weight:** Varies

**Description:**



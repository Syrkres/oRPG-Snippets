---
cssclass: oRPGPage
fileType: item
itemType: weapon_simple_weapon_melee_weapon
name: yklwa
source: toa
rarity: none
attunement: none_required
value: 1_gp
weight: 3_lb.
properties: 1d8_piercing_-_thrown_(10&#x2F;30_ft.)
---
> [!oRPG-Item]
> # Yklwa
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon, simple weapon, melee weapon |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 3 lb. |
>  |**Properties** | 1d8, piercing, - thrown (10&#x2F;30 ft.) |
> | **Source** | ToA |

#  Yklwa
**Type:** weapon, simple weapon, melee weapon

**Rarity:** None
**Attunement:** None Required
**Source:** ToA
**Properties:** 1d8, piercing, - thrown (10&#x2F;30 ft.)
**Value:** 1 gp
**Weight:** 3 lb.

**Description:** A yklwa (pronounced YICK-ul-wah) is a simple melee weapon that is the traditional weapon of Chultan warriors. A yklwa consists of a 3-foot wooden shaft with a steel or stone blade up to 18 inches long. Although it has the thrown weapon property, the yklwa is not well balanced for throwing. Thrown. If a weapon has the thrown property, you can throw the weapon to make a ranged attack. If the weapon is a melee weapon, you use the same ability modifier for that attack roll and damage roll that you would use for a melee attack with the weapon. For example, if you throw a handaxe, you use your Strength, but if you throw a dagger, you can use either your Strength or your Dexterity, since the dagger has the finesse property.



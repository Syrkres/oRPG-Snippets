---
cssclass: oRPGPage
fileType: item
itemType: spellcasting_focus
name: yew_wand
source: phb
rarity: none
attunement: none_required
value: 10_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Yew Wand
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | spellcasting focus |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Yew Wand
**Type:** spellcasting focus

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 10 gp
**Weight:** 1 lb.

**Description:** A druid can use this object as a spellcasting focus.



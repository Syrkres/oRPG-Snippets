---
cssclass: oRPGPage
fileType: item
itemType: food_and_drink
name: ale_(gallon)
source: phb
rarity: none
attunement: none_required
value: 2_sp
weight: varies
properties:
---
> [!oRPG-Item]
> # Ale (Gallon)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | food and drink |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 sp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Ale (Gallon)
**Type:** food and drink

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 2 sp
**Weight:** Varies

**Description:**



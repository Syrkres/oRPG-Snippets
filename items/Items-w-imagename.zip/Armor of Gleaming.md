---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_gleaming
source: xge
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Gleaming
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Armor of Gleaming
**Type:** generic variant

**Rarity:** Common
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This armor never gets dirty. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Gleaming)Chain Mail (Chain Mail of Gleaming)Chain Shirt (Chain Shirt of Gleaming)Half Plate Armor (Half Plate Armor of Gleaming)Hide Armor (Hide Armor of Gleaming)Plate Armor (Plate Armor of Gleaming)Ring Mail (Ring Mail of Gleaming)Scale Mail (Scale Mail of Gleaming)Spiked Armor (Spiked Armor of Gleaming)Splint Armor (Splint Armor of Gleaming)



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: concertina
source: rmbre
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Concertina
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | RMBRE |

#  Concertina
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** RMBRE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** A concertina is a less charming kind of accordion.In addition to knocking out a killer polka, a creature playing the concertina can use an action to cause an area of mist or water up to 30 feet in diameter and 6 inches deep to freeze solid.Once used, this feature of the concertina can&#39;t be used again until the next dawn.Any creatures touching the floor must succeed on a DC 20 Dexterity saving throw or be restrained by the ice. As an action, a restrained creature can attempt to free itself or another creature within its reach from the ice, doing so with a successful DC 20 Strength (Athletics) check. A character freed from the ice is no longer restrained by it. The ice melts in an hour.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: battle_standard_of_infernal_power
source: bgdia
rarity: very_rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Battle Standard of Infernal Power
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | BGDIA |

#  Battle Standard of Infernal Power
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** BGDIA
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This hell-forged battle standard is made of infernal iron and fitted with a small, unopenable cage containing a quasit. The trapped quasit is incapacitated, and its cage has AC 19, 10 hit points, and immunity to all types of damage except force damage. If killed or somehow released, the quasit disappears in a cloud of smoke, and a new one appears in the cage, provided the cage is intact.While you hold the banner, your weapon attacks and those of all allied creatures within 300 feet of you count as magical for the purposes of overcoming damage immunities and resistances.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cloak_of_arachnida
source: dmg
rarity: very_rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Cloak of Arachnida
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | 14,000 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Cloak of Arachnida
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This fine garment is made of black silk interwoven with faint silvery threads. While wearing it, you gain the following benefits:You have resistance to poison damage.You have a climbing speed equal to your walking speed.You can move up, down, and across vertical surfaces and upside down along ceilings, while leaving your hands free.You can&#39;t be caught in webs of any sort and can move through webs as if they were difficult terrain.You can use an action to cast the web spell (save DC 13). The web created by the spell fills twice its normal area. Once used, this property of the cloak can&#39;t be used again until the next dawn.



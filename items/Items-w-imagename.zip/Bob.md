---
cssclass: oRPGPage
fileType: item
itemType: weapon_(battleaxe)_martial_weapon_melee_weapon
name: bob
source: toa
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: 4_lb.
properties: 1d8_slashing_-_versatile_(1d10)
---
> [!oRPG-Item]
> # Bob
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (battleaxe), martial weapon, melee weapon |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d8, slashing, - versatile (1d10) |
> | **Source** | ToA |

#  Bob
**Type:** weapon (battleaxe), martial weapon, melee weapon

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** ToA
**Properties:** 1d8, slashing, - versatile (1d10)
**Value:** Varies
**Weight:** 4 lb.

**Description:** This +1 battleaxe floats on water and other liquids, and grants its bearer advantage on Strength (Athletics) checks made to swim. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: candle_of_invocation
source: dmg
rarity: very_rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Candle of Invocation
> ![[Candle of Invocation.jpg|Candle of Invocation]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | 8,400 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Candle of Invocation
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This slender taper is dedicated to a deity and shares that deity&#39;s alignment. The candle&#39;s alignment can be detected with the detect evil and good spell. The DM chooses the god and associated alignment or determines the alignment randomly.d20Alignment1-2Chaotic evil3-4Chaotic neutral5-7Chaotic good8-9Neutral evil10-11Neutral12-13Neutral good14-15Lawful evil16-17Lawful neutral18-20Lawful goodThe candle&#39;s magic is activated when the candle is lit, which requires an action. After burning for 4 hours, the candle is destroyed. You can snuff it out early for use at a later time. Deduct the time it burned in increments of 1 minute from the candle&#39;s total burn time.While lit, the candle sheds dim light in a 30-foot radius. Any creature within that light whose alignment matches that of the candle makes attack rolls, saving throws, and ability checks with advantage. In addition, a cleric or druid in the light whose alignment matches the candle&#39;s can cast 1st-level spells he or she has prepared without expending spell slots, though the spell&#39;s effect is as if cast with a 1st-level slot.Alternatively, when you light the candle for the first time, you can cast the gate spell with it. Doing so destroys the candle.



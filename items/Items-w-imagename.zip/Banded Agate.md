---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: banded_agate
source: dmg
rarity: none
attunement: none_required
value: 10_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Banded Agate
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Banded Agate
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 10 gp
**Weight:** Varies

**Description:** A translucent striped brown, blue, white, or red gemstone.



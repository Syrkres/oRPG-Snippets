---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +1_weapon
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +1 Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +1 Weapon
**Type:** generic variant

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +1 bonus to attack and damage rolls made with this magic weapon. Base items. This item variant can be applied to the following base items:Antimatter Rifle (+1 Antimatter Rifle)Automatic Pistol (+1 Automatic Pistol)Automatic Rifle (+1 Automatic Rifle)Battleaxe (+1 Battleaxe)Blowgun (+1 Blowgun)Club (+1 Club)Dagger (+1 Dagger)Dart (+1 Dart)Double-Bladed Scimitar (+1 Double-Bladed Scimitar)Flail (+1 Flail)Glaive (+1 Glaive)Greataxe (+1 Greataxe)Greatclub (+1 Greatclub)Greatsword (+1 Greatsword)Halberd (+1 Halberd)Hand Crossbow (+1 Hand Crossbow)Handaxe (+1 Handaxe)Heavy Crossbow (+1 Heavy Crossbow)Hooked Shortspear (+1 Hooked Shortspear)Hunting Rifle (+1 Hunting Rifle)Javelin (+1 Javelin)Lance (+1 Lance)Laser Pistol (+1 Laser Pistol)Laser Rifle (+1 Laser Rifle)Light Crossbow (+1 Light Crossbow)Light Hammer (+1 Light Hammer)Light Repeating Crossbow (+1 Light Repeating Crossbow)Longbow (+1 Longbow)Longsword (+1 Longsword)Mace (+1 Mace)Maul (+1 Maul)Morningstar (+1 Morningstar)Musket (+1 Musket)Pike (+1 Pike)Pistol (+1 Pistol)Quarterstaff (+1 Quarterstaff)Rapier (+1 Rapier)Revolver (+1 Revolver)Scimitar (+1 Scimitar)Shortbow (+1 Shortbow)Shortsword (+1 Shortsword)Shotgun (+1 Shotgun)Sickle (+1 Sickle)Sling (+1 Sling)Spear (+1 Spear)Trident (+1 Trident)War Pick (+1 War Pick)Warhammer (+1 Warhammer)Whip (+1 Whip)Yklwa (+1 Yklwa)



---
cssclass: oRPGPage
fileType: item
itemType: medium_armor
name: dragon_scale_mail
source: dmg
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 45_lb.
properties: ac_14_+_dex_(max_2)
---
> [!oRPG-Item]
> # Dragon Scale Mail
> ![[Dragon Scale Mail.jpg|Dragon Scale Mail]]
>
> |  |   |
> |:--|---|
> |**Type** | medium armor |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 45 lb. |
>  |**Properties** | AC 14 + Dex (max 2) |
> | **Source** | DMG |

#  Dragon Scale Mail
**Type:** medium armor

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:** AC 14 + Dex (max 2)
**Value:** Varies
**Weight:** 45 lb.

**Description:** The wearer has disadvantage on Dexterity (Stealth) checks.Multiple variations of this item exist, as listed below:Black Dragon Scale MailBlue Dragon Scale MailBrass Dragon Scale MailBronze Dragon Scale MailCopper Dragon Scale MailGold Dragon Scale MailGreen Dragon Scale MailRed Dragon Scale MailSilver Dragon Scale MailWhite Dragon Scale Mail



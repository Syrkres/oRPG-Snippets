---
cssclass: oRPGPage
fileType: item
itemType: artisan&#39;s_tools
name: alchemists_supplies
source: phb
rarity: none
attunement: none_required
value: 50_gp
weight: 8_lb.
properties:
---
> [!oRPG-Item]
> # Alchemist&#39;s Supplies
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Artisan&#39;s Tools |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| 8 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Alchemist&#39;s Supplies
**Type:** Artisan&#39;s Tools

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 50 gp
**Weight:** 8 lb.

**Description:** These special tools include the items needed to pursue a craft or trade. Proficiency with a set of artisan&#39;s tools lets you add your proficiency bonus to any ability checks you make using the tools in your craft. Each type of artisan&#39;s tools requires a separate proficiency.Alchemist&#39;s supplies enable a character to produce useful concoctions, such as acid or alchemist&#39;s fire. Components. Alchemist&#39;s supplies include two glass beakers, a metal frame to hold a beaker in place over an open flame, a glass stirring rod, a small mortar and pestle, and a pouch of common alchemical ingredients, including salt, powdered iron, and purified water. Arcana. Proficiency with alchemist&#39;s supplies allows you to unlock more information on Arcana checks involving potions and similar materials. Investigation. When you inspect an area for clues, proficiency with alchemist&#39;s supplies grants additional insight into any chemicals or other substances that might have been used in the area. Alchemical Crafting. You can use this tool proficiency to create alchemical items. A character can spend money to collect raw materials, which weigh 1 pound for every 50 gp spent. The DM can allow a character to make a check using the indicated skill with advantage. As part of a long rest, you can use alchemist&#39;s supplies to make one dose of acid, alchemist&#39;s fire, antitoxin, oil, perfume, or soap. Subtract half the value of the created item from the total gp worth of raw materials you are carrying.Alchemist&#39;s SuppliesActivityDCCreate a puff of thick smoke10Identify a poison10Identify a substance15Start a fire15Neutralize acid20See the Tool Proficiencies entry for more information.



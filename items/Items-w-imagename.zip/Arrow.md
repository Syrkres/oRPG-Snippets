---
cssclass: oRPGPage
fileType: item
itemType: ammunition
name: arrow
source: phb
rarity: none
attunement: none_required
value: 5_cp
weight: 0.8_oz.
properties:
---
> [!oRPG-Item]
> # Arrow
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 cp |
>  | **Weight**| 0.8 oz. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Arrow
**Type:** ammunition

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 cp
**Weight:** 0.8 oz.

**Description:**



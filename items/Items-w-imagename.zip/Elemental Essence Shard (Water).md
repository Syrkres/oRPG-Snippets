---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: elemental_essence_shard_(water)
source: tce
rarity: rare
attunement: requires_attunement_by_a_sorcerer
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Elemental Essence Shard (Water)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement By A Sorcerer |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | TCE |

#  Elemental Essence Shard (Water)
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement By A Sorcerer
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** This crackling crystal contains the essence of an elemental plane. As an action, you can attach the shard to a Tiny object (such as a weapon or a piece of jewelry) or detach it. It falls off if your attunement to it ends. You can use the shard as a spellcasting focus while you hold or wear it.When you use a Metamagic option on a spell while you are holding or wearing the shard, you can use the following property: Property. You create a wave of water that bursts out from you in a 10-foot radius. Each creature of your choice that you can see in that area takes 2d6 cold damage and must succeed on a Strength saving throw against your spell save DC or be pushed 10 feet away from you and fall prone.



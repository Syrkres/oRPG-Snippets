---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cleansing_stone
source: erlw
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Cleansing Stone
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ERLW |

#  Cleansing Stone
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** ERLW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** A cleansing stone is a sphere 1 foot in diameter, engraved with mystic sigils. When touching the stone, you can use an action to activate it and remove dirt and grime from your garments and your person.Such stones are often embedded in pedestals in public squares in Aundair or in high-end Ghallanda inns.



---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_thunder_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Thunder Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Thunder Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to thunder damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Thunder Resistance)Chain Mail (Chain Mail of Thunder Resistance)Chain Shirt (Chain Shirt of Thunder Resistance)Half Plate Armor (Half Plate Armor of Thunder Resistance)Hide Armor (Hide Armor of Thunder Resistance)Leather Armor (Leather Armor of Thunder Resistance)Padded Armor (Padded Armor of Thunder Resistance)Plate Armor (Plate Armor of Thunder Resistance)Ring Mail (Ring Mail of Thunder Resistance)Scale Mail (Scale Mail of Thunder Resistance)Spiked Armor (Spiked Armor of Thunder Resistance)Splint Armor (Splint Armor of Thunder Resistance)Studded Leather Armor (Studded Leather Armor of Thunder Resistance)



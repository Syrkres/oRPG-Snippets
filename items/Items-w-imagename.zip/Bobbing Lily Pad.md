---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: bobbing_lily_pad
source: wbtw
rarity: very_rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Bobbing Lily Pad
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | WBtW |

#  Bobbing Lily Pad
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** WBtW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This magic vehicle is a 10-foot-diameter leaf that floats on water. It has tendrils that propel it across land and across the water&#39;s surface (but not underwater), as well as through the air. It has a walking, flying, and swimming speed of 20 feet, and it can hover. It moves according to your spoken directions while you are riding it.The lily pad can transport up to 300 pounds without hindrance. It can carry up to twice this weight, but it moves at half speed if it carries more than its normal capacity.



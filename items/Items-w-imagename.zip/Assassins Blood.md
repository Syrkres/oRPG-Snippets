---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear_poison_(ingested)
name: assassins_blood
source: dmg
rarity: none
attunement: none_required
value: 150_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Assassin&#39;s Blood
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear, poison (ingested) |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 150 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Assassin&#39;s Blood
**Type:** adventuring gear, poison (ingested)

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 150 gp
**Weight:** Varies

**Description:** A creature subjected to this poison must make a DC 10 Constitution saving throw. On a failed save, it takes 6 (1d12) poison damage and is poisoned for 24 hours. On a successful save, the creature takes half damage and isn&#39;t poisoned.



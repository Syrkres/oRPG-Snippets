---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: circlet_of_blasting
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Circlet of Blasting
> ![[Circlet of Blasting.jpg|Circlet of Blasting]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Circlet of Blasting
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While wearing this circlet, you can use an action to cast the scorching ray spell with it. When you make the spell&#39;s attacks, you do so with an attack bonus of +5. The circlet can&#39;t be used this way again until the next dawn.



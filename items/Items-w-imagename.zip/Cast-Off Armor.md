---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: cast-off_armor
source: xge
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Cast-Off Armor
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Cast-Off Armor
**Type:** generic variant

**Rarity:** Common
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You can doff this armor as an action. Base items. This item variant can be applied to the following base items:Breastplate (Cast-Off Breastplate)Chain Mail (Cast-Off Chain Mail)Chain Shirt (Cast-Off Chain Shirt)Half Plate Armor (Cast-Off Half Plate Armor)Hide Armor (Cast-Off Hide Armor)Leather Armor (Cast-Off Leather Armor)Padded Armor (Cast-Off Padded Armor)Plate Armor (Cast-Off Plate Armor)Ring Mail (Cast-Off Ring Mail)Scale Mail (Cast-Off Scale Mail)Spiked Armor (Cast-Off Spiked Armor)Splint Armor (Cast-Off Splint Armor)Studded Leather Armor (Cast-Off Studded Leather Armor)



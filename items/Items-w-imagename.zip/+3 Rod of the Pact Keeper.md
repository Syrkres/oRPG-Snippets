---
cssclass: oRPGPage
fileType: item
itemType: rod
name: +3_rod_of_the_pact_keeper
source: dmg
rarity: very_rare
attunement: requires_attunement_by_a_warlock
value: varies
weight: 2_lb.
properties:
---
> [!oRPG-Item]
> # +3 Rod of the Pact Keeper
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | rod |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement By A Warlock |
> | **Value** | Varies |
>  | **Weight**| 2 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  +3 Rod of the Pact Keeper
**Type:** rod

**Rarity:** Very Rare
**Attunement:** Requires Attunement By A Warlock
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 2 lb.

**Description:** While holding this rod, you gain a +3 bonus to spell attack rolls and to the saving throw DCs of your warlock spells.In addition, you can regain one warlock spell slot as an action while holding the rod. You can&#39;t use this property again until you finish a long rest.



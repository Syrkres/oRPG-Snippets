---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: chalk_(1_piece)
source: phb
rarity: none
attunement: none_required
value: 1_cp
weight: varies
properties:
---
> [!oRPG-Item]
> # Chalk (1 piece)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 cp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | PHB |

#  Chalk (1 piece)
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 cp
**Weight:** Varies

**Description:**



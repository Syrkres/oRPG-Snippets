---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: crystal_ball
source: dmg
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Crystal Ball
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | undefined |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Crystal Ball
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** This crystal ball is about 6 inches in diameter. While touching it, you can cast the scrying spell (save DC 17) with it.



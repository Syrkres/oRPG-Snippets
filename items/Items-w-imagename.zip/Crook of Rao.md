---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: crook_of_rao
source: tce
rarity: artifact
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Crook of Rao
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Artifact |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | TCE |

#  Crook of Rao
**Type:** wondrous item

**Rarity:** Artifact
**Attunement:** Requires Attunement
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Ages ago, the serene god Rao created a tool to shield his fledgling faithful against the evils of the Lower Planes. Yet, as eons passed, mortals developed their own methods of dealing with existential threats, and the crook was largely forgotten. In recent ages, though, the Crook of Rao was rediscovered and leveraged against the rising power of the Witch Queen Iggwilv (one of the names of the wizard Tasha). Although she was defeated, Iggwilv managed to damage the crook during the battle, infecting it with an insidious curse-and the potential for future victory. In the aftermath, the crook was again lost. Occasionally it reappears, but the famed artifact is not what it was. Whether or not the artifact&#39;s bearers realize its full threat, few risk using the Crook of Rao -potentially for the final time. Random Properties. The artifact has the following random properties, which you can determine by rolling on the tables in the &quot;Artifacts&quot; section of the Dungeon Master&#39;s Guide:2 minor beneficial properties1 major beneficial property1 minor detrimental property Spells. The crook has 6 charges. While holding it, you can use an action to expend 1 or more of its charges to cast one of the following spells (save DC 18) from it: aura of life (2 charges), aura of purity (2 charges), banishment (1 charge), beacon of hope (1 charge), mass cure wounds (3 charges). The crook regains 1d6 expended charges daily at dawn. Absolute Banishment. While you are attuned to the crook and holding it, you can spend 10 minutes to banish all but the mightiest fiends within 1 mile of you. Any fiend with a challenge rating of 19 or higher is unaffected. Each banished fiend is sent back to its home plane and can&#39;t return to the plane the Crook of Rao banished it from for 100 years. Failing Matrix. Whenever the Crook of Rao &#39;s Absolute Banishment property is used, or when its last charge is expended, roll on the Extraplanar Reversal table. Any creatures conjured as a result of this effect appear in random unoccupied spaces within 60 feet of you and are not under your control. Iggwilv&#39;s Curse. When the Crook was last used against Iggwilv, the Witch Queen lashed out at the artifact, infecting its magical matrix. Over the years, this curse has spread within the crook, threatening to violently pervert its ancient magic. If this occurs, the Crook of Rao, as it is currently known, is destroyed, its magical matrix inverting and exploding into a 50-foot-diameter portal. This portal functions as a permanent gate spell cast by Iggwilv. The gate then, once per round on initiative count 20, audibly speaks a fiend&#39;s name in Iggwilv&#39;s voice, doing so until the gate calls on every fiend ever banished by the Crook of Rao. If the fiend still exists, it is drawn through the gate. This process takes eighteen years to complete, at the end of which the gate becomes a permanent portal to Pazunia, the first layer of the Abyss.Extraplanar Reversald100Effect1-25A portal to a random plane opens. The portal closes after 5 minutes.26-452d4 imps and 2d4 quasits appear.46-601d8 succubi&#x2F;incubi appear.61-701d10 barbed devils and 1d10 vrocks appear.71-801 arcanaloth, 1 night hag, and 1 rakshasa appear.81-851 ice devil and 1 marilith appear.86-901 balor and 1 pit fiend appear. At the DM&#39;s discretion, a portal opens into the presence of an archdevil or demon lord instead, then closes after 5 minutes.91-00Iggwilv&#39;s Curse (see the Iggwilv&#39;s Curse property). Destroying or Repairing the Crook. The Crook of Rao can either be destroyed or repaired by journeying to Mount Celestia and obtaining a tear from the eternally serene god Rao. One way to make the emotionless god cry would be to reunite Rao with the spirit of his first worshiper who sought revelations beyond the multiverse long ago. The Crook dissolves if immersed in the god&#39;s tear for a year and a day. If washed in the tear daily for 30 days, the Crook loses its Failing Matrix property.



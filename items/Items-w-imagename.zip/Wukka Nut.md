---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: wukka_nut
source: toa
rarity: unknown
attunement: none_required
value: 1_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Wukka Nut
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | Unknown |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ToA |

#  Wukka Nut
**Type:** adventuring gear

**Rarity:** Unknown
**Attunement:** None Required
**Source:** ToA
**Properties:**
**Value:** 1 gp
**Weight:** Varies

**Description:** These fist-sized nuts grow on wukka trees, which are popular haunts for jaculi, su-monsters, and zorbos. A wukka nut rattles when shaken, causing its shell to shed bright light in a 10-foot radius and dim light for an additional 10 feet. This magical light fades after 1 minute, but shaking the nut again causes the light to reappear. If the shell of the nut is cracked open, it loses its magic.



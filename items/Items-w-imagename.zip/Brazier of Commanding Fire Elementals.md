---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: brazier_of_commanding_fire_elementals
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: 5_lb.
properties:
---
> [!oRPG-Item]
> # Brazier of Commanding Fire Elementals
> ![[Brazier of Commanding Fire Elementals.jpg|Brazier of Commanding Fire Elementals]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | 100,000 gp |
>  | **Weight**| 5 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Brazier of Commanding Fire Elementals
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 5 lb.

**Description:** While a fire burns in this brass brazier, you can use an action to speak the brazier&#39;s command word and summon a fire elemental, as if you had cast the conjure elemental spell. The brazier can&#39;t be used this way again until the next dawn.The brazier weighs 5 pounds.



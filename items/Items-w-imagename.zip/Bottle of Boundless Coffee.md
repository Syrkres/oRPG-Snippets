---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: bottle_of_boundless_coffee
source: scc
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Bottle of Boundless Coffee
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | SCC |

#  Bottle of Boundless Coffee
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** SCC
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This metal bottle carries delicious, warm coffee. The bottle comes with a stopper, which is attached to the bottle by a little chain. Even when open, the bottle won&#39;t accept any liquid other than the coffee it produces. The coffee inside is always comfortably warm, and none of the heat can be felt through the bottle.Each time you drink the coffee, roll a d20. On a 1, the bottle refuses to dispense coffee for the next hour. If you pour coffee from the bottle, rather than drinking from it, the coffee vanishes the moment it leaves the bottle.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: crystal_ball_of_true_seeing
source: dmg
rarity: legendary
attunement: requires_attunement
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Crystal Ball of True Seeing
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | DMG |

#  Crystal Ball of True Seeing
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** This crystal ball is about 6 inches in diameter. While touching it, you can cast the scrying spell (save DC 17) with it.While scrying with the crystal ball, you have truesight with a radius of 120 feet centered on the spell&#39;s sensor.



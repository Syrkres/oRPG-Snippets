---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cloak_of_many_fashions
source: xge
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Cloak of Many Fashions
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Cloak of Many Fashions
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While wearing this cloak, you can use a bonus action to change the style, color, and apparent quality of the garment. The cloak&#39;s weight doesn&#39;t change. Regardless of its appearance, the cloak can&#39;t be anything but a cloak. Although it can duplicate the appearance of other magic cloaks, it doesn&#39;t gain their magical properties.



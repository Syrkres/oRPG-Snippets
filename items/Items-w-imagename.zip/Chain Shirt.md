---
cssclass: oRPGPage
fileType: item
itemType: medium_armor
name: chain_shirt
source: phb
rarity: none
attunement: none_required
value: 50_gp
weight: 20_lb.
properties: ac_13_+_dex_(max_2)
---
> [!oRPG-Item]
> # Chain Shirt
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | medium armor |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| 20 lb. |
>  |**Properties** | AC 13 + Dex (max 2) |
> | **Source** | PHB |

#  Chain Shirt
**Type:** medium armor

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** AC 13 + Dex (max 2)
**Value:** 50 gp
**Weight:** 20 lb.

**Description:** Made of interlocking metal rings, a chain shirt is worn between layers of clothing or leather. This armor offers modest protection to the wearer&#39;s upper body and allows the sound of the rings rubbing against one another to be muffled by outer layers.



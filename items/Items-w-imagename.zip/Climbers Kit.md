---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: climbers_kit
source: phb
rarity: none
attunement: none_required
value: 25_gp
weight: 12_lb.
properties:
---
> [!oRPG-Item]
> # Climber&#39;s Kit
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 25 gp |
>  | **Weight**| 12 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Climber&#39;s Kit
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 25 gp
**Weight:** 12 lb.

**Description:** A climber&#39;s kit includes special pitons, boot tips, gloves, and a harness. You can use the climber&#39;s kit as an action to anchor yourself; when you do, you can&#39;t fall more than 25 feet from the point where you anchored yourself, and you can&#39;t climb more than 25 feet away from that point without undoing the anchor.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: +1_bloodwell_vial
source: tce
rarity: uncommon
attunement: requires_attunement_by_a_sorcerer
value: varies
weight: 0.16_oz.
properties:
---
> [!oRPG-Item]
> # +1 Bloodwell Vial
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement By A Sorcerer |
> | **Value** | Varies |
>  | **Weight**| 0.16 oz. |
>  |**Properties** |  |
> | **Source** | TCE |

#  +1 Bloodwell Vial
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement By A Sorcerer
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 0.16 oz.

**Description:** To attune to this vial, you must place a few drops of your blood into it. The vial can&#39;t be opened while your attunement to it lasts. If your attunement to the vial ends, the contained blood turns to ash. You can use the vial as a spellcasting focus for your spells while wearing or holding it, and you gain a +1 bonus to spell attack rolls and to the saving throw DCs of your sorcerer spells.In addition, when you roll any Hit Dice to recover hit points while you are carrying the vial, you can regain 5 sorcery points. This property of the vial can&#39;t be used again until the next dawn.



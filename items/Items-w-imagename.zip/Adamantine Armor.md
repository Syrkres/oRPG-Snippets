---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: adamantine_armor
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Adamantine Armor
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Adamantine Armor
**Type:** generic variant

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This suit of armor is reinforced with adamantine, one of the hardest substances in existence. While you&#39;re wearing it, any critical hit against you becomes a normal hit. Base items. This item variant can be applied to the following base items:Breastplate (Adamantine Breastplate)Chain Mail (Adamantine Chain Mail)Chain Shirt (Adamantine Chain Shirt)Half Plate Armor (Adamantine Half Plate Armor)Plate Armor (Adamantine Plate Armor)Ring Mail (Adamantine Ring Mail)Scale Mail (Adamantine Scale Mail)Spiked Armor (Adamantine Spiked Armor)Splint Armor (Adamantine Splint Armor)



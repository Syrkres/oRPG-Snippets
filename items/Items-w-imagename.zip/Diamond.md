---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: diamond
source: dmg
rarity: none
attunement: none_required
value: 5000_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Diamond
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5,000 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Diamond
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 5,000 gp
**Weight:** Varies

**Description:** A transparent blue-white, canary, pink, brown, or blue gemstone.



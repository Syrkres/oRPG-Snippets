---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: ascendant_dragon_vessel
source: ftd
rarity: legendary
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Ascendant Dragon Vessel
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Legendary |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  Ascendant Dragon Vessel
**Type:** wondrous item

**Rarity:** Legendary
**Attunement:** Requires Attunement
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This vessel can be a potion bottle, drinking horn, or other container meant to hold a liquid.As a bonus action, if the vessel is empty, you can speak the command word to fill the vessel with one of the following (your choice): ale, olive oil, mead, wine, whiskey, a potion of healing, a potion of greater healing, a potion of superior healing, a potion of supreme healing, a potion of climbing, a potion of fire breath, a potion of flying, or a potion of dragon&#39;s majesty. Once this property is used, it can&#39;t be used until the next dawn. A potion you create in this way loses its magical properties if it isn&#39;t imbibed within 24 hours.



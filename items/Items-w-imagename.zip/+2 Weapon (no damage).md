---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +2_weapon_(no_damage)
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +2 Weapon (no damage)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +2 Weapon (no damage)
**Type:** generic variant

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +2 bonus to attack rolls made with this weapon. Base items. This item variant can be applied to the following base items:Net (+2 Net)



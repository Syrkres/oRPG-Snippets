---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: basket
source: phb
rarity: none
attunement: none_required
value: 4_sp
weight: 2_lb.
properties:
---
> [!oRPG-Item]
> # Basket
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 4 sp |
>  | **Weight**| 2 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Basket
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 4 sp
**Weight:** 2 lb.

**Description:** A basket holds 2 cubic feet or 40 pounds of gear.



---
cssclass: oRPGPage
fileType: item
itemType: tack_and_harness
name: bit_and_bridle
source: phb
rarity: none
attunement: none_required
value: 2_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Bit and bridle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | tack and harness |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 2 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Bit and bridle
**Type:** tack and harness

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 2 gp
**Weight:** 1 lb.

**Description:**



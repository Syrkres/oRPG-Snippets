---
cssclass: oRPGPage
fileType: item
itemType: ammunition_generic_variant
name: adamantine_ammunition
source: xge
rarity: unknown
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Adamantine Ammunition
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition, generic variant |
> |**Rarity** | Unknown |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | XGE |

#  Adamantine Ammunition
**Type:** ammunition, generic variant

**Rarity:** Unknown
**Attunement:** None Required
**Source:** XGE
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Ammunition made of or coated with adamantine is unusually effective when used to break objects. Whenever a piece of adamantine ammunition hits an object, the hit is a critical hit.The adamantine version of ten pieces of ammunition costs 500 gp more than the normal version, whether the ammunition is made of the metal or coated with it. Base items. This item variant can be applied to the following base items:Arrow (Adamantine Arrow)Blowgun Needle (Adamantine Blowgun Needle)Crossbow Bolt (Adamantine Crossbow Bolt)Modern Bullet (Adamantine Modern Bullet)Renaissance Bullet (Adamantine Renaissance Bullet)Sling Bullet (Adamantine Sling Bullet)



---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: costume_clothes
source: phb
rarity: none
attunement: none_required
value: 5_gp
weight: 4_lb.
properties:
---
> [!oRPG-Item]
> # Costume Clothes
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 gp |
>  | **Weight**| 4 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Costume Clothes
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 gp
**Weight:** 4 lb.

**Description:**



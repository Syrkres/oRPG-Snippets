---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: bedroll
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: 7_lb.
properties:
---
> [!oRPG-Item]
> # Bedroll
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 7 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Bedroll
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** 7 lb.

**Description:**



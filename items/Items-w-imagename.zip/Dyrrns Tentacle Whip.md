---
cssclass: oRPGPage
fileType: item
itemType: weapon_(whip)_martial_weapon_melee_weapon
name: dyrrns_tentacle_whip
source: erlw
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 3_lb.
properties: 1d4_slashing_-_finesse_reach
---
> [!oRPG-Item]
> # Dyrrn&#39;s Tentacle Whip
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (whip), martial weapon, melee weapon |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** | 1d4, slashing, - finesse, reach |
> | **Source** | ERLW |

#  Dyrrn&#39;s Tentacle Whip
**Type:** weapon (whip), martial weapon, melee weapon

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** ERLW
**Properties:** 1d4, slashing, - finesse, reach
**Value:** Varies
**Weight:** 3 lb.

**Description:** This long, whip-like strand of tough muscle bears a sharp stinger at one end. To attune to this symbiotic weapon, you wrap the whip around your wrist for the entire attunement period, during which time the whip painfully embeds its tendrils into your arm.You gain a +2 bonus to attack and damage rolls made with this magic whip, but attack rolls made against aberrations with this weapon have disadvantage. A creature hit by this weapon takes an extra 1d6 psychic damage. When you roll a 20 on the d20 for an attack roll with this weapon, the target is stunned until the end of its next turn.As a bonus action, you can sheathe the whip by causing it to retract into your arm, or draw the whip out of your arm again. Symbiotic Nature. The whip can&#39;t be removed from you while you&#39;re attuned to it, and you can&#39;t voluntarily end your attunement to it. If you&#39;re targeted by a spell that ends a curse, your attunement to the whip ends, and it detaches from you. Finesse. When making an attack with a finesse weapon, you use your choice of your Strength or Dexterity modifier for the attack and damage rolls. You must use the same modifier for both rolls. Reach. This weapon adds 5 feet to your reach when you attack with it. This property also determines your reach for opportunity attacks with a reach weapon.



---
cssclass: oRPGPage
fileType: item
itemType: weapon_(dagger)_simple_weapon_melee_weapon
name: dagger_of_venom
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: 1_lb.
properties: 1d4_piercing_-_finesse_light_thrown_(20&#x2F;60_ft.)
---
> [!oRPG-Item]
> # Dagger of Venom
> ![[Dagger of Venom.jpg|Dagger of Venom]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (dagger), simple weapon, melee weapon |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | 8,302 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** | 1d4, piercing, - finesse, light, thrown (20&#x2F;60 ft.) |
> | **Source** | DMG |

#  Dagger of Venom
**Type:** weapon (dagger), simple weapon, melee weapon

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:** 1d4, piercing, - finesse, light, thrown (20&#x2F;60 ft.)
**Value:** Varies
**Weight:** 1 lb.

**Description:** You gain a +1 bonus to attack and damage rolls made with this magic weapon.You can use an action to cause thick, black poison to coat the blade. The poison remains for 1 minute or until an attack using this weapon hits a creature. That creature must succeed on a DC 15 Constitution saving throw or take 2d10 poison damage and become poisoned for 1 minute. The dagger can&#39;t be used this way again until the next dawn. Finesse. When making an attack with a finesse weapon, you use your choice of your Strength or Dexterity modifier for the attack and damage rolls. You must use the same modifier for both rolls. Light. A light weapon is small and easy to handle, making it ideal for use when fighting with two weapons. Thrown. If a weapon has the thrown property, you can throw the weapon to make a ranged attack. If the weapon is a melee weapon, you use the same ability modifier for that attack roll and damage roll that you would use for a melee attack with the weapon. For example, if you throw a handaxe, you use your Strength, but if you throw a dagger, you can use either your Strength or your Dexterity, since the dagger has the finesse property.



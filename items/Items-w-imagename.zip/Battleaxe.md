---
cssclass: oRPGPage
fileType: item
itemType: weapon_martial_weapon_melee_weapon
name: battleaxe
source: phb
rarity: none
attunement: none_required
value: 10_gp
weight: 4_lb.
properties: 1d8_slashing_-_versatile_(1d10)
---
> [!oRPG-Item]
> # Battleaxe
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon, martial weapon, melee weapon |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d8, slashing, - versatile (1d10) |
> | **Source** | PHB |

#  Battleaxe
**Type:** weapon, martial weapon, melee weapon

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** 1d8, slashing, - versatile (1d10)
**Value:** 10 gp
**Weight:** 4 lb.

**Description:**  Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



---
cssclass: oRPGPage
fileType: item
itemType: ammunition
name: crossbow_bolt
source: phb
rarity: none
attunement: none_required
value: 5_cp
weight: 1.2_oz.
properties:
---
> [!oRPG-Item]
> # Crossbow Bolt
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | ammunition |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 5 cp |
>  | **Weight**| 1.2 oz. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Crossbow Bolt
**Type:** ammunition

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 5 cp
**Weight:** 1.2 oz.

**Description:**



---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +1_weapon_(no_damage)
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +1 Weapon (no damage)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +1 Weapon (no damage)
**Type:** generic variant

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have a +1 bonus to attack rolls made with this weapon. Base items. This item variant can be applied to the following base items:Net (+1 Net)



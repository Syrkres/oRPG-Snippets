---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: crystalline_chronicle
source: tce
rarity: very_rare
attunement: requires_attunement_by_a_wizard
value: varies
weight: 3_lb.
properties:
---
> [!oRPG-Item]
> # Crystalline Chronicle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement By A Wizard |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** |  |
> | **Source** | TCE |

#  Crystalline Chronicle
**Type:** wondrous item

**Rarity:** Very Rare
**Attunement:** Requires Attunement By A Wizard
**Source:** TCE
**Properties:**
**Value:** Varies
**Weight:** 3 lb.

**Description:** An etched crystal sphere the size of a grapefruit hums faintly and pulses with irregular flares of inner light. While you are touching the crystal, you can retrieve and store information and spells within the crystal at the same rate as reading and writing. When found, the crystal contains the following spells: detect thoughts, intellect fortress, Rary&#39;s telepathic bond, sending, telekinesis, Tasha&#39;s mind whip, and Tenser&#39;s floating disk. It functions as a spellbook for you, with its spells and other writing psychically encoded within it.While you are holding the crystal, you can use it as a spellcasting focus for your wizard spells, and you know the mage hand, mind sliver (appears in this book), and message cantrips if you don&#39;t already know them.The crystal has 3 charges, and it regains 1d3 expended charges daily at dawn. You can use the charges in the following ways while holding it:If you spend 1 minute studying the information within the crystal, you can expend 1 charge to replace one of your prepared wizard spells with a different spell in the book.When you cast a wizard spell, you can expend 1 charge to cast the spell without verbal, somatic, or material components of up to 100 gp value.



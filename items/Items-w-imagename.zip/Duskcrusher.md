---
cssclass: oRPGPage
fileType: item
itemType: weapon_(warhammer)_martial_weapon_melee_weapon
name: duskcrusher
source: egw
rarity: very_rare
attunement: requires_attunement
value: varies
weight: 2_lb.
properties: 1d8_radiant_-_versatile_(1d10)
---
> [!oRPG-Item]
> # Duskcrusher
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (warhammer), martial weapon, melee weapon |
> |**Rarity** | Very Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 2 lb. |
>  |**Properties** | 1d8, radiant, - versatile (1d10) |
> | **Source** | EGW |

#  Duskcrusher
**Type:** weapon (warhammer), martial weapon, melee weapon

**Rarity:** Very Rare
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:** 1d8, radiant, - versatile (1d10)
**Value:** Varies
**Weight:** 2 lb.

**Description:** This item takes the form of a leather-wrapped metal rod emblazoned with the symbol of Pelor, the Dawn Father. While grasping the rod, you can use a bonus action to cause a warhammer head of crackling radiance to spring into existence. The warhammer&#39;s radiant head emits bright light in a 15-foot radius and dim light for an additional 15 feet. The light is sunlight. You can use an action to make the radiant head disappear.While the radiant head is active, you gain a +2 bonus to attack and damage rolls made with this magic weapon, and attacks with the weapon deal radiant damage instead of bludgeoning damage. An undead creature hit by the weapon takes an extra 1d8 radiant damage.While you are holding Duskcrusher and its radiant head is active, you can use an action to cast the sunbeam spell (save DC 15) from the weapon, and this action can&#39;t be used again until the next dawn. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cuddly_strixhaven_mascot
source: scc
rarity: common
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Cuddly Strixhaven Mascot
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Common |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | SCC |

#  Cuddly Strixhaven Mascot
**Type:** wondrous item

**Rarity:** Common
**Attunement:** None Required
**Source:** SCC
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** Representing one of the mascots of Strixhaven, this soft, Tiny, magic toy is perfect for cuddling. If you press it to your arm, shoulder, or leg as an action, the toy stays attached there for 1 hour or until you use an action to remove it.The toy can also be used to fight off fear. When you make a saving throw to avoid or end the frightened condition on yourself, you can give yourself advantage on the roll if the toy is on your person. You must decide to do so before rolling the d20. If the save succeeds, you can&#39;t use the toy in this way until you finish a long rest.



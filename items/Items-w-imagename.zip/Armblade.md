---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armblade
source: erlw
rarity: common
attunement: requires_attunement_by_a_warforged
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armblade
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Common |
> | **Attunement** | Requires Attunement By A Warforged |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ERLW |

#  Armblade
**Type:** generic variant

**Rarity:** Common
**Attunement:** Requires Attunement By A Warforged
**Source:** ERLW
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** An armblade is a magic weapon that attaches to your arm, becoming inseparable from you as long as you&#39;re attuned to it. To attune to this item, you must hold it against your forearm for the entire attunement period.As a bonus action, you can retract the armblade into your forearm or extend it from there. While it is extended, you can use the weapon as if you were holding it, and you can&#39;t use that hand for other purposes. Base items. This item variant can be applied to the following base items:Battleaxe (Battleaxe Armblade)Club (Club Armblade)Dagger (Dagger Armblade)Flail (Flail Armblade)Handaxe (Handaxe Armblade)Hooked Shortspear (Hooked Shortspear Armblade)Javelin (Javelin Armblade)Lance (Lance Armblade)Light Hammer (Light Hammer Armblade)Longsword (Longsword Armblade)Mace (Mace Armblade)Morningstar (Morningstar Armblade)Quarterstaff (Quarterstaff Armblade)Rapier (Rapier Armblade)Scimitar (Scimitar Armblade)Shortsword (Shortsword Armblade)Sickle (Sickle Armblade)Spear (Spear Armblade)Trident (Trident Armblade)War Pick (War Pick Armblade)Warhammer (Warhammer Armblade)Whip (Whip Armblade)Yklwa (Yklwa Armblade)



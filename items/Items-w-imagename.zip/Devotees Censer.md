---
cssclass: oRPGPage
fileType: item
itemType: weapon_(flail)_martial_weapon_melee_weapon
name: devotees_censer
source: tce
rarity: rare
attunement: requires_attunement_by_a_cleric_or_paladin
value: varies
weight: 2_lb.
properties: 1d8_bludgeoning
---
> [!oRPG-Item]
> # Devotee&#39;s Censer
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (flail), martial weapon, melee weapon |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement By A Cleric Or Paladin |
> | **Value** | Varies |
>  | **Weight**| 2 lb. |
>  |**Properties** | 1d8, bludgeoning |
> | **Source** | TCE |

#  Devotee&#39;s Censer
**Type:** weapon (flail), martial weapon, melee weapon

**Rarity:** Rare
**Attunement:** Requires Attunement By A Cleric Or Paladin
**Source:** TCE
**Properties:** 1d8, bludgeoning
**Value:** Varies
**Weight:** 2 lb.

**Description:** The rounded head of this flail is perforated with tiny holes, arranged in symbols and patterns. The flail counts as a holy symbol for you. When you hit with an attack using this magic flail, the target takes an extra 1d8 radiant damage.As a bonus action, you can speak the command word to cause the flail to emanate a thin cloud of incense out to 10 feet for 1 minute. At the start of each of your turns, you and any other creatures in the incense each regain 1d4 hit points. This property can&#39;t be used again until the next dawn.



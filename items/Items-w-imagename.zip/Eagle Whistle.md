---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: eagle_whistle
source: tftyp
rarity: rare
attunement: none_required
value: varies
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Eagle Whistle
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | TftYP |

#  Eagle Whistle
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** None Required
**Source:** TftYP
**Properties:**
**Value:** Varies
**Weight:** 1 lb.

**Description:** While you blow an eagle whistle continuously, you can fly twice as fast as your walking speed. You can blow the whistle continuously for a number of rounds equal to 5 + five times your Constitution modifier (minimum of 1 round) or until you talk, hold your breath, or start suffocating. A use of the whistle also ends if you land. If you are aloft when you stop blowing the whistle, you fall. The whistle has three uses. It regains expended uses daily at dawn.



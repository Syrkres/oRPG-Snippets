---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: armor_of_psychic_resistance
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Armor of Psychic Resistance
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Armor of Psychic Resistance
**Type:** generic variant

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** You have resistance to psychic damage while you wear this armor. Base items. This item variant can be applied to the following base items:Breastplate (Breastplate of Psychic Resistance)Chain Mail (Chain Mail of Psychic Resistance)Chain Shirt (Chain Shirt of Psychic Resistance)Half Plate Armor (Half Plate Armor of Psychic Resistance)Hide Armor (Hide Armor of Psychic Resistance)Leather Armor (Leather Armor of Psychic Resistance)Padded Armor (Padded Armor of Psychic Resistance)Plate Armor (Plate Armor of Psychic Resistance)Ring Mail (Ring Mail of Psychic Resistance)Scale Mail (Scale Mail of Psychic Resistance)Spiked Armor (Spiked Armor of Psychic Resistance)Splint Armor (Splint Armor of Psychic Resistance)Studded Leather Armor (Studded Leather Armor of Psychic Resistance)



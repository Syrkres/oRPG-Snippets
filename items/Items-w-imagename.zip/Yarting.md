---
cssclass: oRPGPage
fileType: item
itemType: instrument
name: yarting
source: scag
rarity: none
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Yarting
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Instrument |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | SCAG |

#  Yarting
**Type:** Instrument

**Rarity:** None
**Attunement:** None Required
**Source:** SCAG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** A southern instrument from Amn and Calimshan that is a Faerûnian analog to the guitar. Numerous variations have spread across the continent.If you have proficiency with a given musical instrument, you can add your proficiency bonus to any ability checks you make to play music with the instrument.A bard can use a musical instrument as a spellcasting focus, substituting it for any material component that does not list a cost.Each type of musical instrument requires a separate proficiency.See the Tool Proficiencies entry for more information.Proficiency with a musical instrument indicates you are familiar with the techniques used to play it. You also have knowledge of some songs commonly performed with that instrument. History. Your expertise aids you in recalling lore related to your instrument. Performance. Your ability to put on a good show is improved when you incorporate an instrument into your act. Compose a Tune. As part of a long rest, you can compose a new tune and lyrics for your instrument. You might use this ability to impress a noble or spread scandalous rumors with a catchy tune.Musical InstrumentActivityDCIdentify a tune10Improvise a tune20



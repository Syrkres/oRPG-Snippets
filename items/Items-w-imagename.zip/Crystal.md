---
cssclass: oRPGPage
fileType: item
itemType: spellcasting_focus
name: crystal
source: phb
rarity: none
attunement: none_required
value: 10_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Crystal
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | spellcasting focus |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 10 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Crystal
**Type:** spellcasting focus

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 10 gp
**Weight:** 1 lb.

**Description:** An arcane focus is a special item designed to channel the power of arcane spells. A sorcerer, warlock, or wizard can use such an item as a spellcasting focus.



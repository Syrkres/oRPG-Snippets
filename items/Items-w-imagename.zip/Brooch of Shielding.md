---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: brooch_of_shielding
source: dmg
rarity: uncommon
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Brooch of Shielding
> ![[Brooch of Shielding.jpg|Brooch of Shielding]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | 1,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Brooch of Shielding
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While wearing this brooch, you have resistance to force damage, and you have immunity to damage from the magic missile spell.



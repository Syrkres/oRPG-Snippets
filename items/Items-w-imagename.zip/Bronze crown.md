---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: bronze_crown
source: dmg
rarity: none
attunement: none_required
value: 250_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Bronze crown
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 250 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Bronze crown
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 250 gp
**Weight:** Varies

**Description:**



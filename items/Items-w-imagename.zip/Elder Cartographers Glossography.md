---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: elder_cartographers_glossography
source: ai
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Elder Cartographer&#39;s Glossography
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | AI |

#  Elder Cartographer&#39;s Glossography
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** AI
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** When you attain rank 4, you gain a small tome that is an uncommon magic item. The elder cartographer&#39;s glossography grants advantage on Intelligence or Wisdom checks related to geographical features or locations.



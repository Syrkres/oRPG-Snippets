---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: cloak_of_elvenkind
source: dmg
rarity: uncommon
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Cloak of Elvenkind
> ![[Cloak of Elvenkind.jpg|Cloak of Elvenkind]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | Requires Attunement |
> | **Value** | 2,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Cloak of Elvenkind
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While you wear this cloak with its hood up, Wisdom (Perception) checks made to see you have disadvantage, and you have advantage on Dexterity (Stealth) checks made to hide, as the cloak&#39;s color shifts to camouflage you. Pulling the hood up or down requires an action.



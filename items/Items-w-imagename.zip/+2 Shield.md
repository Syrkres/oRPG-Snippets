---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: +2_shield_(*)
source: dmg
rarity: rare
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # +2 Shield (*)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  +2 Shield (*)
**Type:** generic variant

**Rarity:** Rare
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** * This generic variant has the same name and source as the item +2 shield.While holding this shield, you have a +2 bonus to AC. This bonus is in addition to the shield&#39;s normal bonus to AC. Base items. This item variant can be applied to the following base items:Shield (+2 Shield)



---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: ceremonial_electrum_dagger_with_a_black_pearl_in_the_pommel
source: dmg
rarity: none
attunement: none_required
value: 750_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Ceremonial electrum dagger with a black pearl in the pommel
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 750 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Ceremonial electrum dagger with a black pearl in the pommel
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 750 gp
**Weight:** Varies

**Description:**



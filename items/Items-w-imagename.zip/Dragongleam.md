---
cssclass: oRPGPage
fileType: item
itemType: weapon_(spear)_simple_weapon_melee_weapon
name: dragongleam
source: hotdq
rarity: unknown_(magic)
attunement: none_required
value: varies
weight: 3_lb.
properties: 1d6_piercing_-_thrown_(20&#x2F;60_ft.)_versatile_(1d8)
---
> [!oRPG-Item]
> # Dragongleam
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (spear), simple weapon, melee weapon |
> |**Rarity** | Unknown (magic) |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 3 lb. |
>  |**Properties** | 1d6, piercing, - thrown (20&#x2F;60 ft.), versatile (1d8) |
> | **Source** | HotDQ |

#  Dragongleam
**Type:** weapon (spear), simple weapon, melee weapon

**Rarity:** Unknown (magic)
**Attunement:** None Required
**Source:** HotDQ
**Properties:** 1d6, piercing, - thrown (20&#x2F;60 ft.), versatile (1d8)
**Value:** Varies
**Weight:** 3 lb.

**Description:** This spear is enchanted with 10 charges of a daylight spell for use in twilight or dark forest underbrush. The command phrase is &quot;Tiamat&#39;s eyes shine,&quot; written in Draconic runes on the spear&#39;s crossguard. Thrown. If a weapon has the thrown property, you can throw the weapon to make a ranged attack. If the weapon is a melee weapon, you use the same ability modifier for that attack roll and damage roll that you would use for a melee attack with the weapon. For example, if you throw a handaxe, you use your Strength, but if you throw a dagger, you can use either your Strength or your Dexterity, since the dagger has the finesse property. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.



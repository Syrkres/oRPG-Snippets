---
cssclass: oRPGPage
fileType: item
itemType: generic_variant
name: dragons_wrath_weapon
source: ftd
rarity: varies
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Dragon&#39;s Wrath Weapon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | generic variant |
> |**Rarity** | Varies |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | FTD |

#  Dragon&#39;s Wrath Weapon
**Type:** generic variant

**Rarity:** Varies
**Attunement:** Requires Attunement
**Source:** FTD
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** This weapon is decorated with dragon heads, claws, wings, scales, or Draconic letters. When it steeps in a dragon&#39;s hoard, it absorbs the energy of the dragon&#39;s breath weapon and deals damage of that type with its special properties.Multiple variations of this item exist, as listed below:Slumbering Dragon&#39;s Wrath WeaponStirring Dragon&#39;s Wrath WeaponWakened Dragon&#39;s Wrath WeaponAscendant Dragon&#39;s Wrath Weapon



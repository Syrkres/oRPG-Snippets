---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: alchemists_fire_(flask)
source: phb
rarity: none
attunement: none_required
value: 50_gp
weight: 1_lb.
properties:
---
> [!oRPG-Item]
> # Alchemist&#39;s Fire (flask)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| 1 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Alchemist&#39;s Fire (flask)
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 50 gp
**Weight:** 1 lb.

**Description:** This sticky, adhesive fluid ignites when exposed to air. As an action, you can throw this flask up to 20 feet, shattering it on impact. Make a ranged attack against a creature or object, treating the alchemist&#39;s fire as an improvised weapon. On a hit, the target takes 1d4 fire damage at the start of each of its turns. A creature can end this damage by using its action to make a DC 10 Dexterity check to extinguish the flames.



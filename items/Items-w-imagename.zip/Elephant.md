---
cssclass: oRPGPage
fileType: item
itemType: mount
name: elephant
source: phb
rarity: none
attunement: none_required
value: 200_gp
weight: varies
properties: speed:_40_carrying_capacity:_1320_lb.
---
> [!oRPG-Item]
> # Elephant
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | mount |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 200 gp |
>  | **Weight**| Varies |
>  |**Properties** | Speed: 40, Carrying Capacity: 1320 lb. |
> | **Source** | PHB |

#  Elephant
**Type:** mount

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:** Speed: 40, Carrying Capacity: 1320 lb.
**Value:** 200 gp
**Weight:** Varies

**Description:**



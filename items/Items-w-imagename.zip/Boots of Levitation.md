---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: boots_of_levitation
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Boots of Levitation
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | 7,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Boots of Levitation
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While you wear these boots, you can use an action to cast the levitate spell on yourself at will.



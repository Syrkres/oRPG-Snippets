---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Guiding_Bolt
school: Evocation
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: 120 feet
duration: 1 round
classes: Cleric,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Guiding Bolt
> Evocation  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 120 feet
**Duration:**  1 round
**Description:**
A flash of light streaks toward a creature of your choice within range. Make a ranged spell attack against the target. On a hit, the target takes 4d6 radiant damage, and the next attack roll made against this target before the end of your next turn has advantage, thanks to the mystical dim light glittering on the target until then.

When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d6 for each slot level above 1st.

**Classes:**  *Cleric, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Longstrider
school: Transmutation
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a pinch of dirt)
range: Touch
duration: 1 hour
classes: Bard, Druid, Ranger, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Longstrider
> Transmutation  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a pinch of dirt)
**Range:** Touch
**Duration:**  1 hour
**Description:**
You touch a creature. The target's speed increases by 10 feet until the spell ends.

When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each spell slot above 1st.

**Classes:**  *Bard, Druid, Ranger, Wizard, *



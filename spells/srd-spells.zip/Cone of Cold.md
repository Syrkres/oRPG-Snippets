---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Cone_of_Cold
school: Evocation
level: 5
castingTime: 1 action
ritual: false
components: V, S, M (a small crystal or a glass cone)
range: Self (60-foot cone)
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEvocation]
>#  Cone of Cold
> Evocation  (5)

**Casting Time:** 1 action
**Components:** V, S, M (a small crystal or a glass cone)
**Range:** Self (60-foot cone)
**Duration:**  Instantaneous
**Description:**
A blast of cold air erupts from your hands. Each creature in a 60-foot cone must make a Constitution saving throw. A creature takes 8d8 cold damage on a failed save, or half as much damage on a successful one.



 A creature killed by this spell becomes a frozen statue until it thaws.

When you cast this spell using a spell slot of 6th level or higher, the damage increases by 1d8 for each slot level above 5th.

**Classes:**  *Sorcerer, Wizard, *



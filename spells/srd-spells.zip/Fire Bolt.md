---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Fire_Bolt
school: Evocation
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: 120 feet
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Fire Bolt
> Evocation  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 120 feet
**Duration:**  Instantaneous
**Description:**
You hurl a mote of fire at a creature or object within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 fire damage. A flammable object hit by this spell ignites if it isn't being worn or carried. This spell’s damage increases by 1d10 when you reach 5th level (2d10), 11th level (3d10), and 17th level (4d10).



**Classes:**  *Sorcerer, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Power_Word_Heal
school: Evocation
level: 9
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Instantaneous
classes: Bard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Power Word Heal
> Evocation  (9)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
A wave of healing energy washes over the creature you touch. The target regains all its hit points. If the creature is charmed, frightened, paralyzed, or stunned, the condition ends. If the creature is prone, it can use its reaction to stand up. This spell has no effect on undead or constructs.



**Classes:**  *Bard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Protection_from_Poison
school: Abjuration
level: 2
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: 1 hour
classes: Cleric, Ranger, Paladin, Druid,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Protection from Poison
> Abjuration  (2)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  1 hour
**Description:**
You touch a creature. If it is poisoned, you neutralize the poison. If more than one poison afflicts the target, you neutralize one poison that you know is present, or you neutralize one at random. For the duration, the target has advantage on saving throws against being poisoned, and it has resistance to poison damage.



**Classes:**  *Cleric, Ranger, Paladin, Druid, *



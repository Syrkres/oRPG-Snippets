---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Meteor_Swarm
school: Evocation
level: 9
castingTime: 1 action
ritual: false
components: V, S
range: 1 mile
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Meteor Swarm
> Evocation  (9)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 1 mile
**Duration:**  Instantaneous
**Description:**
Blazing orbs of fire plummet to the ground at four different points you can see within range. Each creature in a 40-foot-radius sphere centered on each point you choose must make a Dexterity saving throw. The sphere spreads around corners. A creature takes 20d6 fire damage and 20d6 bludgeoning damage on a failed save, or half as much damage on a successful one. A creature in the area of more than one fiery burst is affected only once.



 The spell damages objects in the area and ignites flammable objects that aren't being worn or carried.



**Classes:**  *Sorcerer, Wizard, *



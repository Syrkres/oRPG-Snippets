---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Mind_Blank
school: Abjuration
level: 8
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: 24 hours
classes: Bard, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Mind Blank
> Abjuration  (8)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  24 hours
**Description:**
Until the spell ends, one willing creature you touch is immune to psychic damage, any effect that would sense its emotions or read its thoughts, divination spells, and the charmed condition. The spell even foils _[wish](../wish/ "wish (lvl 9)")_ spells and spells or effects of similar power used to affect the target's mind or to gain information about the target.



**Classes:**  *Bard, Wizard, *



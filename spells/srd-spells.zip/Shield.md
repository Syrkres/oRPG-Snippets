---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Shield
school: Abjuration
level: 1
castingTime: 1 reaction, which you take when you are hit by an attack or targeted by the magic missile spell
ritual: false
components: V, S
range: Self
duration: 1 round
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Shield
> Abjuration  (1)

**Casting Time:** 1 reaction, which you take when you are hit by an attack or targeted by the magic missile spell
**Components:** V, S
**Range:** Self
**Duration:**  1 round
**Description:**
An invisible barrier of magical force appears and protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from magic missile.



**Classes:**  *Sorcerer, Wizard, *



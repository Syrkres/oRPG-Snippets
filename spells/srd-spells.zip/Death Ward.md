---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Death_Ward
school: Abjuration
level: 4
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: 8 hours
classes: Cleric, Paladin,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Death Ward
> Abjuration  (4)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  8 hours
**Description:**
You touch a creature and grant it a measure of protection from death.



 The first time the target would drop to 0 hit points as a result of taking damage, the target instead drops to 1 hit point, and the spell ends.



 If the spell is still in effect when the target is subjected to an effect that would kill it instantaneously without dealing damage, that effect is instead negated against the target, and the spell ends.



**Classes:**  *Cleric, Paladin, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Control_Winds
school: Transmutation
level: 5
castingTime: 1 action
ritual: false
components: V, S
range: 300 feet
duration: Concentration, up to 1 hour
classes: Druid, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Control Winds
> Transmutation  (5)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 300 feet
**Duration:**  Concentration, up to 1 hour
**Description:**
You take control of the air in a 100-foot cube that you can see within range. Choose one of the following effects when you cast the spell. The effect lasts for the spell’s duration, unless you use your action on a later turn to switch to a different effect. You can also use your action to temporarily halt the effect or to restart one you’ve halted.



**Classes:**  *Druid, Sorcerer, Wizard, *



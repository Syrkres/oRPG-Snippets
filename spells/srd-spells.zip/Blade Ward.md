---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Blade_Ward
school: Abjuration
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: Self
duration: 1 round
classes: Bard, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Blade Ward
> Abjuration  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self
**Duration:**  1 round
**Description:**
You extend your hand and trace a sigil of warding in the air. Until the end of your next turn, you have resistance against bludgeoning, piercing, and slashing damage dealt by weapon attacks.



**Classes:**  *Bard, Sorcerer, Warlock, Wizard, *



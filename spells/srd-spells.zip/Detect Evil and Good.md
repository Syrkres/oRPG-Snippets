---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Detect_Evil_and_Good
school: Divination
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: Self
duration: Concentration, up to 10 minutes
classes: Cleric, Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGDivination]
>#  Detect Evil and Good
> Divination  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self
**Duration:**  Concentration, up to 10 minutes
**Description:**
For the duration, you know if there is an aberration, celestial, elemental, fey, fiend, or undead within 30 feet of you, as well as where the creature is located. Similarly, you know if there is a place or object within 30 feet of you that has been magically consecrated or desecrated.



 The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.



**Classes:**  *Cleric, Paladin, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Speak_with_Animals
school: Divination
level: 1
castingTime: 1 action
ritual: true
components: V, S
range: Self
duration: 10 minutes
classes: Bard, Druid, Ranger,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGDivination]
>#  Speak with Animals
> Divination  (1)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self
**Duration:**  10 minutes
**Description:**
You gain the ability to comprehend and verbally communicate with beasts for the duration. The knowledge and awareness of many beasts is limited by their intelligence, but at a minimum, beasts can give you information about nearby locations and monsters, including whatever they can perceive or have perceived within the past day. You might be able to persuade a beast to perform a small favor for you, at the DM's discretion.



**Classes:**  *Bard, Druid, Ranger, *



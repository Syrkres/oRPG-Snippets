---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Stoneskin
school: Abjuration
level: 4
castingTime: 1 action
ritual: false
components: V, S, M (diamond dust worth 100 gp, which the spell consumes)
range: Touch
duration: Concentration, up to 1 hour
classes: Druid, Sorcerer, Ranger, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGAbjuration]
>#  Stoneskin
> Abjuration  (4)

**Casting Time:** 1 action
**Components:** V, S, M (diamond dust worth 100 gp, which the spell consumes)
**Range:** Touch
**Duration:**  Concentration, up to 1 hour
**Description:**
This spell turns the flesh of a willing creature you touch as hard as stone. Until the spell ends, the target has resistance to nonmagical bludgeoning, piercing, and slashing damage.



**Classes:**  *Druid, Sorcerer, Ranger, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: False_Life
school: Necromancy
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a small amount of alcohol or distilled spirits)
range: Self
duration: 1 hour
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGNecromancy]
>#  False Life
> Necromancy  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a small amount of alcohol or distilled spirits)
**Range:** Self
**Duration:**  1 hour
**Description:**
Bolstering yourself with a necromantic facsimile of life, you gain 1d4 + 4 temporary hit points for the duration.

When you cast this spell using a spell slot of 2nd level or higher, you gain 5 additional temporary hit points for each slot level above 1st.

**Classes:**  *Sorcerer, Wizard, *



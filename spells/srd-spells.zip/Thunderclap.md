---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Thunderclap
school: Evocation
level: 0
castingTime: 1 action
ritual: false
components: S
range: Self (5-foot radius)
duration: Instantaneous
classes: Bard, Druid, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03vinactive.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Thunderclap
> Evocation  (cantrip)

**Casting Time:** 1 action
**Components:** S
**Range:** Self (5-foot radius)
**Duration:**  Instantaneous
**Description:**
You create a burst of thunderous sound, which can be heard 100 feet away. Each creature other than you within 5 feet of you must make a Constitution saving throw. On a failed save, the creature takes 1d6 thunder damage.



 The spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6).



**Classes:**  *Bard, Druid, Sorcerer, Warlock, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Fire_Shield
school: Evocation
level: 4
castingTime: 1 action
ritual: false
components: V, S, M (a bit of phosphorous or a firefly)
range: Self
duration: 10 minutes
classes: Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEvocation]
>#  Fire Shield
> Evocation  (4)

**Casting Time:** 1 action
**Components:** V, S, M (a bit of phosphorous or a firefly)
**Range:** Self
**Duration:**  10 minutes
**Description:**
Thin and wispy flames wreathe your body for the duration, shedding bright light in a 10-foot radius and dim light for an additional 10 feet, You can end the spell early by using an action to dismiss it.



 The flames provide you with a warm shield or a chill shield, as you choose. The warm shield grants you resistance to cold damage, and the chill shield grants you resistance to fire damage.



 In addition, whenever a creature within 5 feet of you hits you with a melee attack, the shield erupts with flame. The attacker takes 2d8 fire damage from a warm shield, or 2d8 cold damage from a cold shield.



**Classes:**  *Wizard, *



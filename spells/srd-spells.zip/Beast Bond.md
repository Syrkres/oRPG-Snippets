---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Beast_Bond
school: Divination
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a bit of fur wrapped in a cloth)
range: Touch
duration: Concentration, up to 10 minutes
classes: Druid, Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGDivination]
>#  Beast Bond
> Divination  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a bit of fur wrapped in a cloth)
**Range:** Touch
**Duration:**  Concentration, up to 10 minutes
**Description:**
You establish a telepathic link with one beast you touch that is friendly to you or charmed by you. The spell fails if the beast’s Intelligence is 4 or higher. Until the spell ends, the link is active while you and the beast are within line of sight of each other. Through the link, the beast can understand your telepathic messages to it, and it can telepathically communicate simple emotions and concepts back to you. While the link is active, the beast gains advantage on attack rolls against any creature within 5 feet of you that you can see.



**Classes:**  *Druid, Ranger, *



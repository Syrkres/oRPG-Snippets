---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Foresight
school: Divination
level: 9
castingTime: 1 minute
ritual: false
components: V, S, M (a hummingbird feather)
range: Touch
duration: 8 hours
classes: Bard, Druid, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGDivination]
>#  Foresight
> Divination  (9)

**Casting Time:** 1 minute
**Components:** V, S, M (a hummingbird feather)
**Range:** Touch
**Duration:**  8 hours
**Description:**
You touch a willing creature and bestow a limited ability to see into the immediate future. For the duration the target can't be surprised and has advantage on attack rolls, ability checks, and saving throws. Additionally, other creatures have disadvantage on attack rolls against the target for the duration.



 This spell immediately ends if you cast it again before its duration ends.



**Classes:**  *Bard, Druid, Warlock, Wizard, *



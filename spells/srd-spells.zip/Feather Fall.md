---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Feather_Fall
school: Transmutation
level: 1
castingTime: 1 reaction, which you take when you or a creature within 60 feet of you falls
ritual: false
components: V, M (a small feather or a piece of down)
range: 60 feet
duration: 1 minute
classes: Bard, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Feather Fall
> Transmutation  (1)

**Casting Time:** 1 reaction, which you take when you or a creature within 60 feet of you falls
**Components:** V, M (a small feather or a piece of down)
**Range:** 60 feet
**Duration:**  1 minute
**Description:**
Choose up to five falling creatures within range. A falling creature's rate of descent slows to 60 feet per round until the spell ends. If the creature lands before the spell ends, it takes no falling damage and can land on its feet, and the spell ends for that creature.



**Classes:**  *Bard, Sorcerer, Wizard, *



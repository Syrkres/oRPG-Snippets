---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Hold_Monster
school: Enchantment
level: 5
castingTime: 1 action
ritual: false
components: V, S, M (a small, straight piece of iron)
range: 90 feet
duration: Concentration, up to 1 minute
classes: Bard, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEnchantment]
>#  Hold Monster
> Enchantment  (5)

**Casting Time:** 1 action
**Components:** V, S, M (a small, straight piece of iron)
**Range:** 90 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
Choose a creature that you can see within range. The target must succeed on a Wisdom saving throw or be paralyzed for the duration. This spell has no effect on undead. At the end of each of its turns, the target can make another Wisdom saving throw. On a success, the spell ends on the target.

When you cast this spell using a spell slot of 6th level or higher, you can target one additional creature for each slot level above 5th. The creatures must be within 30 feet of each other when you target them.

**Classes:**  *Bard, Sorcerer, Warlock, Wizard, *



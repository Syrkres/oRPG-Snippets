---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Resistance
school: Abjuration
level: 0
castingTime: 1 action
ritual: false
components: V, S, M (a miniature cloak)
range: Touch
duration: Concentration, up to 1 minute
classes: Cleric, Druid,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGAbjuration]
>#  Resistance
> Abjuration  (cantrip)

**Casting Time:** 1 action
**Components:** V, S, M (a miniature cloak)
**Range:** Touch
**Duration:**  Concentration, up to 1 minute
**Description:**
You touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one saving throw of its choice. It can roll the die before or after making the saving throw. The spell then ends.



**Classes:**  *Cleric, Druid, *



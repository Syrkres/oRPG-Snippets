---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Water_Walk
school: Transmutation
level: 3
castingTime: 1 action
ritual: true
components: V, S, M (a piece of cork)
range: 30 feet
duration: 1 hour
classes: Cleric, Druid, Ranger, Sorcerer,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Water Walk
> Transmutation  (3)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S, M (a piece of cork)
**Range:** 30 feet
**Duration:**  1 hour
**Description:**
This spell grants the ability to move across any liquid surface--such as water, acid, mud, snow, quicksand, or lava--as if it were harmless solid ground (creatures crossing molten lava can still take damage from the heal). Up to ten willing creatures you can see within range gain this abilily for the duration.



 lf you target a creature submerged in a liquid, the spell carries the target to the surface of the liquid at a rate of 60 feet per round.



**Classes:**  *Cleric, Druid, Ranger, Sorcerer, *



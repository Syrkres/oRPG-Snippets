---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Healing_Word
school: Evocation
level: 1
castingTime: 1 bonus action
ritual: false
components: V
range: 60 feet
duration: Instantaneous
classes: Bard, Cleric, Druid,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Healing Word
> Evocation  (1)

**Casting Time:** 1 bonus action
**Components:** V
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
A creature of your choice that you can see within range regains hit points equal to 1d4 + your spellcasting ability modifier. This spell has no effect on undead or constructs.

When you cast this spell using a spell slot of 2nd level or higher, the healing increases by 1d4 for each slot level above 1st.

**Classes:**  *Bard, Cleric, Druid, *



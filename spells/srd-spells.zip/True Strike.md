---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: True_Strike
school: Divination
level: 0
castingTime: 1 action
ritual: false
components: S
range: 30 feet
duration: Concentration, up to 1 round
classes: Bard, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03vinactive.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGDivination]
>#  True Strike
> Divination  (cantrip)

**Casting Time:** 1 action
**Components:** S
**Range:** 30 feet
**Duration:**  Concentration, up to 1 round
**Description:**
You extend your hand and point a finger at a target in range. Your magic grants you a brief insight into the target's defenses. On your next turn, you gain advantage on your first attack roll against the target, provided that this spell hasn't ended.



**Classes:**  *Bard, Sorcerer, Warlock, Wizard, *



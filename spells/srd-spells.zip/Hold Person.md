---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Hold_Person
school: Enchantment
level: 2
castingTime: 1 action
ritual: true
components: V, S, M (a small, straight piece of iron)
range: 60 feet
duration: Concentration, up to 1 minute
classes: Bard, Cleric, Druid, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEnchantment]
>#  Hold Person
> Enchantment  (2)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S, M (a small, straight piece of iron)
**Range:** 60 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
Choose a humanoid that you can see within range. The target must succeed on a Wisdom saving throw or be paralyzed for the duration. At the end of each of its turns, the target can make another Wisdom saving throw. On a success, the spell ends on the target.

When you cast this spell using a spell slot of 3rd level or higher, you can target one additional humanoid for each slot level above 2nd. The humanoids must be within 30 feet of each other when you target them.

**Classes:**  *Bard, Cleric, Druid, Sorcerer, Warlock, Wizard, *



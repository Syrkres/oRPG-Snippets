---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Spare_the_Dying
school: Necromancy
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Instantaneous
classes: Cleric,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGNecromancy]
>#  Spare the Dying
> Necromancy  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
You touch a living creature that has 0 hit points. The creature becomes stable. This spell has no effect on undead or constructs.



**Classes:**  *Cleric, *



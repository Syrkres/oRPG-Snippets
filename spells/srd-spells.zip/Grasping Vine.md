---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Grasping_Vine
school: Conjuration
level: 4
castingTime: 1 bonus action
ritual: false
components: V, S
range: 30 feet
duration: Concentration, up to 1 minute
classes: Ranger, Druid,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Grasping Vine
> Conjuration  (4)

**Casting Time:** 1 bonus action
**Components:** V, S
**Range:** 30 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
You conjure a vine that sprouts from the ground in an unoccupied space of your choice that you can see within range. When you cast this spell, you can direct the vine to lash out at a creature within 30 feet of it that you can see. That creature must succeed on a Dexterity saving throw or be pulled 20 feet directly toward the vine.



 Until the spell ends, you can direct the vine to lash out at the same creature or another one as a bonus action on each of your turns.



**Classes:**  *Ranger, Druid, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Beacon_of_Hope
school: Abjuration
level: 3
castingTime: 1 action
ritual: false
components: V, S
range: 30 feet
duration: Concentration, up to 1 minute
classes: Cleric,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Beacon of Hope
> Abjuration  (3)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 30 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
This spell bestows hope and vitality. Choose any number of creatures within range. For the duration, each target has advantage on Wisdom saving throws and death saving throws, and regains the maximum number of hit points possible from any healing.



**Classes:**  *Cleric, *



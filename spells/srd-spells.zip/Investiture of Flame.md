---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Investiture_of_Flame
school: Transmutation
level: 6
castingTime: 1 action
ritual: false
components: V, S
range: Self
duration: Concentration, up to 10 minutes
classes: Druid, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Investiture of Flame
> Transmutation  (6)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self
**Duration:**  Concentration, up to 10 minutes
**Description:**
* You are immune to fire damage and have resistance to cold damage.



 * Any creature that moves within 5 feet of you for the first time on a turn or ends its turn there takes 1d10 fire damage.



 * You can use your action to create a line of fire 15 feet long and 5 feet wide extending from you in a direction you choose. Each creature in the line must make a Dexterity saving throw. A creature takes 4d8 fire damage on a failed save, or half as much damage on a successful one.



**Classes:**  *Druid, Sorcerer, Warlock, Wizard, *



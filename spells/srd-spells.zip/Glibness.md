---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Glibness
school: Transmutation
level: 8
castingTime: 1 action
ritual: false
components: V
range: Self
duration: 1 hour
classes: Bard, Warlock,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Glibness
> Transmutation  (8)

**Casting Time:** 1 action
**Components:** V
**Range:** Self
**Duration:**  1 hour
**Description:**
Until the spell ends, when you make a Charisma check, you can replace the number you roll with a 15. Additionally, no matter what you say, magic that would determine if you are telling the truth indicates that you are being truthful.



**Classes:**  *Bard, Warlock, *



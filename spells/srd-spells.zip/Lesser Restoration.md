---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Lesser_Restoration
school: Abjuration
level: 2
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Instantaneous
classes: Bard, Cleric, Druid, Paladin, Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Lesser Restoration
> Abjuration  (2)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
You touch a creature and can end either one disease or one condition afflicting it. The condition can be blinded, deafened, paralyzed, or poisoned.



**Classes:**  *Bard, Cleric, Druid, Paladin, Ranger, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Inflict_Wounds
school: Necromancy
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Instantaneous
classes: Cleric,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGNecromancy]
>#  Inflict Wounds
> Necromancy  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
Make a melee spell attack against a creature you can reach. On a hit, the target takes 3d10 necrotic damage.

When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d10 for each slot level above 1st.

**Classes:**  *Cleric, *



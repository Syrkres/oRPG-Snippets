---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Phantasmal_Killer
school: Illusion
level: 4
castingTime: 1 action
ritual: false
components: V, S
range: 120 feet
duration: Concentration, up to 1 minute
classes: Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGIllusion]
>#  Phantasmal Killer
> Illusion  (4)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 120 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
You tap into the nightmares of a creature you can see within range and create an illusory manifestation of its deepest fears, visible only to that creature. The target must make a Wisdom saving throw. On a failed save, the target becomes frightened for the duration. At the start of each of the target's turns before the spell ends, the target must succeed on a Wisdom saving throw or take 4d10 psychic damage. On a successful save, the spell ends.

When you cast this spell using a spell slot of 5th level or higher, the damage increases by 1d10 for each slot level above 4th.

**Classes:**  *Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Create_Food_and_Water
school: Conjuration
level: 3
castingTime: 1 action
ritual: false
components: V, S
range: 30 feet
duration: Instantaneous
classes: Cleric, Paladin,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Create Food and Water
> Conjuration  (3)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 30 feet
**Duration:**  Instantaneous
**Description:**
You create 45 pounds of food and 30 gallons of water on the ground or in containers within range, enough to sustain up to fifteen humanoids or five steeds for 24 hours. The food is bland but nourishing, and spoils if uneaten after 24 hours. The water is clean and doesn’t go bad.



**Classes:**  *Cleric, Paladin, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Power_Word_Stun
school: Enchantment
level: 8
castingTime: 1 action
ritual: false
components: V
range: 60 feet
duration: Instantaneous
classes: Bard, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEnchantment]
>#  Power Word Stun
> Enchantment  (8)

**Casting Time:** 1 action
**Components:** V
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
You speak a word of power that can overwhelm the mind of one creature you can see within range, leaving it dumbfounded. If the target has 150 hit points or fewer, it is stunned. Otherwise, the spell has no effect.



 The stunned target must make a Constitution saving throw at the end of each of its turns.  On a successful save, this stunning effect ends.



**Classes:**  *Bard, Sorcerer, Warlock, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Remove_Curse
school: Abjuration
level: 3
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Instantaneous
classes: Cleric, Paladin, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Remove Curse
> Abjuration  (3)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
At your touch, all curses affecting one creature or object end. If the object is a cursed magical item, its curse remains, but the spell breaks its owner's attunement to the object so it can be removed or discarded.



**Classes:**  *Cleric, Paladin, Warlock, Wizard, *



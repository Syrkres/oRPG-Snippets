---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Staggering_Smite
school: Evocation
level: 4
castingTime: 1 bonus action
ritual: false
components: V
range: Self
duration: Concentration, up to 1 minute
classes: Paladin,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Staggering Smite
> Evocation  (4)

**Casting Time:** 1 bonus action
**Components:** V
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
The next time you hit a creature with a melee weapon attack during this spell's duration, your weapon pierces both body and mind, and the attack deals an extra 4d6 psychic damage to the target. The target must make a Wisdom saving throw. On a failed save, it has disadvantage on attack rolls and ability checks, and can't take reactions, until the end of its next turn.



**Classes:**  *Paladin, *



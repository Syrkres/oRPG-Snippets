---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Nondetection
school: Abjuration
level: 3
castingTime: 1 action
ritual: false
components: V, S, M (a pinch of diamond dust worth 25 gp sprinkled over the target, which the spell consumes)
range: Touch
duration: 8 hours
classes: Bard, Ranger, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGAbjuration]
>#  Nondetection
> Abjuration  (3)

**Casting Time:** 1 action
**Components:** V, S, M (a pinch of diamond dust worth 25 gp sprinkled over the target, which the spell consumes)
**Range:** Touch
**Duration:**  8 hours
**Description:**
For the duration, you hide a target that you touch from divination magic. The target can be a willing creature or a place or an object no larger than 10 feet in any dimension. The target can’t be targeted by any divination magic or perceived through magical scrying sensors.



**Classes:**  *Bard, Ranger, Wizard, *



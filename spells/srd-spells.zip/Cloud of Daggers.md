---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Cloud_of_Daggers
school: Conjuration
level: 2
castingTime: 1 action
ritual: false
components: V, S, M (a sliver of glass)
range: 60 feet
duration: Concentration, up to 1 minute
classes: Bard, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGConjuration]
>#  Cloud of Daggers
> Conjuration  (2)

**Casting Time:** 1 action
**Components:** V, S, M (a sliver of glass)
**Range:** 60 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
You fill the air with spinning daggers in a cube 5 feet on each side, centered on a point you choose within range. A creature takes 4d4 slashing damage when it enters the spell’s area for the first time on a turn or starts its turn there.

When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 2d4 for each slot level above 2nd.

**Classes:**  *Bard, Sorcerer, Warlock, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Protection_from_Energy
school: Abjuration
level: 3
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Concentration, up to 1 minute
classes: Cleric, Druid, Ranger, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Protection from Energy
> Abjuration  (3)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Concentration, up to 1 minute
**Description:**
For the duration, the willing creature you touch has resistance to one damage type of your choice: acid, cold, fire, lightning, or thunder.



**Classes:**  *Cleric, Druid, Ranger, Sorcerer, Wizard, *



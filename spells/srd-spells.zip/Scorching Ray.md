---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Scorching_Ray
school: Evocation
level: 2
castingTime: 1 action
ritual: false
components: V, S
range: 120 feet
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Scorching Ray
> Evocation  (2)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 120 feet
**Duration:**  Instantaneous
**Description:**
You create three rays of fire and hurl them at targets within range. You can hurl them at one target or several.



 Make a ranged spell attack for each ray. On a hit, the target takes 2d6 fire damage.

When you cast this spell using a spell slot of 3rd level or higher, you create one additional ray for each slot level above 2nd.

**Classes:**  *Sorcerer, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Magic_Missile
school: Evocation
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: 120 feet
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Magic Missile
> Evocation  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 120 feet
**Duration:**  Instantaneous
**Description:**
You create three glowing darts of magical force. Each dart hits a creature of your choice that you can see within range. A dart deals 1d4 + 1 force damage to its target. The darts all strike simultaneously, and you can direct them to hit one creature or several.

When you cast this spell using a spell slot of 2nd level or higher, the spell creates one more dart for each slot level above 1st.

**Classes:**  *Sorcerer, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Friends
school: Enchantment
level: 0
castingTime: 1 action
ritual: false
components: S, M (a small amount of makeup applied to the face as this spell is cast)
range: Self
duration: Concentration, up to 1 minute
classes: Bard, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03vinactive.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEnchantment]
>#  Friends
> Enchantment  (cantrip)

**Casting Time:** 1 action
**Components:** S, M (a small amount of makeup applied to the face as this spell is cast)
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
For the duration, you have advantage on all Charisma checks directed at one creature of your choice that isn't hostile toward you. When the spell ends, the creature realizes that you have used magic to influence its mood and becomes hostile toward you. A creature prone to violence might attack you. Another creature might seek retribution in other ways (at the DM's discretion), depending on the nature of your interaction with it.



**Classes:**  *Bard, Sorcerer, Warlock, Wizard, *



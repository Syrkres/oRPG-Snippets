---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Ice_Knife
school: Conjuration
level: 1
castingTime: 1 action
ritual: false
components: S, M (a drop of water or piece of ice)
range: 60 feet
duration: Instantaneous
classes: Druid, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03vinactive.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGConjuration]
>#  Ice Knife
> Conjuration  (1)

**Casting Time:** 1 action
**Components:** S, M (a drop of water or piece of ice)
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
You create a shard of ice and fling it at one creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 piercing damage. Hit or miss, the shard then explodes. The target and each creature within 5 feet of the point where the ice exploded must succeed on a Dexterity saving throw or take 2d6 cold damage.

When you cast this spell using a spell slot of 2nd level or higher, the cold damage increases by 1d6 for each slot level above 1st.

**Classes:**  *Druid, Sorcerer, Wizard, *



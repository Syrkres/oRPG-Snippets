---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Tongues
school: Divination
level: 3
castingTime: 1 action
ritual: false
components: V, M (a small clay model of a ziggurat)
range: Touch
duration: 1 hour
classes: Bard, Cleric, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGDivination]
>#  Tongues
> Divination  (3)

**Casting Time:** 1 action
**Components:** V, M (a small clay model of a ziggurat)
**Range:** Touch
**Duration:**  1 hour
**Description:**
This spell grants the creature you touch the ability to understand any spoken language it hears. Moreover, when the target speaks, any creature that knows at least one language and can hear the target understands what it says.



**Classes:**  *Bard, Cleric, Sorcerer, Warlock, Wizard, *



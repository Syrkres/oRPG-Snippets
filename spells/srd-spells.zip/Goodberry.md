---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Goodberry
school: Transmutation
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a sprig of mistletoe)
range: Touch
duration: Instantaneous
classes: Druid, Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Goodberry
> Transmutation  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a sprig of mistletoe)
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
Up to ten berries appear in your hand and are infused with magic for the duration. A creature can use its action to eat one berry. Eating a berry restores 1 hit point, and the berry provides enough nourishment to sustain a creature for a day.



 The berries lose their potency if they have not been consumed within 24 hours of the casting of this spell.



**Classes:**  *Druid, Ranger, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Skywrite
school: Transmutation
level: 2
castingTime: 1 action
ritual: true
components: V, S
range: Sight
duration: Concentration, up to 1 hour
classes: Bard, Druid, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Skywrite
> Transmutation  (2)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S
**Range:** Sight
**Duration:**  Concentration, up to 1 hour
**Description:**
You cause up to ten words to form in a part of the sky you can see. The words appear to be made of cloud and remain in place for the spell’s duration. The words dissipate when the spell ends. A strong wind can disperse the clouds and end the spell early



**Classes:**  *Bard, Druid, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Conjure_Celestial
school: Conjuration
level: 7
castingTime: 1 minute
ritual: false
components: V, S
range: 90 feet
duration: Concentration, up to 1 hour
classes: Cleric,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Conjure Celestial
> Conjuration  (7)

**Casting Time:** 1 minute
**Components:** V, S
**Range:** 90 feet
**Duration:**  Concentration, up to 1 hour
**Description:**
You summon a celestial of challenge rating 4 or lower, which apperas in an unoccupied space that you can see within range. The celestial disappears when it drops to 0 hit points or when the spell ends.



 The celestial is friendly to you and your companions for the duration. Roll initiative for the celestial, which has its own turns. It obeys any verbal commands that you issue to it (no action required by you), as long as they don't violate its alignment. If you don't issue any commands to the celestial, it defends itself from hostile creatures but otherwise takes no actions.



 The DM has the celestial's statistics.

When you cast this spell using a 9th-level spell slot, you summon a celestial of challenge rating 5 or lower.

**Classes:**  *Cleric, *



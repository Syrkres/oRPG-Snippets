---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Ray_of_Sickness
school: Necromancy
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: 60 feet
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGNecromancy]
>#  Ray of Sickness
> Necromancy  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
A ray of sickening greenish energy lashes out toward a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 2d8 poison damage and must make a Constitution saving throw. On a failed save, it is also poisoned until the end of your next turn.

When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d8 for each slot level above 1st.

**Classes:**  *Sorcerer, Wizard, *



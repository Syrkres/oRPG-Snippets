---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Earthbind
school: Transmutation
level: 2
castingTime: 1 action
ritual: false
components: V
range: 300 feet
duration: Concentration, up to 1 minute
classes: Druid, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Earthbind
> Transmutation  (2)

**Casting Time:** 1 action
**Components:** V
**Range:** 300 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
Choose one creature you can see within range. Yellow strips of magical energy loop around the creature. The target must succeed on a Strength saving throw or its flying speed (if any) is reduced to 0 feet for the spell’s duration. An airborne creature affected by this spell descends at 60 feet per round until it reaches the ground or the spell ends.



**Classes:**  *Druid, Sorcerer, Warlock, Wizard, *



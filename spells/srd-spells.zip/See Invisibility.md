---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: See_Invisibility
school: Divination
level: 2
castingTime: 1 action
ritual: false
components: V, S, M (a pinch of tale and a small sprinkling of powdered silver)
range: Self
duration: 1 hour
classes: Bard, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGDivination]
>#  See Invisibility
> Divination  (2)

**Casting Time:** 1 action
**Components:** V, S, M (a pinch of tale and a small sprinkling of powdered silver)
**Range:** Self
**Duration:**  1 hour
**Description:**
For the duration, you see invisible creatures and objects as if they were visible, and you can see into the Ethereal Plane. Ethereal creatures and objects appear ghostly and translucent.



**Classes:**  *Bard, Sorcerer, Wizard, *



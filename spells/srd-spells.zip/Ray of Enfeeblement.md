---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Ray_of_Enfeeblement
school: Necromancy
level: 2
castingTime: 1 action
ritual: false
components: V, S
range: 60 feet
duration: Concentration, up to 1 minute
classes: Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGNecromancy]
>#  Ray of Enfeeblement
> Necromancy  (2)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 60 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
A black beam of enervating energy springs from your finger toward a creature within range. Make a ranged spell attack against the target. On a hit, the target deals only half damage with weapon attacks that use Strength until the spell ends.



 At the end of each of the target's turns, it can make a Constitution saving throw against the spell. On a success, the spell ends.



**Classes:**  *Warlock, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Gust
school: Transmutation
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: 30 feet
duration: Instantaneous
classes: Druid, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Gust
> Transmutation  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 30 feet
**Duration:**  Instantaneous
**Description:**
* One Medium or smaller creature that you choose must succeed on a Strength saving throw or be pushed up to 5 feet away from you.



 * You create a small blast of air capable of moving one object that is neither held nor carried and that weighs no more than 5 pounds. The object is pushed up to 10 feet away from you. It isn’t pushed with enough force to cause damage.



 * You create a harmless sensory affect using air, such as causing leaves to rustle, wind to slam shutters shut, or your clothing to ripple in a breeze.



**Classes:**  *Druid, Sorcerer, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Create_Bonfire
school: Conjuration
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: 60 feet
duration: Concentration, up to 1 minute
classes: Druid, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Create Bonfire
> Conjuration  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 60 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
You create a bonfire on ground that you can see within range. Until the spell ends, the bonfire fills a 5-foot cube. Any creature in the bonfire’s space when you cast the spell must succeed on a Dexterity saving throw or take 1d8 fire damage. A creature must also make the saving throw when it enters the bonfire’s space for the first time on a turn or ends its turn there.



 The spell’s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).



**Classes:**  *Druid, Sorcerer, Warlock, Wizard, *



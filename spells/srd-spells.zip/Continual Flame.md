---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Continual_Flame
school: Evocation
level: 2
castingTime: 1 action
ritual: false
components: V, S, M (ruby dust worth 50 gp, which the spell consumes)
range: Self
duration: Until dispelled
classes: Cleric, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEvocation]
>#  Continual Flame
> Evocation  (2)

**Casting Time:** 1 action
**Components:** V, S, M (ruby dust worth 50 gp, which the spell consumes)
**Range:** Self
**Duration:**  Until dispelled
**Description:**
A flame, equivalent in brightness to a torch, springs forth from an object that you touch. The effect looks like a regular flame, but it creates no heat and doesn't use oxygen. A *continual flame* can be covered or hidden but not smothered or quenched.



**Classes:**  *Cleric, Wizard, *



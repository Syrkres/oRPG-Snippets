---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Thorn_Whip
school: Transmutation
level: 0
castingTime: 1 action
ritual: false
components: V, S, M (the stem of a plant with thorns)
range: 30 feet
duration: Instantaneous
classes: Druid,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Thorn Whip
> Transmutation  (cantrip)

**Casting Time:** 1 action
**Components:** V, S, M (the stem of a plant with thorns)
**Range:** 30 feet
**Duration:**  Instantaneous
**Description:**
You create a long, vine-like whip covered in thorns that lashes out at your command toward a creature in range. Make a melee spell attack against the target. If the attack hits, the creature takes 1d6 piercing damage, and if the creature is Large or smaller, you pull the creature up to 10 feet closer to you.



 This spell's damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6).



**Classes:**  *Druid, *



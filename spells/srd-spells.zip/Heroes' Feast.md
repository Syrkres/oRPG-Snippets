---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Heroes'_Feast
school: Conjuration
level: 6
castingTime: 10 minutes
ritual: false
components: V, S, M (a gem-encrusted bowl worth at least 1,000 gp, which the spell consumes)
range: 30 feet
duration: Instantaneous
classes: Cleric, Druid,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGConjuration]
>#  Heroes' Feast
> Conjuration  (6)

**Casting Time:** 10 minutes
**Components:** V, S, M (a gem-encrusted bowl worth at least 1,000 gp, which the spell consumes)
**Range:** 30 feet
**Duration:**  Instantaneous
**Description:**
You bring forth a great feast, including magnificent food and drink. The feast takes 1 hour to consume and disappears at the end of that time, and the beneficial effects don’t set in until this hour is over. Up to twelve other creatures can partake of the feast.



 A creature that partakes of the feast gains several benefits. The creature is cured of all diseases and poison, becomes immune to poison and being frightened, and makes all Wisdom saving throws with advantage. Its hit point maximum also increases by 2d10, and it gains the same number of hit points. These benefits last for 24 hours



**Classes:**  *Cleric, Druid, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Barkskin
school: Transmutation
level: 2
castingTime: 1 action
ritual: false
components: V, S, M (a handful of oak bark)
range: Touch
duration: Concentration, up to 1 hour
classes: Druid, Ranger,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Barkskin
> Transmutation  (2)

**Casting Time:** 1 action
**Components:** V, S, M (a handful of oak bark)
**Range:** Touch
**Duration:**  Concentration, up to 1 hour
**Description:**
You touch a willing creature. Until the spell ends, the target’s skin has a rough, bark-like appearance, and the target’s AC can’t be less than 16, regardless of what kind of armor it is wearing.



**Classes:**  *Druid, Ranger, *



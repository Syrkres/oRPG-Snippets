---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Hail_of_Thorns
school: Conjuration
level: 1
castingTime: 1 bonus action
ritual: false
components: V
range: Self
duration: Concentration, up to 1 minute
classes: Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Hail of Thorns
> Conjuration  (1)

**Casting Time:** 1 bonus action
**Components:** V
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
The next time you hit a creature with a ranged weapon attack before this spell ends, this spell creates a rain of thorns that sprouts from your ranged weapon or ammunition. In addition to the normal effects of the attack, the target of the attack and each creature within 5 feet of it must make a Dexterity saving throw. A creature takes 1d10 piercing damage on a failed save, or half as much damage on a successful one.

If you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d10 for each slot level above 1st (to a maximum of 6d10).

**Classes:**  *Ranger, *



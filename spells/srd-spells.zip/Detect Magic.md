---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Detect_Magic
school: Divination
level: 1
castingTime: 1 action
ritual: true
components: V, S
range: Self
duration: Concentration, up to 10 minutes
classes: Bard, Cleric, Druid, Paladin, Ranger, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGDivination]
>#  Detect Magic
> Divination  (1)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self
**Duration:**  Concentration, up to 10 minutes
**Description:**
For the duration, you sense the presence of magic within 30 feet of you. If you sense magic in this way, you can use your action to see a faint aura around any visible creature or object in the area that bears magic, and you learn its school of magic, if any.



 The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.



**Classes:**  *Bard, Cleric, Druid, Paladin, Ranger, Sorcerer, Wizard, *



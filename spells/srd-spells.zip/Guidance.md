---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Guidance
school: Divination
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Concentration, up to 1 minute
classes: Cleric, Druid,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGDivination]
>#  Guidance
> Divination  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Concentration, up to 1 minute
**Description:**
You touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one ability check of its choice. It can roll the die before or after making the ability check. The spell then ends.



**Classes:**  *Cleric, Druid, *



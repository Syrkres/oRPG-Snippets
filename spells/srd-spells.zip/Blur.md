---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Blur
school: Illusion
level: 2
castingTime: 1 action
ritual: false
components: V
range: Self
duration: Concentration, up to 1 minute
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGIllusion]
>#  Blur
> Illusion  (2)

**Casting Time:** 1 action
**Components:** V
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
Your body becomes blurred, shifting and wavering to all who can see you. For the duration, any creature has disadvantage on attack rolls against you. An attacker is immune to this effect if it doesn’t rely on sight, as with blindsight, or can see through illusions, as with truesight.



**Classes:**  *Sorcerer, Wizard, *



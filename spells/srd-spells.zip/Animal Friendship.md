---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Animal_Friendship
school: Enchantment
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a morsel of food)
range: 30 feet
duration: 24 hours
classes: Bard, Druid, Ranger,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEnchantment]
>#  Animal Friendship
> Enchantment  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a morsel of food)
**Range:** 30 feet
**Duration:**  24 hours
**Description:**
This spell lets you convince a beast that you mean it no harm. Choose a beast that you can see within range. It must see and hear you. If the beast's Intelligence is 4 or higher, the spell fails. Otherwise, the beast must succeed on a Wisdom saving throw or be charmed by you for the spell's duration. If you or one of your companions harms the target, the spell ends.

When you cast this spell using a spell slot of 2nd level or higher, you can affect one additional beast for each slot level above 1st.

**Classes:**  *Bard, Druid, Ranger, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Darkvision
school: Transmutation
level: 2
castingTime: 1 action
ritual: false
components: V, S, M (either a pinch of dried carrot or an agate)
range: Touch
duration: 8 hours
classes: Druid, Ranger, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Darkvision
> Transmutation  (2)

**Casting Time:** 1 action
**Components:** V, S, M (either a pinch of dried carrot or an agate)
**Range:** Touch
**Duration:**  8 hours
**Description:**
You touch a willing creature to grant it the ability to see in the dark. For the duration, that creature has darkvision out to a range of 60 feet.



**Classes:**  *Druid, Ranger, Sorcerer, Wizard, *



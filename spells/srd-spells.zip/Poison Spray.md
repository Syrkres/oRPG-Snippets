---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Poison_Spray
school: Conjuration
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: 10 feet
duration: Instantaneous
classes: Druid, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Poison Spray
> Conjuration  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 10 feet
**Duration:**  Instantaneous
**Description:**
You extend your hand toward a creature you can see within range and project a puff of noxious gas from your palm. The creature must succeed on a Constitution saving throw or take 1d12 poison damage.



 This spell's damage increases by 1d12 when you reach 5th level (2d12), 11th level (3d12), and 17th level (4d12).



**Classes:**  *Druid, Sorcerer, Warlock, Wizard, *



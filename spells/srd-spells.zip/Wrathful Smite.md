---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Wrathful_Smite
school: Evocation
level: 1
castingTime: 1 bonus action
ritual: false
components: V
range: Self
duration: Concentration, up to 1 minute
classes: Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Wrathful Smite
> Evocation  (1)

**Casting Time:** 1 bonus action
**Components:** V
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
The next time you hit with a melee weapon attack during this spell's duration, your attack deals an extra 1d6 psychic damage. Additionally, if the target is a creature, it must make a Wisdom saving throw or be frightened of you until the spell ends. As an action, the creature can make a Wisdom check against your spell save DC to steel its resolve and end this spell.



**Classes:**  *Paladin, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Divine_Favor
school: Evocation
level: 1
castingTime: 1 bonus action
ritual: false
components: V, S
range: Self
duration: Concentration, up to 1 minute
classes: Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Divine Favor
> Evocation  (1)

**Casting Time:** 1 bonus action
**Components:** V, S
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
Your prayer empowers you with divine radiance. Until the spell ends, your weapon attacks deal an extra 1d4 radiant damage on a hit.



**Classes:**  *Paladin, *



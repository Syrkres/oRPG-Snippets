---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Flame_Arrows
school: Transmutation
level: 3
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Concentration, up to 1 hour
classes: Druid, Ranger, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Flame Arrows
> Transmutation  (3)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Concentration, up to 1 hour
**Description:**
You touch a quiver containing arrows or bolts. When a target is hit by a ranged weapon attack using a piece of ammunition drawn from the quiver, the target takes an extra 1d6 fire damage. The spell’s magic ends on the piece of ammunition when it hits or misses, and the spell ends when twelve pieces of ammunition have been drawn from the quiver.

When you cast this spell using a spell slot of 4th level or higher, the number of pieces of ammunition you can affect with this spell increases by two for each slot level above 3rd.

**Classes:**  *Druid, Ranger, Sorcerer, Wizard, *



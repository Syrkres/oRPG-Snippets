---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Freedom_of_Movement
school: Abjuration
level: 4
castingTime: 1 action
ritual: false
components: V, S, M (a leather strap, bound around the arm or a similar appendage)
range: Touch
duration: 1 hour
classes: Bard, Cleric, Druid, Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGAbjuration]
>#  Freedom of Movement
> Abjuration  (4)

**Casting Time:** 1 action
**Components:** V, S, M (a leather strap, bound around the arm or a similar appendage)
**Range:** Touch
**Duration:**  1 hour
**Description:**
You touch a willing creature. For the duration, the target's movement is unaffected by difficult terrain, and spells and other magical effects can neither reduce the target's speed nor cause the target to be paralyzed or restrained.



 The target can also spend 5 feet of movement to automatically escape from nonmagical restraints, such as manacles or a creature that has it grappled. Finally, being underwater imposes no penalties on the target's movement or attacks.



**Classes:**  *Bard, Cleric, Druid, Ranger, *



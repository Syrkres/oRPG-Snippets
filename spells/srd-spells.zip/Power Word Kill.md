---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Power_Word_Kill
school: Enchantment
level: 9
castingTime: 1 action
ritual: false
components: V
range: 60 feet
duration: Instantaneous
classes: Bard, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEnchantment]
>#  Power Word Kill
> Enchantment  (9)

**Casting Time:** 1 action
**Components:** V
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
You utter a word of power that can compel one creature you can see within range to die instantly.  If the creature you choose has 100 hit points or fewer, it dies. Otherwise, the spell has no effect.



**Classes:**  *Bard, Sorcerer, Warlock, Wizard, *



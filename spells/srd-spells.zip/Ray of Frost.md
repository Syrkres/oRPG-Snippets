---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Ray_of_Frost
school: Evocation
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: 60 feet
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Ray of Frost
> Evocation  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
A frigid beam of blue-white light streaks toward a creature within range. Make a ranged spell attack against the target. On a hit, it takes 1d8 cold damage, and its speed is reduced by 10 feet until the start of your next turn.



 The spell’s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).



**Classes:**  *Sorcerer, Wizard, *



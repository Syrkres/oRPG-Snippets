---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Purify_Food_and_Drink
school: Transmutation
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: 10 feet
duration: Instantaneous
classes: Cleric, Druid, Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Purify Food and Drink
> Transmutation  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 10 feet
**Duration:**  Instantaneous
**Description:**
All nonmagical food and drink within a 5-foot radius sphere centered on a point of your choice within range is purified and rendered free of poison and disease.



**Classes:**  *Cleric, Druid, Paladin, *



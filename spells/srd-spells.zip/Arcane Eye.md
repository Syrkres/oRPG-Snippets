---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Arcane_Eye
school: Divination
level: 4
castingTime: 1 action
ritual: false
components: V, S, M (a bit of bat fur)
range: 30 feet
duration: Concentration, up to 1 hour
classes: Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGDivination]
>#  Arcane Eye
> Divination  (4)

**Casting Time:** 1 action
**Components:** V, S, M (a bit of bat fur)
**Range:** 30 feet
**Duration:**  Concentration, up to 1 hour
**Description:**
You create an invisible, magical eye within range that hovers in the for the duration.



 You mentally recieve visual information from the eye, which has normal vision and darkvision out to 30 feet. The eye can look in every direction.



 As an action, you can move the eye up to 30 feet in any direction. There is no limit to how far away from you the eye can move, but it can't enter another plane of existence. A solid barrier blocks the eye's movement, but the eye can pass through an opening as small as 1 inch in diameter.



**Classes:**  *Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Detect_Poison_and_Disease
school: Divination
level: 1
castingTime: 1 action
ritual: true
components: V, S, M (a yew leaf)
range: Self
duration: Concentration, up to 10 minutes
classes: Cleric, Druid, Paladin, Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGDivination]
>#  Detect Poison and Disease
> Divination  (1)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S, M (a yew leaf)
**Range:** Self
**Duration:**  Concentration, up to 10 minutes
**Description:**
For the duration, you can sense the presence and location of poisons, poisonous creatures, and diseases within 30 feet of you. You also identify the kind of poison, poisonous creature, or disease in each case.



 The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.



**Classes:**  *Cleric, Druid, Paladin, Ranger, *



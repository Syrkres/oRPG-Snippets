---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Pass_without_Trace
school: Abjuration
level: 2
castingTime: 1 action
ritual: false
components: V, S, M (ashes from a burned leaf of mistletoe and a sprig of spruce)
range: Self
duration: Concentration, up to 1 hour
classes: Druid, Ranger,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGAbjuration]
>#  Pass without Trace
> Abjuration  (2)

**Casting Time:** 1 action
**Components:** V, S, M (ashes from a burned leaf of mistletoe and a sprig of spruce)
**Range:** Self
**Duration:**  Concentration, up to 1 hour
**Description:**
A veil of shadows and silence radiates from you, masking you and your companions from detection. For the duration, each creature you choose within 30 feet of you (including you) has a +10 bonus to Dexterity (Stealth) checks and can’t be tracked except by magical means. A creature that receives this bonus leaves behind no tracks or other traces of its passage.



**Classes:**  *Druid, Ranger, *



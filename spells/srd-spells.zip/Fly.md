---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Fly
school: Transmutation
level: 3
castingTime: 1 action
ritual: false
components: V, S, M (a wing feather from any bird)
range: Touch
duration: Concentration, up to 10 minutes
classes: Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Fly
> Transmutation  (3)

**Casting Time:** 1 action
**Components:** V, S, M (a wing feather from any bird)
**Range:** Touch
**Duration:**  Concentration, up to 10 minutes
**Description:**
You touch a willing creature. The target gains a flying speed of 60 feet for the duration. When the spell ends, the target falls if it is still aloft, unless it can stop the fall.

When you cast this spell using a spell slot of 4th level or higher, you can target one additional creature for each slot level above 3rd.

**Classes:**  *Sorcerer, Warlock, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Earth_Tremor
school: Evocation
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: Self (10-foot radius)
duration: Instantaneous
classes: Bard, Druid, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Earth Tremor
> Evocation  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self (10-foot radius)
**Duration:**  Instantaneous
**Description:**
You cause a tremor in the ground in a 10-foot radius. Each creature other than you in that area must make a Dexterity saving throw. On a failed save, a creature takes 1d6 bludgeoning damage and is knocked prone. If the ground in that area is loose earth or stone, it becomes difficult terrain until cleared.

When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d6 for each slot level above 1st.

**Classes:**  *Bard, Druid, Sorcerer, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Heal
school: Evocation
level: 6
castingTime: 1 action
ritual: false
components: V, S
range: 60 feet
duration: Instantaneous
classes: Cleric, Druid,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Heal
> Evocation  (6)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
Choose a creature that you can see within range. A surge of positive energy washes through the creature, causing it to regain 70 hit points. This spell also ends blindness, deafness, and any diseases affecting the target. This spell has no effect on constructs or undead.

When you cast this spell using a spell slot of 7th level or higher, the amount of healing increases by 10 for each slot level above 6th.

**Classes:**  *Cleric, Druid, *



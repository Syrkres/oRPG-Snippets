---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Aura_Of_Vitality
school: Evocation
level: 3
castingTime: 1 action
ritual: false
components: V
range: Self (30-foot radius)
duration: Concentration, up to 1 minute
classes: Paladin,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Aura Of Vitality
> Evocation  (3)

**Casting Time:** 1 action
**Components:** V
**Range:** Self (30-foot radius)
**Duration:**  Concentration, up to 1 minute
**Description:**
Healing energy radiates from you in an aura with a 30-foot radius. Until the spell ends, the aura moves with you, centered on you. You can use a bonus action to cause one creature in the aura (including you) to regain 2d6 hit points.



**Classes:**  *Paladin, *



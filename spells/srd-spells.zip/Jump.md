---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Jump
school: Transmutation
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a grasshopper's hind leg)
range: Touch
duration: 1 minute
classes: Druid, Ranger, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Jump
> Transmutation  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a grasshopper's hind leg)
**Range:** Touch
**Duration:**  1 minute
**Description:**
You touch a creature. The creature's jump distance is tripled until the spell ends.



**Classes:**  *Druid, Ranger, Sorcerer, Wizard, *



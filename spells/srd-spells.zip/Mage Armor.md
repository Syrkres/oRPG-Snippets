---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Mage_Armor
school: Abjuration
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a piece of cured leather)
range: Touch
duration: 8 hours
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGAbjuration]
>#  Mage Armor
> Abjuration  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a piece of cured leather)
**Range:** Touch
**Duration:**  8 hours
**Description:**
You touch a willing creature who isn’t wearing armor, and a protective magical force surrounds it until the spell ends. The target’s base AC becomes 13 + its Dexterity modifier. The spell ends if the target dons armor or if you dismiss the spell as an action.



**Classes:**  *Sorcerer, Wizard, *



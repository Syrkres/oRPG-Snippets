---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Cure_Wounds
school: Evocation
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Instantaneous
classes: Bard, Cleric, Druid, Paladin, Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Cure Wounds
> Evocation  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
A creature you touch regains a number of hit points equal to 1d8 + your spellcasting ability modifier. This spell has no effect on undead or constructs.

When you cast this spell using a spell slot of 2nd level or higher, the healing increases by 1d8 for each slot level above 1st.

**Classes:**  *Bard, Cleric, Druid, Paladin, Ranger, *



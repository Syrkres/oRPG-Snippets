---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Pyrotechnics
school: Transmutation
level: 2
castingTime: 1 action
ritual: false
components: V, S
range: 60 feet
duration: Instantaneous
classes: Bard, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Pyrotechnics
> Transmutation  (2)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
Choose an area of flame that you can see and that can fit within a 5-foot cube within range. You can extinguish the fire in that area, and you create either fireworks or smoke.



**Classes:**  *Bard, Sorcerer, Wizard, *



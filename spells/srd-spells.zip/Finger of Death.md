---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Finger_of_Death
school: Necromancy
level: 7
castingTime: 1 action
ritual: false
components: V, S
range: 60 feet
duration: Instantaneous
classes: Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGNecromancy]
>#  Finger of Death
> Necromancy  (7)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
You send negative engery coursing through a creature that you can see within range, causing it searing pain. The target must make a Constitution saving throw. It takes 7d8 + 30 necrotic damage on a failed save, or half as much damage on a successful one.



 A humanoid killed by this spell rises at the start of your next turn as a zombie that is permanently under your command, following your verbal orders to the best of its ability.



**Classes:**  *Sorcerer, Warlock, Wizard, *



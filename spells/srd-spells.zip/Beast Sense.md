---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Beast_Sense
school: Divination
level: 2
castingTime: 1 action
ritual: true
components: S
range: Touch
duration: Concentration, up to 1 hour
classes: Druid, Ranger,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03vinactive.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGDivination]
>#  Beast Sense
> Divination  (2)
> **Ritual**

**Casting Time:** 1 action
**Components:** S
**Range:** Touch
**Duration:**  Concentration, up to 1 hour
**Description:**
You touch a willing beast. For the duration of the spell, you can use your action to see through the beast’s eyes and hear what it hears, and continue to do so until you use your action to return to your normal senses.



 While perceiving through the beast’s senses, you gain the benefits of any special senses possessed by that creature, though you are blinded and deafened to your own surroundings.



**Classes:**  *Druid, Ranger, *



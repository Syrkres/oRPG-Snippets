---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Greater_Invisibility
school: Illusion
level: 4
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Concentration, up to 1 minute
classes: Sorcerer, Wizard, Bard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGIllusion]
>#  Greater Invisibility
> Illusion  (4)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Concentration, up to 1 minute
**Description:**
You or a creature you touch becomes invisible until the spell ends. Anything the target is wearing or carrying is invisible as long as it is on the target’s person.



**Classes:**  *Sorcerer, Wizard, Bard, *



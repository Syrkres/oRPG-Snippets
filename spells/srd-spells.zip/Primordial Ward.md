---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Primordial_Ward
school: Abjuration
level: 6
castingTime: 1 action
ritual: false
components: V, S
range: Self
duration: Concentration, up to 1 minute
classes: Druid,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Primordial Ward
> Abjuration  (6)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
You have resistance to acid, cold, fire, lightning, and thunder damage for the spell’s duration.



 When you take damage of one of those types, you can use your reaction to gain immunity to that type of damage, including against the triggering damage. If you do so, the resistances end, and you have the immunity until the end of your next turn, at which time the spell ends.



**Classes:**  *Druid, *



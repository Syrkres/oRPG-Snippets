---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Flame_Strike
school: Evocation
level: 5
castingTime: 1 action
ritual: false
components: V, S, M (pinch of sulfur)
range: 60 feet
duration: Instantaneous
classes: Cleric,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEvocation]
>#  Flame Strike
> Evocation  (5)

**Casting Time:** 1 action
**Components:** V, S, M (pinch of sulfur)
**Range:** 60 feet
**Duration:**  Instantaneous
**Description:**
A vertical column of divine fire roars down from the heavens in a location you specify. Each creature in a 10-foot radius, 40-foot-high cylinder centered on a point within range must make a Dexterity saving throw. A creature takes 4d6 fire damage and 4d6 radiant damage on a failed save, or half as much damage on a successful one.

When you cast this spell using a spell slot of 6th level or higher, the fire damage or the radiant damage (your choice) inceases by 1d6 for each slot level above 5th.

**Classes:**  *Cleric, *



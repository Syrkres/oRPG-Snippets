---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Expeditious_Retreat
school: Transmutation
level: 1
castingTime: 1 bonus action
ritual: false
components: V, S
range: Self
duration: Concentration, up to 10 minutes
classes: Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Expeditious Retreat
> Transmutation  (1)

**Casting Time:** 1 bonus action
**Components:** V, S
**Range:** Self
**Duration:**  Concentration, up to 10 minutes
**Description:**
This spell allows you to move at an incredible pace. When you cast this spell, and then as a bonus action on each of your turns until the spell ends, you can take the Dash action.



**Classes:**  *Sorcerer, Warlock, Wizard, *



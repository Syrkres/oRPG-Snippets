---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Water_Breathing
school: Transmutation
level: 3
castingTime: 1 action
ritual: true
components: V, S, M (a short reed or piece of straw)
range: 30 feet
duration: 24 hours
classes: Druid, Ranger, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Water Breathing
> Transmutation  (3)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S, M (a short reed or piece of straw)
**Range:** 30 feet
**Duration:**  24 hours
**Description:**
This spell grants up to ten willing creatures you can see within range the abilily to breathe underwater until the spell ends. Affected creatures also retain their normal mode of respiration.



**Classes:**  *Druid, Ranger, Sorcerer, Wizard, *



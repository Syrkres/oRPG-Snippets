---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Grease
school: Conjuration
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a bit of pork rind or butter)
range: 60 feet
duration: 1 minute
classes: Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGConjuration]
>#  Grease
> Conjuration  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a bit of pork rind or butter)
**Range:** 60 feet
**Duration:**  1 minute
**Description:**
Slick grease covers the ground in a 10-foot square centered on a point within range and turns it into difficult terrain for the duration.



 When the grease appears, each creature standing in its area must succeed on a Dexterity saving throw or fall prone. A creature that enters the area or ends its turn there must also succeed on a Dexterity saving throw or fall prone.



**Classes:**  *Wizard, *



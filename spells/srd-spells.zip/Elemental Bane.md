---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Elemental_Bane
school: Transmutation
level: 4
castingTime: 1 action
ritual: false
components: V, S
range: 90 feet
duration: Concentration, up to 1 minute
classes: Druid, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Elemental Bane
> Transmutation  (4)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 90 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
Choose one creature you can see within range, and choose one of the following damage types: acid, cold, fire, lightning, or thunder. The target must succeed on a Constitution saving throw or be affected by the spell for its duration. The first time each turn the affected target takes damage of the chosen type, the target takes an extra 2d6 damage of that type. Moreover, the target loses any resistance to that damage type until the spell ends.

When you cast this spell using a spell slot of 5th level or higher, you can target one additional creature for each slot level above 4th. The creatures must be within 30 feet of each other when you target them.

**Classes:**  *Druid, Warlock, Wizard, *



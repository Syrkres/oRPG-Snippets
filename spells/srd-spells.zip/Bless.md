---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Bless
school: Enchantment
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a sprinkling of holy water)
range: 30 feet
duration: Concentration, up to 1 minute
classes: Cleric, Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEnchantment]
>#  Bless
> Enchantment  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a sprinkling of holy water)
**Range:** 30 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
You bless up to three creatures of your choice within range. Whenever a target makes an attack roll or a saving throw before the spell ends, the target can roll a d4 and add the number rolled to the attack roll or saving throw.

When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st.

**Classes:**  *Cleric, Paladin, *



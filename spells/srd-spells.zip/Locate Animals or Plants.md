---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Locate_Animals_or_Plants
school: Divination
level: 2
castingTime: 1 action
ritual: true
components: V, S, M (a bit of fur from a bloodhound)
range: Self
duration: Instantaneous
classes: Bard, Druid, Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGDivination]
>#  Locate Animals or Plants
> Divination  (2)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S, M (a bit of fur from a bloodhound)
**Range:** Self
**Duration:**  Instantaneous
**Description:**
Describe or name a specific kind of beast or plant. Concentrating on the voice of nature in your surroundings, you learn the direction and distance to the closest creature or plant of that kind within 5 miles, if any are present.



**Classes:**  *Bard, Druid, Ranger, *



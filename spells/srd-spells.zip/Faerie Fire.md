---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Faerie_Fire
school: Evocation
level: 1
castingTime: 1 action
ritual: false
components: V
range: 60 feet
duration: Concentration, up to 1 minute
classes: Bard, Druid,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Faerie Fire
> Evocation  (1)

**Casting Time:** 1 action
**Components:** V
**Range:** 60 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
Each object in a 20-foot cube within range is outlined in blue, green, or violet light (your choice). Any creature in the area when the spell is cast is also outlined in light if it fails a Dexterity saving throw. For the duration, objects and affected creatures shed dim light in a 10-foot radius.



 Any attack roll against an affected creature or object has advantage if the attacker can see it, and the affected creature or object can't benefit from being invisible.



**Classes:**  *Bard, Druid, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Message
school: Transmutation
level: 0
castingTime: 1 action
ritual: false
components: V, S, M (a short piece of copper wire)
range: 120 feet
duration: 1 round
classes: Bard, Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Message
> Transmutation  (cantrip)

**Casting Time:** 1 action
**Components:** V, S, M (a short piece of copper wire)
**Range:** 120 feet
**Duration:**  1 round
**Description:**
You point your finger toward a creature within range and whisper a message. The target (and only the target) hears the message and can reply in a whisper that only you can hear.



 You can cast this spell through solid objects if you are familiar with the target and know it is beyond the barrier. Magical silence, 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood blocks the spell. The spell doesn't have to follow a straight line and can travel freely around corners or through openings.



**Classes:**  *Bard, Sorcerer, Wizard, *



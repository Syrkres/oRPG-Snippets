---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Misty_Step
school: Conjuration
level: 2
castingTime: 1 bonus action
ritual: false
components: V
range: Self
duration: Instantaneous
classes: Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Misty Step
> Conjuration  (2)

**Casting Time:** 1 bonus action
**Components:** V
**Range:** Self
**Duration:**  Instantaneous
**Description:**
Briefly surrounded by silvery mist, you teleport up to 30 feet to an unoccupied space that you can see.



**Classes:**  *Sorcerer, Warlock, Wizard, *



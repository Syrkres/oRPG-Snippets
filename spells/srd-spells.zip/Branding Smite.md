---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Branding_Smite
school: Evocation
level: 2
castingTime: 1 bonus action
ritual: false
components: V
range: Self
duration: Concentration, up to 1 minute
classes: Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Branding Smite
> Evocation  (2)

**Casting Time:** 1 bonus action
**Components:** V
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
The next time you hit a creature with a weapon attack before this spell ends, the weapon gleams with astral radiance as you strike. The attack deals an extra 2d6 radiant damage to the target, which becomes visible if it’s invisible, and the target sheds dim light in a 5-foot radius and can’t become invisible until the spell ends.

When you cast this spell using a spell slot of 3rd level or higher, the extra damage increases by 1d6 for each slot level above 2nd.

**Classes:**  *Paladin, *



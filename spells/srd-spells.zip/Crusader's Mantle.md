---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Crusader's_Mantle
school: Evocation
level: 3
castingTime: 1 action
ritual: false
components: V
range: Self
duration: Concentration, up to 1 minute
classes: Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Crusader's Mantle
> Evocation  (3)

**Casting Time:** 1 action
**Components:** V
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
Holy power radiates from you in an aura with a 30-foot radius, awakening boldness in friendly creatures. Until the spell ends, the aura moves with you, centered on you. While in the aura, each nonhostile creature in the aura (including you) deals an extra 1d4 radiant damage when it hits with a weapon attack.



**Classes:**  *Paladin, *



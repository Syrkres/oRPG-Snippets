---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Guardian_of_Faith
school: Conjuration
level: 4
castingTime: 1 action
ritual: false
components: V
range: 30 feet
duration: 8 hours
classes: Cleric,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Guardian of Faith
> Conjuration  (4)

**Casting Time:** 1 action
**Components:** V
**Range:** 30 feet
**Duration:**  8 hours
**Description:**
A Large spectral guardian appears and hovers for the duration in an unoccupied space of your choice that you can see within range. The guardian occupies that space and is indistinct except for a gleaming sword and shield emblazoned with the symbol of your deity.



 Any creature hostile to you that moves to a space within 10 feet of the guardian for the first time on a turn must succeed on a Dexterity saving throw. The creature takes 20 radiant damage on a failed save, or half as much damage on a successful one. The guardian vanishes when it has dealt a total of 60 damage.



**Classes:**  *Cleric, *



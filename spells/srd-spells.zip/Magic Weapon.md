---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Magic_Weapon
school: Transmutation
level: 2
castingTime: 1 bonus action
ritual: false
components: V, S
range: Touch
duration: Concentration, up to 1 hour
classes: Paladin, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Magic Weapon
> Transmutation  (2)

**Casting Time:** 1 bonus action
**Components:** V, S
**Range:** Touch
**Duration:**  Concentration, up to 1 hour
**Description:**
You touch a nonmagical weapon. Until the spell ends, that weapon becomes a magic weapon with a +1 bonus to attack rolls and damage rolls.

When you cast this spell using a spell slot of 4th level or higher, the bonus increases to +2. When you use a spell slot of 6th level or higher, the bonus increases to +3.

**Classes:**  *Paladin, Wizard, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Invisibility
school: Illusion
level: 2
castingTime: 1 action
ritual: false
components: V, S, M (an eyelash encased in gum arabic)
range: Touch
duration: Concentration, up to 1 hour
classes: Bard, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGIllusion]
>#  Invisibility
> Illusion  (2)

**Casting Time:** 1 action
**Components:** V, S, M (an eyelash encased in gum arabic)
**Range:** Touch
**Duration:**  Concentration, up to 1 hour
**Description:**
A creature you touch becomes invisible until the spell ends. Anything the target is wearing or carrying is invisible as long as it is on the target's person. The spell ends for a target that attacks or casts a spell.

When you cast this spell using a spell slot of 3rd level or higher, you can target one additional creature for each slot level above 2nd.

**Classes:**  *Bard, Sorcerer, Warlock, Wizard, *



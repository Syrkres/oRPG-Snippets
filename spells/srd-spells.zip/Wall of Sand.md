---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Wall_of_Sand
school: Evocation
level: 3
castingTime: 1 action
ritual: false
components: V, S, M (a handful of sand)
range: 90 feet
duration: Concentration, up to 10 minutes
classes: Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEvocation]
>#  Wall of Sand
> Evocation  (3)

**Casting Time:** 1 action
**Components:** V, S, M (a handful of sand)
**Range:** 90 feet
**Duration:**  Concentration, up to 10 minutes
**Description:**
You conjure up a wall of swirling sand on the ground at a point you can see within range. You can make the wall up to 30 feet long, 10 feet high, and 10 feet thick, and it vanishes when the spell ends. It blocks line of sight but not movement. A creature is blinded while in the wall’s space and must spend 3 feet of movement for every 1 foot it moves there.



**Classes:**  *Wizard, *


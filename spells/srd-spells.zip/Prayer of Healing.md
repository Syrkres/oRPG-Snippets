---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Prayer_of_Healing
school: Evocation
level: 2
castingTime: 10 minutes
ritual: false
components: V
range: 30 feet
duration: Instantaneous
classes: Cleric,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Prayer of Healing
> Evocation  (2)

**Casting Time:** 10 minutes
**Components:** V
**Range:** 30 feet
**Duration:**  Instantaneous
**Description:**
Up to six creatures of your choice that you can see within range each regain hit points equal to 2d8 + your spellcasting ability modifier. This spell has no effect on undead or constructs.

When you cast this spell using a spell slot of 3rd level or higher, the healing increases by 1d8 for each slot level above 2nd.

**Classes:**  *Cleric, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Circle_of_Power
school: Abjuration
level: 5
castingTime: 1 action
ritual: false
components: V
range: Self (30-foot radius)
duration: Concentration, up to 10 minutes
classes: Paladin,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Circle of Power
> Abjuration  (5)

**Casting Time:** 1 action
**Components:** V
**Range:** Self (30-foot radius)
**Duration:**  Concentration, up to 10 minutes
**Description:**
Divine energy radiates from you, distorting and diffusing magical energy within 30 feet of you. Until the spell ends, the sphere moves with you, centered on you. For the duration, each friendly creature in the area (including you) has advantage on saving throws against spells and other magical effects. Additionally, when an affected creature succeeds on a saving throw made against a spell or magical effect that allows it to make a saving throw to take only half damage, it instead takes no damage if it succeeds on the saving throw.



**Classes:**  *Paladin, *



---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Vampiric_Touch
school: Necromancy
level: 3
castingTime: 1 action
ritual: false
components: V,S
range: Self
duration: Concentration, up to 1 minute
classes: Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGNecromancy]
>#  Vampiric Touch
> Necromancy  (3)

**Casting Time:** 1 action
**Components:** V,S
**Range:** Self
**Duration:**  Concentration, up to 1 minute
**Description:**
The touch of your shadow-wreathed hand can siphon life force from others to heal your wounds. Make a melee spell attack against a creature within your reach. On a hit, the target takes 3d6 necrotic damage, and you regain hit points equal to half the amount of necrotic damage dealt. Until the spell ends, you can make the attack again on each of your turns as an action.

When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d6 for each slot level above 3rd.

**Classes:**  *Warlock, Wizard, *



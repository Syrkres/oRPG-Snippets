---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Chromatic_Orb
school: Evocation
level: 1
castingTime: 1 action
ritual: false
components: V, S, M (a diamond worth at least 50gp)
range: 90 feet
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEvocation]
>#  Chromatic Orb
> Evocation  (1)

**Casting Time:** 1 action
**Components:** V, S, M (a diamond worth at least 50gp)
**Range:** 90 feet
**Duration:**  Instantaneous
**Description:**
You hurl a 4-inch-diameter sphere of energy at a creature that you can see within range. You choose acid, cold, fire, lightning, poison, or thunder for the type of orb you create, and then make a ranged spell attack against the target. If the attack hits, the creature takes 3d8 of the type you chose.

When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d8 for each slot level above 1st.

**Classes:**  *Sorcerer, Wizard, *



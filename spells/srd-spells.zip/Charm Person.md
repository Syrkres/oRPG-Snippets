---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Charm_Person
school: Enchantment
level: 1
castingTime: 1 action
ritual: false
components: V, S
range: 30 feet
duration: 1 hour
classes: Bard, Druid, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEnchantment]
>#  Charm Person
> Enchantment  (1)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 30 feet
**Duration:**  1 hour
**Description:**
You attempt to charm a humanoid you can see within range. It must make a Wisdom saving throw, and does so with advantage if you or your companions are fighting it. If it fails the saving throw, it is charmed by you until the spell ends or until you or your companions do anything harmful to it. The charmed creature regards you as a friendly acquaintance. When the spell ends, the creature knows it was charmed by you.

When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st. The creatures must be within 30 feet of each other when you target them.

**Classes:**  *Bard, Druid, Sorcerer, Warlock, Wizard, *



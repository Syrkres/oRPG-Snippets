---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Aura_of_Life
school: Abjuration
level: 4
castingTime: 1 action
ritual: false
components: V
range: Self (30-foot radius)
duration: Concentration, up to 10 minutes
classes: Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Aura of Life
> Abjuration  (4)

**Casting Time:** 1 action
**Components:** V
**Range:** Self (30-foot radius)
**Duration:**  Concentration, up to 10 minutes
**Description:**
Life-preserving energy radiates from you in an aura with a 30-foot radius. Until the spell ends, the aura moves with you, centered on you. Each nonhostile creature in the aura (including you) has resistance to necrotic damage, and its hit point maximum can't be reduced. In addition, a nonhostile, living creature regains 1 hit point when it starts its turn in the aura with 0 hit points.



**Classes:**  *Paladin, *



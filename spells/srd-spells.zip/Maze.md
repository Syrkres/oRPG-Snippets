---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Maze
school: Conjuration
level: 8
castingTime: 1 action
ritual: false
components: V, S
range: 60 feet
duration: Concentration, up to 10 minutes
classes: Wizard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Maze
> Conjuration  (8)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 60 feet
**Duration:**  Concentration, up to 10 minutes
**Description:**
You banish a creature that you can see within range into a labyrinthine demiplane. The target remains there for the duration or until it escapes the maze.



 The target can use its action to attempt to escape. When it does so, it makes a DC 20 Intelligence check. If it succeeds, it escapes, and the spell ends (a minotaur or goristro demon automatically succeeds).



 When the spell ends, the target reappears in the space it left or, if that space is occupied, in the nearest unoccupied space.



**Classes:**  *Wizard, *



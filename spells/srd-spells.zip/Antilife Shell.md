---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Antilife_Shell
school: Abjuration
level: 5
castingTime: 1 action
ritual: false
components: V, S
range: Self (10-foot radius)
duration: Concentration, up to 1 hour
classes: Druid,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGAbjuration]
>#  Antilife Shell
> Abjuration  (5)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self (10-foot radius)
**Duration:**  Concentration, up to 1 hour
**Description:**
A shimmering barrier extends out from you in a 10-foot radius and moves with you, remaining centered on you and hedging out creatures other than undead and constructs. The barrier lasts for the duration.



 The barrier prevents an affected creature from passing or reaching through. An affected creature can cast spells or make attacks with ranged or reach weapons through the barrier.



 If you move so an affected creature is forced to pass through the barrier, the spell ends.



**Classes:**  *Druid, *



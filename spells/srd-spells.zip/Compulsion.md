---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Compulsion
school: Enchantment
level: 4
castingTime: 1 action
ritual: false
components: V, S
range: 30 feet
duration: Concentration, up to 1 minute
classes: Bard,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEnchantment]
>#  Compulsion
> Enchantment  (4)

**Casting Time:** 1 action
**Components:** V, S
**Range:** 30 feet
**Duration:**  Concentration, up to 1 minute
**Description:**
Creatures of your choice that you can see within range and that can hear you must make a Wisdom saving throw. A target automatically succeeds on this saving throw if it can't be charmed. On a failed save, a target is affected by this spell. Until the spell ends, you can use a bonus action on each of your turns to designate a direction that is horizontal to you. Each affected target must use as much of its movement as possible to move in that direction on its next turn. It can take any action before it moves. After moving in this way, it can make another Wisdom save to try to end the effect.



 A target isn't compelled to move into an obviously deadly hazard, such as a fire or a pit, but it will provoke opportunity attacks to move in the designated direction.



**Classes:**  *Bard, *



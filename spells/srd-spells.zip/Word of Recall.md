---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Word_of_Recall
school: Conjuration
level: 6
castingTime: 1 action
ritual: false
components: V
range: 5 feet
duration: Instantaneous
classes: Cleric,
---
> [!oRPG-Spell]
> |Info|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Word of Recall
> Conjuration  (6)

**Casting Time:** 1 action
**Components:** V
**Range:** 5 feet
**Duration:**  Instantaneous
**Description:**
You and up to five willing creatures within 5 feet of you instantly teleport to a previously designated sanctuary. You and any creatures that teleport with you appear in the nearest unoccupied space to the spot you designated when you prepared your sanctuary (see below). If you cast this spell without first preparing a sanctuary, the spell has no effect.



 You must designate a sanctuary by casting this spell within a location, such as a temple, dedicated to or strongly linked to your deity. If you attempt to cast the spell in this manner in an area that isn’t dedicated to your deity, the spell has no effect.



**Classes:**  *Cleric, *



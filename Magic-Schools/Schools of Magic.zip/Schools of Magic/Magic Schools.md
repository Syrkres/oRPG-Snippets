---
fileType: Gming
---
> [!oRPG-magicSchools-chart] Magic Schools Description
> 
> Abjuration
> 
> ![[abjurationLrg.png]]
> 
> Protect Stuff
> 
> Illusion
> 
> ![[illusionLrg.png]]
> 
> Make stuff seem like other stuff
> 
> Enchantment
> 
> ![[enchantmentLrg.png]]
> 
> Make things do stuff
> 
> Divination
> 
> ![[divinationLrg.png]]
> 
> Protect Stuff
> 
> Evocation
> 
> ![[evocationLrg.png]]
> 
> Destroy stuff
> 
> Transmutation
> 
> ![[transmutationLrg.png]]
> 
> Change stuff into other stuff
> 
> Necromancy
> 
> ![[necromancyLrg.png]]
> 
> Do creepy stuff
> 
> Conjuration
> 
> ![[conjurationLrg.png]]
> 
> Make stuff appear

